/**
 * nnue.cpp — Apex Timurlenk NNUE implementasyonu
 *
 * Ağırlık dosyası formatı (networks/apex_v1.bin):
 *   [0-3]  "APEX"          — magic
 *   [4-7]  version (int32) — şu an 1
 *   [8..]  W1: NNUE_INPUT × NNUE_L1 × int16
 *          b1: NNUE_L1 × int32
 *          W2: NNUE_L1*2 × NNUE_L2 × int16
 *          b2: NNUE_L2 × int32
 *          W3: NNUE_L2 × int16
 *          b3: int32
 */

#include "nnue.h"
#include "board.h"
#include <cstring>
#include <fstream>
#include <algorithm>
#include <cmath>

namespace Apex {

// ─── Yapıcı ──────────────────────────────────────────────────────────────────

NNUENetwork::NNUENetwork() {
    W1_.fill(0);
    b1_.fill(0);
    W2_.fill(0);
    b2_.fill(0);
    W3_.fill(0);
    b3_.fill(0);
}

// ─── Ağırlık Dosyası Yükleme ─────────────────────────────────────────────────

bool NNUENetwork::load(const std::string& path) {
    std::ifstream f(path, std::ios::binary);
    if (!f) return false;

    char magic[4];
    f.read(magic, 4);
    if (f.gcount() < 4 || std::strncmp(magic, "APEX", 4) != 0) return false;

    int32_t version;
    f.read(reinterpret_cast<char*>(&version), 4);
    if (version < 1 || version > 2) return false;

    auto read16 = [&](auto& arr) {
        f.read(reinterpret_cast<char*>(arr.data()),
               arr.size() * sizeof(int16_t));
    };
    auto read32 = [&](auto& arr) {
        f.read(reinterpret_cast<char*>(arr.data()),
               arr.size() * sizeof(int32_t));
    };

    read16(W1_); read32(b1_);
    read16(W2_); read32(b2_);
    read16(W3_); read32(b3_);

    if (!f) return false;

    // Placeholder tespiti: tüm W1_ sıfırsa ağırlık dosyası boş demektir
    bool has_nonzero = false;
    for (int i = 0; i < std::min((int)W1_.size(), 256); i++) {
        if (W1_[i] != 0) { has_nonzero = true; break; }
    }
    if (!has_nonzero) return false; // Eğitilmemiş model — NNUE bypass

    loaded_ = true;
    return true;
}

// ─── Özellik İndeksi ─────────────────────────────────────────────────────────
// perspective: hangi renkten bakıyoruz (WHITE / BLACK)
// piece_color: taşın rengi
// pt: taş tipi (SAH=1..PIYON=11, 0-tabanlı olması için -1)
// sq: kare (0..109)

int NNUENetwork::feature_index(Color perspective, Color piece_color,
                                PieceType pt, Square sq) {
    if (sq >= BOARD_NORMAL || pt == NO_PIECE_TYPE) return -1;
    // Renk perspektifine göre tahtayı çevir
    int sq_idx = (perspective == BLACK) ? (BOARD_NORMAL - 1 - sq) : sq;
    // Taş rengi: 0 = kendi, 1 = rakip
    int color_idx = (piece_color == perspective) ? 0 : 1;
    int pt_idx = static_cast<int>(pt) - 1; // 0..10
    return color_idx * NNUE_PIECE_TYPES * NNUE_SQUARES
         + pt_idx * NNUE_SQUARES
         + sq_idx;
}

// ─── İleri Besleme ───────────────────────────────────────────────────────────

i32 NNUENetwork::forward(const Accumulator& acc, Color stm) const {
    // L1 aktivasyonları: stm birikimleyicisi önce, sonra rakip
    const auto& our_acc = (stm == WHITE) ? acc.white : acc.black;
    const auto& opp_acc = (stm == WHITE) ? acc.black : acc.white;

    // Clamp(0, Q_IN) aktivasyon
    std::array<int32_t, NNUE_L1 * 2> l1{};
    for (int i = 0; i < NNUE_L1; i++) {
        l1[i]          = std::clamp(our_acc[i], 0, Q_IN);
        l1[i + NNUE_L1] = std::clamp(opp_acc[i], 0, Q_IN);
    }

    // L2: dot product
    std::array<int32_t, NNUE_L2> l2{};
    for (int o = 0; o < NNUE_L2; o++) {
        int32_t sum = b2_[o];
        for (int i = 0; i < NNUE_L1 * 2; i++)
            sum += static_cast<int32_t>(W2_[i * NNUE_L2 + o]) * l1[i];
        l2[o] = std::max(0, sum / Q_W1); // ReLU + dequantize
    }

    // L3: çıkış
    int32_t out = b3_[0];
    for (int i = 0; i < NNUE_L2; i++)
        out += static_cast<int32_t>(W3_[i]) * l2[i];

    // Centipawn'a dönüştür
    return static_cast<i32>(out * NNUE_SCALE / (Q_W1 * Q_W2 * Q_IN));
}

// ─── Artımlı Akümülatör Güncelleme ───────────────────────────────────────────

void NNUENetwork::add_piece(Accumulator& acc, Color pc, PieceType pt, Square sq) const {
    if (!loaded_ || sq >= BOARD_NORMAL || pt == NO_PIECE_TYPE) return;
    for (Color persp : {WHITE, BLACK}) {
        int idx = feature_index(persp, pc, pt, sq);
        if (idx < 0 || idx >= NNUE_INPUT) continue;
        auto& a = (persp == WHITE) ? acc.white : acc.black;
        const int16_t* row = &W1_[idx * NNUE_L1];
        for (int n = 0; n < NNUE_L1; n++)
            a[n] += row[n];
    }
}

void NNUENetwork::remove_piece_from_acc(Accumulator& acc, Color pc, PieceType pt, Square sq) const {
    if (!loaded_ || sq >= BOARD_NORMAL || pt == NO_PIECE_TYPE) return;
    for (Color persp : {WHITE, BLACK}) {
        int idx = feature_index(persp, pc, pt, sq);
        if (idx < 0 || idx >= NNUE_INPUT) continue;
        auto& a = (persp == WHITE) ? acc.white : acc.black;
        const int16_t* row = &W1_[idx * NNUE_L1];
        for (int n = 0; n < NNUE_L1; n++)
            a[n] -= row[n];
    }
}

// ─── Tam Değerlendirme (Kaba Kuvvet + Akümülatör Cache) ──────────────────────

i32 NNUENetwork::evaluate(const Board& b, Color stm) const {
    if (!loaded_) return 0;

    // Geçerli akümülatör varsa doğrudan ileri besleme
    const StateInfo* st = b.state();
    if (st && st->acc_valid) {
        return forward(st->acc, stm);
    }

    // Kaba kuvvet: tüm taşları tara, akümülatörü sıfırdan hesapla
    Accumulator acc;
    acc.reset(b1_);

    for (int r = 0; r < BOARD_RANKS; r++) {
        for (int f = 0; f < BOARD_FILES; f++) {
            Square sq = make_sq(f, r);
            Piece p = b.piece_on(sq);
            if (p == NO_PIECE) continue;
            PieceType pt = piece_type(p);
            Color     pc = piece_color(p);

            for (Color persp : {WHITE, BLACK}) {
                int idx = feature_index(persp, pc, pt, sq);
                if (idx < 0 || idx >= NNUE_INPUT) continue;

                auto& a = (persp == WHITE) ? acc.white : acc.black;
                for (int n = 0; n < NNUE_L1; n++)
                    a[n] += W1_[idx * NNUE_L1 + n];
            }
        }
    }

    // Sonraki çağrılar için StateInfo'ya cache'le (logically const)
    if (st) {
        const_cast<StateInfo*>(st)->acc = acc;
        const_cast<StateInfo*>(st)->acc_valid = true;
    }

    return forward(acc, stm);
}

} // namespace Apex
