#include "tt.h"
#include "movegen.h"
#include <cstdlib>
#include <cstring>
#include <algorithm>

namespace Apex {

ZobristTable Zobrist;

// ─────────────────────────────────────────────────────────────────────────────
//  TranspositionTable
// ─────────────────────────────────────────────────────────────────────────────
TranspositionTable::TranspositionTable()
    : table_(nullptr), size_(0), age_(0)
{
    Zobrist.init();
    resize(TT_DEFAULT_MB);
}

TranspositionTable::~TranspositionTable() {
    std::free(table_);
}

void TranspositionTable::resize(int mb) {
    // 2^N slot — istenen MB'a en yakın aşağıdaki güç
    size_t bytes   = static_cast<size_t>(mb) * 1024 * 1024;
    size_t slots   = bytes / sizeof(TTEntry);

    // En yakın 2^N
    size_ = 1;
    while (size_ * 2 <= slots) size_ *= 2;

    std::free(table_);
    // aligned_alloc: önbellek hattı hizalaması (64 byte)
    table_ = static_cast<TTEntry*>(
        std::aligned_alloc(64, size_ * sizeof(TTEntry))
    );
    clear();
}

void TranspositionTable::clear() {
    std::memset(table_, 0, size_ * sizeof(TTEntry));
    age_ = 0;
}

void TranspositionTable::store(u64 hash, int depth, TTFlag flag,
                               i32 score, i32 eval, Move best_move, int ply)
{
    size_t   idx = index(hash);
    TTEntry& e   = table_[idx];

    u32 key = static_cast<u32>(hash >> 32);

    // Yazma politikası:
    // 1. Aynı pozisyon → her zaman yaz (güncel bilgi üstündür)
    // 2. Eski giriş (farklı yaş) → yaz
    // 3. Yeni derinlik eskisinden büyükse → yaz
    bool replace = (e.key16 == key)         // aynı pozisyon
                || (e.age  != age_)         // eski giriş
                || (depth + 2 > e.depth);   // daha derin

    if (!replace) return;

    // Mat skorlarını ply-bağımsız hale getir (TT'de normalize saklama)
    if (score >  SCORE_MATE - 500) score += ply;
    if (score < -SCORE_MATE + 500) score -= ply;

    e.key16 = key;
    e.score  = static_cast<i16>(score);
    e.eval   = static_cast<i16>(eval);
    e.move   = best_move;
    e.depth  = static_cast<u8>(std::max(0, depth));
    e.flag   = static_cast<u8>(flag);
    e.age    = age_;
}

const TTEntry* TranspositionTable::probe(u64 hash) const {
    size_t       idx = index(hash);
    const TTEntry& e = table_[idx];
    u32          key = static_cast<u32>(hash >> 32);

    if (e.key16 != key || !e.valid()) return nullptr;
    return &e;
}

int TranspositionTable::hashfull() const {
    // İlk 1000 slotu örnekle
    int filled = 0;
    for (int i = 0; i < 1000; i++)
        if (table_[i].valid() && table_[i].age == age_)
            filled++;
    return filled; // promil (0–1000)
}

// ─────────────────────────────────────────────────────────────────────────────
//  MoveOrderer
// ─────────────────────────────────────────────────────────────────────────────
void MoveOrderer::reset() {
    std::memset(killers_,     0, sizeof(killers_));
    std::memset(history_,     0, sizeof(history_));
    std::memset(cap_history_, 0, sizeof(cap_history_));
    std::memset(counter_,     0, sizeof(counter_));
}

void MoveOrderer::add_killer(Move m, int ply) {
    if (ply >= MAX_PLY) return;
    if (m != killers_[ply][0]) {
        killers_[ply][1] = killers_[ply][0];
        killers_[ply][0] = m;
    }
}

void MoveOrderer::update_history(Move m, int depth, bool good, Color stm) {
    if (!move_ok(m)) return;
    Square from = move_from(m);
    Square to   = move_to(m);

    i32 bonus = good ? depth * depth : -(depth * depth);
    i32& h    = history_[stm][from][to];

    // Sınırlar: [-16384, +16384]
    h += bonus - h * std::abs(bonus) / 16384;
}

void MoveOrderer::update_cap_history(Move m, int depth, bool good,
                                      Color stm, PieceType captured) {
    if (!move_ok(m) || captured == NO_PIECE_TYPE) return;
    Square to  = move_to(m);
    i32 bonus  = good ? depth * depth : -(depth * depth);
    i32& h     = cap_history_[stm][to][captured];
    h += bonus - h * std::abs(bonus) / 16384;
}

void MoveOrderer::update_counter(Move prev, Move response) {
    if (!move_ok(prev) || !move_ok(response)) return;
    counter_[move_from(prev)][move_to(prev)] = response;
}

// Hamle skorlama (sıralama için)
void MoveOrderer::score_moves(MoveList& ml, const Board& b,
                              Move tt_move, int ply, Color stm,
                              Move prev_move,
                              const i32 (*cont_hist)[BOARD_SIZE]) const
{
    // MVV-LVA tablosu: saldırıcı değeri × 10 - kurban değeri
    // Küçük saldırgan, büyük kurban = yüksek skor
    auto mvv_lva = [&](Move m) -> i32 {
        Piece attacker = b.piece_on(move_from(m));
        Piece victim   = b.piece_on(move_to(m));
        if (victim == NO_PIECE) return 0;
        return PIECE_VALUE[piece_type(victim)] * 10
             - PIECE_VALUE[piece_type(attacker)];
    };

    Move killer0 = (ply < MAX_PLY) ? killers_[ply][0] : MOVE_NONE;
    Move killer1 = (ply < MAX_PLY) ? killers_[ply][1] : MOVE_NONE;

    // Counter-move: önceki hamleiyle tetiklenen yanıt hamlesi
    Move counter = MOVE_NONE;
    if (move_ok(prev_move))
        counter = counter_[move_from(prev_move)][move_to(prev_move)];

    for (auto& me : ml) {
        Move m = me.move;
        i32  s = 0;

        if (m == tt_move) {
            s = 2'000'000;  // TT hamlesi her zaman ilk
        } else {
            Piece victim = b.piece_on(move_to(m));
            if (victim != NO_PIECE) {
                // Yeme hamlesi: MVV-LVA + capture history
                i32 see_val = see(b, m);
                i32 cap_h   = cap_history_[stm][move_to(m)][piece_type(victim)];
                if (see_val >= 0)
                    s = 1'000'000 + mvv_lva(m) + cap_h / 16;  // Kazançlı/nötr yeme
                else
                    s = -500'000  + mvv_lva(m) + cap_h / 16;  // Kayıplı yeme (en sona)
            } else if (move_type(m) == MT_PROMO) {
                s = 900'000;  // Terfi
            } else if (m == killer0) {
                s = 800'000;
            } else if (m == killer1) {
                s = 790'000;
            } else if (counter != MOVE_NONE && m == counter) {
                s = 780'000;  // Counter-move heuristic
            } else {
                // Sakin hamle: history + CMH (1-ply continuation)
                s = history_[stm][move_from(m)][move_to(m)];
                if (cont_hist) {
                    PieceType pt = piece_type(b.piece_on(move_from(m)));
                    if (pt != NO_PIECE_TYPE)
                        s += cont_hist[pt][move_to(m)] / 2;
                }
            }
        }

        me.score = s;
    }
}

MoveExt& MoveOrderer::next_move(MoveList& ml, int index) const {
    int best = index;
    for (int i = index + 1; i < ml.size(); i++)
        if (ml.moves[i].score > ml.moves[best].score)
            best = i;
    if (best != index)
        std::swap(ml.moves[index], ml.moves[best]);
    return ml.moves[index];
}

// Bir taşın belirli bir kareye saldırıp saldırmadığını kontrol et
// SEE'de find_lva() için kullanılır
static bool can_piece_attack(const Board& b, Square frm, PieceType pt, Square to) {
    int ff = sq_file(frm), fr = sq_rank(frm);
    int tf = sq_file(to),  tr = sq_rank(to);
    int df = tf - ff, dr = tr - fr;
    int adf = std::abs(df), adr = std::abs(dr);

    switch (pt) {
    case PIYON: {
        Color c = piece_color(b.piece_on(frm));
        int fwd = (c == WHITE) ? 1 : -1;
        return (dr == fwd && adf == 1);
    }
    case VALI:
        return (adf == 1 && adr == 0) || (adf == 0 && adr == 1);
    case FERZ:
        return (adf == 1 && adr == 1);
    case SAH:
        return (adf <= 1 && adr <= 1 && (adf + adr) > 0);
    case AT:
        return (adf == 1 && adr == 2) || (adf == 2 && adr == 1);
    case DEVE:
        return (adf == 1 && adr == 3) || (adf == 3 && adr == 1);
    case FIL:
        return (adf == 2 && adr == 2);
    case SAVAS:
    case TALIA:
        return (adf == 2 && adr == 0) || (adf == 0 && adr == 2);
    case KALE: {
        if (df != 0 && dr != 0) return false;
        int sf = (df == 0) ? 0 : (df > 0 ? 1 : -1);
        int sr = (dr == 0) ? 0 : (dr > 0 ? 1 : -1);
        for (int f2 = ff+sf, r2 = fr+sr; !(f2 == tf && r2 == tr); f2 += sf, r2 += sr) {
            if (f2 < 0 || f2 >= BOARD_FILES || r2 < 0 || r2 >= BOARD_RANKS) return false;
            if (b.piece_on(make_sq(f2, r2)) != NO_PIECE) return false;
        }
        return true;
    }
    case ZURAFA: {
        // 1 çapraz adım (boş) + düz devam min 3 adım (1.,2. aralar boş)
        static const int ddx[] = { 1, 1,-1,-1};
        static const int ddy[] = { 1,-1, 1,-1};
        static const int sdx[] = { 1,-1, 0, 0};
        static const int sdy[] = { 0, 0, 1,-1};
        for (int d = 0; d < 4; d++) {
            int cf = ff + ddx[d], cr = fr + ddy[d];
            if (cf < 0 || cf >= BOARD_FILES || cr < 0 || cr >= BOARD_RANKS) continue;
            if (b.piece_on(make_sq(cf, cr)) != NO_PIECE) continue;
            for (int s = 0; s < 4; s++) {
                bool blocked = false;
                for (int step = 1; step <= 2; step++) {
                    int xf = cf + sdx[s]*step, xr = cr + sdy[s]*step;
                    if (xf < 0 || xf >= BOARD_FILES || xr < 0 || xr >= BOARD_RANKS)
                        { blocked = true; break; }
                    if (b.piece_on(make_sq(xf, xr)) != NO_PIECE)
                        { blocked = true; break; }
                }
                if (blocked) continue;
                for (int step = 3; ; step++) {
                    int xf = cf + sdx[s]*step, xr = cr + sdy[s]*step;
                    if (xf < 0 || xf >= BOARD_FILES || xr < 0 || xr >= BOARD_RANKS) break;
                    if (xf == tf && xr == tr) return true;
                    if (b.piece_on(make_sq(xf, xr)) != NO_PIECE) break;
                }
            }
        }
        return false;
    }
    default: return false;
    }
}

// SEE (Static Exchange Evaluation) — yeniden-yakalama zinciri
// Pozitif = kazançlı, negatif = kayıplı
i32 MoveOrderer::see(const Board& b, Move m) {
    Square to  = move_to(m);
    Square frm = move_from(m);

    Piece victim = b.piece_on(to);
    if (victim == NO_PIECE) return 0;

    // LVA sırası: en ucuz saldırıcıyı bul
    auto find_lva = [&](Color side) -> Square {
        static const PieceType order[] = {
            PIYON, VALI, FERZ, SAVAS, FIL, AT, DEVE, TALIA, KALE, ZURAFA, SAH
        };
        for (PieceType pt : order) {
            for (Square sq : b.pieces(side, pt)) {
                if (can_piece_attack(b, sq, pt, to))
                    return sq;
            }
        }
        return SQ_NONE;
    };

    i32 gain[32];
    int d = 0;

    Color side = piece_color(b.piece_on(frm));
    gain[d] = PIECE_VALUE[piece_type(victim)];
    d++;

    side = ~side;
    i32 last_attacker_val = PIECE_VALUE[piece_type(b.piece_on(frm))];

    for (int iter = 0; iter < 15 && d < 32; iter++) {
        Square lva = find_lva(side);
        if (lva == SQ_NONE) break;

        Piece lva_piece = b.piece_on(lva);
        gain[d] = last_attacker_val - gain[d-1];
        last_attacker_val = PIECE_VALUE[piece_type(lva_piece)];
        d++;
        side = ~side;
    }

    // Minimax geriye doğru hesapla
    while (--d > 0)
        gain[d-1] = std::max(-gain[d], gain[d-1]);

    return gain[0];
}

} // namespace Apex
