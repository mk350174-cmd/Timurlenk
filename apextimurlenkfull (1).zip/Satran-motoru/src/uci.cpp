#include "uci.h"
#include "movegen.h"
#include "evaluate.h"
#include <iostream>
#include <sstream>
#include <algorithm>
#include <iomanip>
#include <cstring>

namespace Apex {

// ─────────────────────────────────────────────────────────────────────────────
//  Koordinat → String dönüşümleri
// ─────────────────────────────────────────────────────────────────────────────
std::string UCI::sq_to_str(Square sq) {
    if (sq == WHITE_CITADEL) return "wc";
    if (sq == BLACK_CITADEL) return "bc";
    if (sq >= BOARD_NORMAL)  return "??";
    char file = 'a' + sq_file(sq);
    int  rank =  1  + sq_rank(sq);
    return std::string(1, file) + std::to_string(rank);
}

Square UCI::str_to_sq(const std::string& s) {
    if (s == "wc") return WHITE_CITADEL;
    if (s == "bc") return BLACK_CITADEL;
    if (s.size() < 2) return SQ_NONE;
    int f = s[0] - 'a';
    int r = std::stoi(s.substr(1)) - 1;
    if (f < 0 || f >= BOARD_FILES || r < 0 || r >= BOARD_RANKS) return SQ_NONE;
    return make_sq(f, r);
}

std::string UCI::move_to_str(Move m, PieceType promo) {
    if (m == MOVE_NONE) return "0000";
    if (m == MOVE_NULL) return "null";

    Square from = move_from(m);
    Square to   = move_to(m);
    MoveType mt = move_type(m);

    std::string s = sq_to_str(from) + sq_to_str(to);

    if (mt == MT_PROMO && promo != NO_PIECE_TYPE) {
        s += '=';
        s += PIECE_TYPE_STR[promo];
    } else if (mt == MT_SWAP) {
        s = "swap:" + sq_to_str(from) + sq_to_str(to);
    }
    return s;
}

Move UCI::str_to_move(const std::string& s, const Board& b) {
    if (s == "0000" || s == "(none)") return MOVE_NONE;

    // Swap hamlesi: "swap:e1h4"
    if (s.substr(0, 5) == "swap:") {
        std::string rest = s.substr(5);
        // from: ilk 2 karakter, to: kalan
        std::string from_s = rest.substr(0, 2);
        std::string to_s   = rest.substr(2);
        // Rank 2 haneliyse düzelt
        if (rest.size() >= 3 && rest[2] == '1' && rest.size() > 3)
            to_s = rest.substr(2);
        Square from = str_to_sq(from_s);
        Square to   = str_to_sq(to_s);
        if (from == SQ_NONE || to == SQ_NONE) return MOVE_NONE;
        return make_move(from, to, MT_SWAP);
    }

    // Citadel: "a9bc" veya "k2wc"
    if (s.size() >= 4) {
        std::string to_s = s.substr(s.size() - 2);
        if (to_s == "wc" || to_s == "bc") {
            std::string from_s = s.substr(0, s.size() - 2);
            Square from = str_to_sq(from_s);
            Square to   = str_to_sq(to_s);
            if (from != SQ_NONE && to != SQ_NONE)
                return make_move(from, to, MT_CITADEL);
        }
    }

    // Normal / terfi: "e5f7" veya "b9b10=K"
    // From: ilk 2-3 karakter (rank 10 için 3)
    // Eşittir işaretinden önce to, sonra promo
    std::string move_s = s;
    PieceType promo_pt = NO_PIECE_TYPE;

    auto eq_pos = move_s.find('=');
    if (eq_pos != std::string::npos) {
        std::string promo_str = move_s.substr(eq_pos + 1);
        move_s = move_s.substr(0, eq_pos);
        for (int pt = 1; pt < PIECE_TYPE_NB; pt++) {
            if (promo_str == PIECE_TYPE_STR[pt]) {
                promo_pt = static_cast<PieceType>(pt);
                break;
            }
        }
    }

    // from ve to: dosya harfi + rank sayısı
    // Rank 10 için to kısmı 3 karakter (b10)
    Square from = SQ_NONE, to = SQ_NONE;
    if (move_s.size() >= 4) {
        // from: a-k + 1-10
        size_t i = 1;
        while (i < move_s.size() && std::isdigit(move_s[i])) i++;
        from = str_to_sq(move_s.substr(0, i));
        to   = str_to_sq(move_s.substr(i));
    }

    if (from == SQ_NONE || to == SQ_NONE) return MOVE_NONE;
    if (promo_pt != NO_PIECE_TYPE)
        return make_move(from, to, MT_PROMO);
    return make_move(from, to);
}

// ─────────────────────────────────────────────────────────────────────────────
//  UCI — Kurucu / Yıkıcı
// ─────────────────────────────────────────────────────────────────────────────
UCI::UCI()
    : board_(), tt_(), searcher_(board_, tt_)
{
    board_.setup();

    // Search sonuçlarını UCI formatında yaz
    searcher_.set_info_callback(
        [this](int depth, int sd, i32 score, u64 nodes, int64_t ms, const PVLine& pv) {
            print_info(depth, sd, score, nodes, ms, pv);
        }
    );
}

UCI::~UCI() {
    wait_search_done();
}

void UCI::wait_search_done() {
    if (search_thread_.joinable()) {
        searcher_.stop();
        search_thread_.join();
    }
    searching_ = false;
}

// ─────────────────────────────────────────────────────────────────────────────
//  Ana Döngü
// ─────────────────────────────────────────────────────────────────────────────
void UCI::loop() {
    std::string line;
    while (!quit_ && std::getline(std::cin, line)) {
        if (line.empty()) continue;
        process(line);
    }
}

void UCI::process(const std::string& line) {
    std::istringstream ss(line);
    std::string token;
    ss >> token;

    if      (token == "uci")        cmd_uci();
    else if (token == "isready")    cmd_isready();
    else if (token == "ucinewgame") cmd_ucinewgame();
    else if (token == "position")   cmd_position(ss);
    else if (token == "go")         cmd_go(ss);
    else if (token == "stop")       cmd_stop();
    else if (token == "quit")       cmd_quit();
    else if (token == "setoption")  cmd_setoption(ss);
    else if (token == "ponderhit")  cmd_ponderhit();
    else if (token == "d")          cmd_debug_board();
    else if (token == "eval")       cmd_debug_eval();
    else if (token == "moves")      cmd_debug_moves();
    else if (token == "perft")      cmd_perft(ss);
    else if (token == "hash")       cmd_debug_hash();
    // Bilinmeyen komutlar sessizce yoksayılır (UCI standardı)
}

// ─────────────────────────────────────────────────────────────────────────────
//  Komut İşleyiciler
// ─────────────────────────────────────────────────────────────────────────────

void UCI::cmd_uci() {
    std::cout << "id name "   << ENGINE_NAME << " " << ENGINE_VERSION << "\n";
    std::cout << "id author " << ENGINE_AUTHOR << "\n";
    std::cout << "\n";

    // Seçenekler
    std::cout << "option name Hash type spin default 64 min 1 max 65536\n";
    std::cout << "option name Threads type spin default 1 min 1 max 128\n";
    std::cout << "option name Contempt type spin default 0 min -100 max 100\n";
    std::cout << "option name MultiPV type spin default 1 min 1 max 10\n";
    std::cout << "option name MoveOverhead type spin default 30 min 0 max 5000\n";
    std::cout << "option name Ponder type check default false\n";
    std::cout << "option name SyzygyPath type string default <empty>\n";

    // Timurlenk'e özgü
    std::cout << "option name CitadelDraw type check default true\n";
    std::cout << "option name SwapAllowed type check default true\n";
    std::cout << "option name PieceNames type combo default tr var tr var en\n";

    // L1.5 Persona Katmanı
    std::cout << "option name Persona type combo default None var None var Machiavelli var Nietzsche var Ulgen var Erlik var Bozkurt var Tengri var DedeKorkut var Umay\n";
    std::cout << "option name Psyche type spin default 0 min -100 max 100\n";

    // Needle commentary bridge
    std::cout << "option name UseNeedle type check default false\n";
    std::cout << "option name NeedleScript type string default <empty>\n";

    // NNUE
    std::cout << "option name UseNNUE type check default false\n";
    std::cout << "option name NNUEPath type string default networks/apex_v1.bin\n";

    // Açılış Kitabı
    std::cout << "option name OwnBook type check default true\n";
    std::cout << "option name BookFile type string default networks/timurlenk_openings.bin\n";

    std::cout << "uciok\n";
}

void UCI::cmd_isready() {
    // NNUE otomatik yükle (varsayılan etkin, dosya varsa)
    if (opts_.use_nnue && !opts_.nnue_path.empty()
        && !searcher_.evaluator().nnue_loaded())
    {
        bool ok = searcher_.evaluator().load_nnue(opts_.nnue_path);
        searcher_.evaluator().set_use_nnue(ok);
        if (!ok) opts_.use_nnue = false;
    }
    // Açılış kitabı otomatik yükle
    if (opts_.own_book && !opts_.book_path.empty() && !book_.loaded()) {
        book_.load(opts_.book_path);
    }
    std::cout << "readyok\n";
}

void UCI::cmd_ucinewgame() {
    wait_search_done();
    searcher_.new_game();
    board_.setup();
    move_history_.clear();
}

void UCI::cmd_position(std::istringstream& ss) {
    wait_search_done();
    move_history_.clear();

    std::string token;
    ss >> token;

    if (token == "startpos") {
        board_.setup();
        ss >> token; // "moves" kelimesini oku
    } else if (token == "fen") {
        std::string fen;
        int parts = 0;
        while (parts < 6 && ss >> token && token != "moves") {
            if (!fen.empty()) fen += ' ';
            fen += token;
            parts++;
        }
        // Eğer token "moves" değilse bir sonraki token'ı oku
        if (token != "moves") {
            if (!(ss >> token)) token.clear();
        }
        if (!board_.from_string(fen))
            board_.setup();
    }

    // Hamleler
    if (token == "moves") {
        std::string move_str;
        while (ss >> move_str) {
            Move m = str_to_move(move_str, board_);
            if (!move_ok(m)) {
                std::cerr << "info string Geçersiz hamle: " << move_str << "\n";
                continue;
            }
            move_history_.push_back({});
            board_.do_move(m, move_history_.back());
        }
    }
}

void UCI::cmd_go(std::istringstream& ss) {
    wait_search_done();

    SearchLimits lim;
    std::string token;

    while (ss >> token) {
        if      (token == "wtime")     ss >> lim.wtime;
        else if (token == "btime")     ss >> lim.btime;
        else if (token == "winc")      ss >> lim.winc;
        else if (token == "binc")      ss >> lim.binc;
        else if (token == "movestogo") ss >> lim.movestogo;
        else if (token == "movetime")  ss >> lim.movetime;
        else if (token == "depth")     ss >> lim.depth;
        else if (token == "nodes")     ss >> lim.nodes;
        else if (token == "infinite")  lim.infinite = true;
        else if (token == "ponder")    lim.ponder   = true;
    }

    // ── Açılış kitabı kontrolü — kitapta hamle varsa aramayı atla ────────────
    if (opts_.own_book && book_.loaded()) {
        Move bm = book_.probe(board_.hash());
        if (bm != MOVE_NONE) {
            Square from = move_from(bm);
            Square to   = move_to(bm);
            // UCI koordinat string'i: "e1f3" formatı
            static const char* FILES = "abcdefghijk";
            char buf[12];
            int from_file = sq_file(from);
            int from_rank = sq_rank(from) + 1;
            int to_file   = sq_file(to);
            int to_rank   = sq_rank(to)   + 1;
            snprintf(buf, sizeof(buf), "%c%d%c%d",
                     FILES[from_file], from_rank,
                     FILES[to_file],   to_rank);
            std::cout << "bestmove " << buf << "\n" << std::flush;
            return;
        }
    }

    searcher_.set_persona(opts_.persona);
    searcher_.set_threads(opts_.threads);

    // Needle bridge callback — Needle aktifse async yorum isteği gönder
    if (opts_.use_needle && commentary_.is_configured()) {
        searcher_.set_needle_callback([this](const std::string& persona,
                                             int score, int depth) {
            commentary_.request_async(persona, score, depth,
                [persona](const std::string& text) {
                    std::cout << "info string [" << persona << "/Needle] "
                              << text << "\n" << std::flush;
                });
        });
        // Zaman yönetimi kararı callback
        searcher_.set_time_adj_callback([this](const std::string& persona,
                                               int phase_score, int mat_balance,
                                               std::function<void(const std::string&)> result_cb) {
            commentary_.request_time_async(persona, phase_score, mat_balance,
                std::move(result_cb));
        });
        // Açılış stili callback
        searcher_.set_opening_callback([this](const std::string& persona,
                                              int move_num, bool is_white,
                                              std::function<void(const std::string&)> result_cb) {
            commentary_.request_opening_async(persona, move_num, is_white,
                std::move(result_cb));
        });
        // Citadel strateji callback
        searcher_.set_citadel_callback([this](const std::string& persona,
                                              int phase, int king_dist, int material,
                                              std::function<void(const std::string&)> result_cb) {
            commentary_.request_citadel_async(persona, phase, king_dist, material,
                std::move(result_cb));
        });
        // Dinamik contempt callback
        searcher_.set_contempt_callback([this](const std::string& persona,
                                               int score_trend, int move_num,
                                               std::function<void(const std::string&)> result_cb) {
            commentary_.request_contempt_async(persona, score_trend, move_num,
                std::move(result_cb));
        });
    } else {
        searcher_.set_needle_callback(nullptr);
        searcher_.set_time_adj_callback(nullptr);
        searcher_.set_opening_callback(nullptr);
        searcher_.set_citadel_callback(nullptr);
        searcher_.set_contempt_callback(nullptr);
    }

    searching_ = true;
    search_thread_ = std::thread([this, lim]() {
        searcher_.start_search(lim);
        Move best   = searcher_.best_move();
        Move ponder = searcher_.ponder_move();
        print_bestmove(best, ponder);
        searching_ = false;
    });
}

void UCI::cmd_stop() {
    searcher_.stop();
    wait_search_done();
}

void UCI::cmd_quit() {
    cmd_stop();
    commentary_.wait();
    quit_ = true;
}

void UCI::cmd_setoption(std::istringstream& ss) {
    std::string token, name, value;
    ss >> token; // "name"
    while (ss >> token && token != "value") name += (name.empty() ? "" : " ") + token;
    while (ss >> token) value += (value.empty() ? "" : " ") + token;

    // Küçük harf karşılaştırma
    auto lower = [](std::string s) {
        std::transform(s.begin(), s.end(), s.begin(), ::tolower);
        return s;
    };
    std::string lname = lower(name);

    if      (lname == "hash")         { opts_.hash_mb = std::stoi(value); tt_.resize(opts_.hash_mb); }
    else if (lname == "threads")      { opts_.threads = std::stoi(value); }
    else if (lname == "contempt")     { opts_.contempt = std::stoi(value); }
    else if (lname == "multipv")      { opts_.multi_pv = std::stoi(value); }
    else if (lname == "moveoverhead") { opts_.move_overhead = std::stoi(value); }
    else if (lname == "ponder")       { opts_.ponder = (lower(value) == "true"); }
    else if (lname == "syzygypath")   { opts_.syzygy_path = value; }
    else if (lname == "citadeldraw")  { opts_.citadel_draw = (lower(value) == "true"); }
    else if (lname == "swapallowed")  { opts_.swap_allowed = (lower(value) == "true"); }
    else if (lname == "piecenames")   { opts_.piece_names = value; }
    else if (lname == "persona") {
        std::string lval = lower(value);
        // Sayısal index desteği: "0"=None, "1"=Machiavelli, "5"=Bozkurt vb.
        bool is_numeric = !lval.empty() && std::all_of(lval.begin(), lval.end(), ::isdigit);
        if (is_numeric) {
            int idx = std::stoi(lval);
            opts_.persona.set_persona(static_cast<PersonaType>(idx));
        } else if (lval == "machiavelli") opts_.persona.set_persona(PersonaType::MACHIAVELLI);
        else if (lval == "nietzsche")   opts_.persona.set_persona(PersonaType::NIETZSCHE);
        else if (lval == "ulgen")       opts_.persona.set_persona(PersonaType::ULGEN);
        else if (lval == "erlik")       opts_.persona.set_persona(PersonaType::ERLIK);
        else if (lval == "bozkurt")     opts_.persona.set_persona(PersonaType::BOZKURT);
        else if (lval == "tengri")      opts_.persona.set_persona(PersonaType::TENGRI);
        else if (lval == "dedekorkut")  opts_.persona.set_persona(PersonaType::DEDE_KORKUT);
        else if (lval == "umay")        opts_.persona.set_persona(PersonaType::UMAY);
        else                            opts_.persona.set_persona(PersonaType::NONE);
        // Evaluator persona ağırlık çarpanlarını güncelle
        searcher_.evaluator().setPersona(static_cast<int>(opts_.persona.type));
        std::cout << "info string Persona: " << opts_.persona.name() << "\n";
    }
    else if (lname == "psyche") {
        opts_.persona.set_psyche(std::stoi(value));
        std::cout << "info string Psyche (ψ): " << opts_.persona.psyche << "\n";
    }
    else if (lname == "useneedle") {
        opts_.use_needle = (lower(value) == "true");
        if (opts_.use_needle && !opts_.needle_script.empty()) {
            commentary_.set_script(opts_.needle_script);
            std::cout << "info string Needle bridge aktif: " << opts_.needle_script << "\n";
        } else if (opts_.use_needle) {
            std::cout << "info string Needle: NeedleScript yolu ayarlanmamış\n";
        } else {
            std::cout << "info string Needle bridge devre dışı\n";
        }
    }
    else if (lname == "needlescript") {
        opts_.needle_script = value;
        if (opts_.use_needle) {
            commentary_.set_script(value);
            std::cout << "info string Needle script: " << value << "\n";
        }
    }
    else if (lname == "usennue") {
        opts_.use_nnue = (lower(value) == "true");
        if (opts_.use_nnue && !opts_.nnue_path.empty())
            searcher_.evaluator().load_nnue(opts_.nnue_path);
        searcher_.evaluator().set_use_nnue(opts_.use_nnue);
        std::cout << "info string NNUE: " << (opts_.use_nnue ? "aktif" : "devre dışı") << "\n";
    }
    else if (lname == "nnuepath") {
        opts_.nnue_path = value;
        if (opts_.use_nnue) {
            bool ok = searcher_.evaluator().load_nnue(value);
            std::cout << "info string NNUE model: " << value
                      << (ok ? " [yüklendi]" : " [hata — dosya bulunamadı]") << "\n";
        }
    }
    else if (lname == "ownbook") {
        opts_.own_book = (lower(value) == "true");
        if (opts_.own_book && !opts_.book_path.empty() && !book_.loaded()) {
            bool ok = book_.load(opts_.book_path);
            std::cout << "info string OwnBook: " << (ok ? "kitap yüklendi" : "kitap bulunamadı — normal arama kullanılacak")
                      << " (" << opts_.book_path << ")\n";
        } else {
            std::cout << "info string OwnBook: " << (opts_.own_book ? "aktif" : "devre dışı") << "\n";
        }
    }
    else if (lname == "bookfile") {
        opts_.book_path = value;
        if (opts_.own_book) {
            bool ok = book_.load(value);
            std::cout << "info string BookFile: " << value
                      << (ok ? " [yüklendi, " + std::to_string(book_.size()) + " pozisyon]"
                             : " [hata — dosya bulunamadı]") << "\n";
        }
    }
    else {
        std::cout << "info string Bilinmeyen seçenek: " << name << "\n";
    }
}

void UCI::cmd_ponderhit() {
    searcher_.ponderhit();
}

void UCI::cmd_debug_board() {
    std::cout << board_.to_string();
    std::cout << "info string Şah kontrolü: "
              << (board_.in_check() ? "VAR" : "yok") << "\n";
}

void UCI::cmd_debug_eval() {
    Evaluator ev;
    i32 score = ev.evaluate(board_, board_.side_to_move());
    std::cout << "info string Değerlendirme: " << score << " cp ("
              << (board_.side_to_move() == WHITE ? "Beyaz" : "Siyah")
              << " perspektifi)\n";
    i32 mat_w = board_.material(WHITE);
    i32 mat_b = board_.material(BLACK);
    std::cout << "info string Materyal — Beyaz: " << mat_w
              << "  Siyah: " << mat_b
              << "  Fark: " << (mat_w - mat_b) << " cp\n";
}

void UCI::cmd_debug_hash() {
    std::cout << "hash " << board_.hash() << "\n";
}

void UCI::cmd_debug_moves() {
    MoveList ml;
    MoveGenerator::generate_legal(board_, ml);
    std::cout << "info string Yasal hamle sayısı: " << ml.count << "\n";
    for (auto& me : ml) {
        std::cout << "  " << move_to_str(me.move, me.promo);
        Piece victim = board_.piece_on(move_to(me.move));
        if (victim != NO_PIECE)
            std::cout << " x" << PIECE_TYPE_TR[piece_type(victim)];
        if (move_type(me.move) == MT_SWAP)   std::cout << " [swap]";
        if (move_type(me.move) == MT_CITADEL) std::cout << " [citadel=beraberlik]";
        if (move_type(me.move) == MT_PROMO)   std::cout << " [terfi=" << PIECE_TYPE_TR[me.promo] << "]";
        std::cout << "\n";
    }
}

void UCI::cmd_perft(std::istringstream& ss) {
    int depth = 1;
    ss >> depth;

    auto t_start = std::chrono::steady_clock::now();
    u64 nodes = perft(depth);
    auto t_end = std::chrono::steady_clock::now();
    int64_t ms = std::chrono::duration_cast<std::chrono::milliseconds>(t_end - t_start).count();
    u64 nps    = ms > 0 ? nodes * 1000 / ms : nodes;

    std::cout << "Perft(" << depth << ") = " << nodes
              << "  süre: " << ms << "ms"
              << "  NPS: " << nps << "\n";
}

u64 UCI::perft(int depth) {
    if (depth == 0) return 1;

    MoveList ml;
    MoveGenerator::generate_legal(board_, ml);
    if (depth == 1) return ml.count;

    u64 nodes = 0;
    for (auto& me : ml) {
        StateInfo st;
        board_.do_move(me.move, st);
        nodes += perft(depth - 1);
        board_.undo_move(me.move);
    }
    return nodes;
}

// ─────────────────────────────────────────────────────────────────────────────
//  UCI Çıktı Oluşturucular
// ─────────────────────────────────────────────────────────────────────────────
void UCI::print_info(int depth, int sel_depth, i32 score,
                     u64 nodes, int64_t ms, const PVLine& pv,
                     int multi_pv_idx)
{
    std::cout << "info depth " << depth
              << " seldepth " << sel_depth;

    if (multi_pv_idx > 0)
        std::cout << " multipv " << multi_pv_idx;

    // Skor: mat mı yoksa cp mi?
    if (is_mate_score(score)) {
        int plies = mate_in_plies(score);
        std::cout << " score mate " << plies;
    } else {
        std::cout << " score cp " << score;
    }

    u64 nps = (ms > 0) ? nodes * 1000 / ms : 0;
    std::cout << " nodes " << nodes
              << " nps "   << nps
              << " time "  << ms
              << " hashfull " << tt_.hashfull();

    // PV hamleler
    if (pv.length > 0) {
        std::cout << " pv";
        for (int i = 0; i < pv.length; i++)
            std::cout << " " << move_to_str(pv.moves[i]);
    }

    std::cout << "\n";

    // Türkçe taş isimli PV açıklaması (piece_names=tr seçiliyse)
    if (opts_.piece_names == "tr" && pv.length > 0 && depth <= 3) {
        std::cout << "info string PV:";
        for (int i = 0; i < pv.length; i++) {
            Move mv = pv.moves[i];
            Square from = move_from(mv);
            Piece p = board_.piece_on(from);
            if (p != NO_PIECE) {
                PieceType pt = piece_type(p);
                std::cout << " " << PIECE_TYPE_TR[pt]
                          << "(" << move_to_str(mv) << ")";
            } else {
                std::cout << " " << move_to_str(mv);
            }
        }
        std::cout << "\n";
    }
}

void UCI::print_bestmove(Move best, Move ponder) {
    std::cout << "bestmove " << move_to_str(best);
    if (ponder != MOVE_NONE && opts_.ponder)
        std::cout << " ponder " << move_to_str(ponder);
    std::cout << "\n";
}

void UCI::apply_options() {
    // Seçenekler değiştiğinde motoru güncelle
    // (thread sayısı, contempt vb. — Faz 2'de genişletilecek)
}

} // namespace Apex
