#include "board.h"
#include "tt.h"
#include <sstream>
#include <iomanip>
#include <cstring>
#include <cassert>

namespace Apex {

// ─────────────────────────────────────────────────────────────────────────────
//  Board — Kurucu
// ─────────────────────────────────────────────────────────────────────────────
Board::Board() : stm_(WHITE), fullmove_(1), st_(nullptr), st_idx_(0) {
    std::memset(mailbox_, 0, sizeof(mailbox_));
    std::memset(king_sq_, 0, sizeof(king_sq_));
    king_sq_[WHITE] = SQ_NONE;
    king_sq_[BLACK] = SQ_NONE;
    // StateInfo başlangıcı (sadece kök durum kullanılır)
    st_buf_[0] = StateInfo{};
    st_ = &st_buf_[0];
    st_->hash       = 0;
    st_->pawn_hash  = 0;
    st_->enpassant  = SQ_NONE;
    st_->halfmove   = 0;
    st_->swap_used[WHITE] = false;
    st_->swap_used[BLACK] = false;
    st_->captured   = NO_PIECE;
    st_->last_move  = MOVE_NONE;
    st_->prev       = nullptr;
    st_->material[WHITE] = 0;
    st_->material[BLACK] = 0;
}

// ─────────────────────────────────────────────────────────────────────────────
//  Kopya kurucu / atama — st_ işaretçisi st_buf_'a yeniden bağlanır
// ─────────────────────────────────────────────────────────────────────────────
Board& Board::operator=(const Board& other) {
    if (this == &other) return *this;
    std::memcpy(mailbox_, other.mailbox_, sizeof(mailbox_));
    king_sq_[0] = other.king_sq_[0];
    king_sq_[1] = other.king_sq_[1];
    stm_        = other.stm_;
    fullmove_   = other.fullmove_;
    st_idx_     = other.st_idx_;
    for (int c = 0; c < 2; c++)
        for (int pt = 0; pt < PIECE_TYPE_NB; pt++)
            piece_list_[c][pt] = other.piece_list_[c][pt];
    std::memcpy(st_buf_, other.st_buf_, sizeof(st_buf_));
    // st_ işaretçisini kendi st_buf_'a yeniden bağla
    st_ = st_buf_ + (other.st_ - other.st_buf_);
    // prev zincirleri: başka Board'ın st_buf_'ını işaret etmesin
    for (int i = 0; i <= st_idx_; i++) {
        if (other.st_buf_[i].prev != nullptr) {
            ptrdiff_t offset = other.st_buf_[i].prev - other.st_buf_;
            st_buf_[i].prev = st_buf_ + offset;
        }
    }
    return *this;
}

Board::Board(const Board& other) : Board() { *this = other; }

// ─────────────────────────────────────────────────────────────────────────────
//  Yardımcı: taş koy / kaldır / taşı
// ─────────────────────────────────────────────────────────────────────────────
void Board::put_piece(Piece p, Square sq) {
    assert(sq < BOARD_SIZE);
    assert(mailbox_[sq] == NO_PIECE);
    mailbox_[sq] = p;

    PieceType pt = piece_type(p);
    Color     c  = piece_color(p);
    piece_list_[c][pt].push_back(sq);

    if (pt == SAH) king_sq_[c] = sq;

    // Materyal güncelle
    st_->material[c] += PIECE_VALUE[pt];

    // Zobrist güncelle
    st_->hash ^= Zobrist.piece[sq][pt][c];
    if (pt == PIYON) st_->pawn_hash ^= Zobrist.piece[sq][pt][c];
}

void Board::remove_piece(Square sq) {
    assert(sq < BOARD_SIZE);
    Piece p = mailbox_[sq];
    assert(p != NO_PIECE);

    PieceType pt = piece_type(p);
    Color     c  = piece_color(p);

    // piece_list'ten çıkar (swap-and-pop — O(1))
    auto& lst = piece_list_[c][pt];
    for (int i = 0; i < (int)lst.size(); i++) {
        if (lst[i] == sq) {
            lst[i] = lst.back();
            lst.pop_back();
            break;
        }
    }

    mailbox_[sq] = NO_PIECE;
    st_->material[c] -= PIECE_VALUE[pt];
    st_->hash ^= Zobrist.piece[sq][pt][c];
    if (pt == PIYON) st_->pawn_hash ^= Zobrist.piece[sq][pt][c];
}

void Board::move_piece(Square from, Square to) {
    assert(from < BOARD_SIZE && to < BOARD_SIZE);
    Piece p = mailbox_[from];
    assert(p != NO_PIECE);

    PieceType pt = piece_type(p);
    Color     c  = piece_color(p);

    // piece_list güncelle
    auto& lst = piece_list_[c][pt];
    for (auto& s : lst) {
        if (s == from) { s = to; break; }
    }

    mailbox_[from] = NO_PIECE;
    mailbox_[to]   = p;

    if (pt == SAH) king_sq_[c] = to;

    // Zobrist güncelle
    st_->hash ^= Zobrist.piece[from][pt][c];
    st_->hash ^= Zobrist.piece[to][pt][c];
    if (pt == PIYON) {
        st_->pawn_hash ^= Zobrist.piece[from][pt][c];
        st_->pawn_hash ^= Zobrist.piece[to][pt][c];
    }
}

// ─────────────────────────────────────────────────────────────────────────────
//  Başlangıç Pozisyonu
//
//  Tarihsel Timurlenk düzeni (rank 0 = beyaz alt, rank 9 = siyah üst):
//
//  rank 9 (siyah ek sıra): Fil . Deve . SavaşM . SavaşM . Deve . Fil
//  rank 8 (siyah ana sıra): Kale-At-Talia-Zürafa-Vali-Şah-Ferz-Zürafa-Talia-At-Kale
//  rank 7 (siyah piyonlar): 11× Piyon
//  rank 6–3: boş
//  rank 2 (beyaz piyonlar): 11× Piyon
//  rank 1 (beyaz ana sıra): Kale-At-Talia-Zürafa-Ferz-Şah-Vali-Zürafa-Talia-At-Kale
//  rank 0 (beyaz ek sıra):  Fil . Deve . SavaşM . SavaşM . Deve . Fil
//
//  Citadel:
//    WHITE_CITADEL (110): k2 sağında (rank=1, file=11) — başlangıçta boş
//    BLACK_CITADEL (111): a9 solunda (rank=8, file=-1) — başlangıçta boş
// ─────────────────────────────────────────────────────────────────────────────
void Board::setup() {
    // Sıfırla
    std::memset(mailbox_, 0, sizeof(mailbox_));
    for (int c = 0; c < 2; c++)
        for (int pt = 0; pt < PIECE_TYPE_NB; pt++)
            piece_list_[c][pt].clear();
    king_sq_[WHITE] = king_sq_[BLACK] = SQ_NONE;
    stm_      = WHITE;
    fullmove_ = 1;
    st_idx_   = 0;
    st_buf_[0] = StateInfo{};
    st_       = &st_buf_[0];
    st_->enpassant = SQ_NONE;
    st_->swap_used[WHITE] = st_->swap_used[BLACK] = false;

    // ── Beyaz Ek Sıra (rank 0): Fil . Deve . SavaşM . SavaşM . Deve . Fil
    // file: 0   1     2     3      4        5      6       7    8     9    10
    //       Fil  -   Deve   -    SavaşM    -    SavaşM    -   Deve   -   Fil
    static const int extra_files[]  = { 0, 2, 4, 6, 8, 10 };
    static const PieceType extra_pt[] = { FIL, DEVE, SAVAS, SAVAS, DEVE, FIL };
    for (int i = 0; i < 6; i++) {
        put_piece(make_piece(WHITE, extra_pt[i]), make_sq(extra_files[i], 0));
        put_piece(make_piece(BLACK, extra_pt[i]), make_sq(extra_files[i], 9));
    }

    // ── Beyaz Ana Sıra (rank 1)
    // Kale-At-Talia-Zürafa-Ferz-Şah-Vali-Zürafa-Talia-At-Kale
    for (int f = 0; f < BOARD_FILES; f++) {
        put_piece(make_piece(WHITE, START_RANK1_WHITE[f]), make_sq(f, 1));
    }

    // ── Siyah Ana Sıra (rank 8) — Ferz ve Vali yer değiştirmiş
    for (int f = 0; f < BOARD_FILES; f++) {
        put_piece(make_piece(BLACK, START_RANK1_BLACK[f]), make_sq(f, 8));
    }

    // ── Piyonlar (rank 2 = beyaz, rank 7 = siyah)
    for (int f = 0; f < BOARD_FILES; f++) {
        put_piece(make_piece(WHITE, PIYON), make_sq(f, 2));
        put_piece(make_piece(BLACK, PIYON), make_sq(f, 7));
    }

    // ── Zobrist: sıra beyazsa ekstra hash gerekmez (seed başlangıç değeri)
    // Siyah oynarsa Zobrist.side XOR'lanacak
}

// ─────────────────────────────────────────────────────────────────────────────
//  do_move — hamleyi uygula
// ─────────────────────────────────────────────────────────────────────────────
void Board::do_move(Move m, StateInfo& new_st, PieceType promo) {
    assert(move_ok(m));

    // StateInfo kopyala (undo için önceki durumu sakla)
    new_st        = *st_;
    new_st.prev   = st_;
    new_st.last_move = m;
    st_           = &new_st;
    st_->halfmove++;
    // Mobilite cache'i geçersiz kıl — yeni pozisyon için yeniden hesaplanacak
    st_->mobility_valid[0] = false;
    st_->mobility_valid[1] = false;

    Square from = move_from(m);
    Square to   = move_to(m);
    MoveType mt = move_type(m);

    Piece  moving  = mailbox_[from];
    Piece  target  = (to < BOARD_NORMAL) ? mailbox_[to] : NO_PIECE;
    Color  us      = stm_;
    Color  them    = ~us;

    st_->captured = target;

    // Yakalama varsa taşı kaldır (swap hamlelerinde to'da kendi taşımız var — kaldırma!)
    if (target != NO_PIECE && mt != MT_SWAP) {
        remove_piece(to);
        st_->halfmove = 0; // Yeme → 50-hamle sayacı sıfırla
    }

    // ── Özel hamle tipleri ────────────────────────────────────────────────
    if (mt == MT_SWAP) {
        // Yer değiştirme: şah from'da, to'daki kendi taşıyla yer değiştirir
        // Swap hakkı henüz kullanılmamış olmalı
        assert(!st_->swap_used[us]);
        Piece other = mailbox_[to];
        assert(other != NO_PIECE && piece_color(other) == us);
        // Yer değiştir: şah → to, diğer taş → from
        mailbox_[from] = other;
        mailbox_[to]   = moving;
        // king_sq güncelle
        if (piece_type(moving) == SAH) king_sq_[us] = to;
        // Hash güncelle (from ve to için her iki taş)
        st_->hash ^= Zobrist.piece[from][piece_type(moving)][us];
        st_->hash ^= Zobrist.piece[to  ][piece_type(moving)][us];
        st_->hash ^= Zobrist.piece[from][piece_type(other)][us];
        st_->hash ^= Zobrist.piece[to  ][piece_type(other)][us];
        // piece_list güncelle
        for (auto& s : piece_list_[us][piece_type(moving)])
            if (s == from) { s = to;   break; }
        for (auto& s : piece_list_[us][piece_type(other)])
            if (s == to)   { s = from; break; }
        st_->swap_used[us] = true;
        st_->hash ^= Zobrist.swap_used[us];

    } else if (mt == MT_CITADEL) {
        // Citadel girişi: şah citadel'e giriyor (beraberlik)
        move_piece(from, to);

    } else if (mt == MT_PROMO) {
        PieceType pt = (promo != NO_PIECE_TYPE) ? promo : KALE;
        remove_piece(from);
        put_piece(make_piece(us, pt), to);
        st_->halfmove = 0;

    } else {
        // Normal hamle
        move_piece(from, to);
        if (piece_type(moving) == PIYON) st_->halfmove = 0;
    }

    // ── NNUE artımlı akümülatör güncelleme ───────────────────────────────
    if (nnue_net_ && nnue_net_->loaded() && new_st.prev && new_st.prev->acc_valid) {
        new_st.acc = new_st.prev->acc;
        if (mt == MT_SWAP) {
            // Şah from→to, diğer taş to→from (ikisi de bizim renk)
            nnue_net_->remove_piece_from_acc(new_st.acc, us, piece_type(moving), from);
            nnue_net_->remove_piece_from_acc(new_st.acc, us, piece_type(target), to);
            nnue_net_->add_piece(new_st.acc, us, piece_type(moving), to);
            nnue_net_->add_piece(new_st.acc, us, piece_type(target), from);
        } else if (mt == MT_PROMO) {
            PieceType promo_pt = (promo != NO_PIECE_TYPE) ? promo : KALE;
            nnue_net_->remove_piece_from_acc(new_st.acc, us, PIYON, from);
            if (target != NO_PIECE)
                nnue_net_->remove_piece_from_acc(new_st.acc, them, piece_type(target), to);
            nnue_net_->add_piece(new_st.acc, us, promo_pt, to);
        } else {
            // Normal + Citadel
            nnue_net_->remove_piece_from_acc(new_st.acc, us, piece_type(moving), from);
            if (target != NO_PIECE)
                nnue_net_->remove_piece_from_acc(new_st.acc, them, piece_type(target), to);
            nnue_net_->add_piece(new_st.acc, us, piece_type(moving), to);
        }
        new_st.acc_valid = true;
    } else {
        new_st.acc_valid = false;
    }

    // ── Sıra değiştir ─────────────────────────────────────────────────────
    stm_ = them;
    st_->hash ^= Zobrist.side;

    if (us == BLACK) fullmove_++;
}

// ─────────────────────────────────────────────────────────────────────────────
//  refresh_nnue_acc — kök akümülatörü sıfırla (artımlı güncelleme başlangıcı)
// ─────────────────────────────────────────────────────────────────────────────
void Board::refresh_nnue_acc() {
    if (!nnue_net_ || !nnue_net_->loaded() || !st_) return;
    st_->acc.reset(nnue_net_->b1());
    for (int r = 0; r < BOARD_RANKS; r++) {
        for (int f = 0; f < BOARD_FILES; f++) {
            Square sq = make_sq(f, r);
            Piece p = piece_on(sq);
            if (p == NO_PIECE) continue;
            nnue_net_->add_piece(st_->acc, piece_color(p), piece_type(p), sq);
        }
    }
    st_->acc_valid = true;
}

// ─────────────────────────────────────────────────────────────────────────────
//  undo_move — hamleyi geri al
// ─────────────────────────────────────────────────────────────────────────────
void Board::undo_move(Move m) {
    stm_   = ~stm_;
    Color  us   = stm_;
    Square from = move_from(m);
    Square to   = move_to(m);
    MoveType mt = move_type(m);

    if (us == BLACK) fullmove_--;

    if (mt == MT_SWAP) {
        // Yer değiştirmeyi geri al
        Piece at_to   = mailbox_[to];   // şah
        Piece at_from = mailbox_[from]; // diğer taş
        mailbox_[from] = at_to;
        mailbox_[to]   = at_from;
        if (piece_type(at_to) == SAH) king_sq_[us] = from;
        for (auto& s : piece_list_[us][piece_type(at_to)])
            if (s == to) { s = from; break; }
        for (auto& s : piece_list_[us][piece_type(at_from)])
            if (s == from) { s = to; break; }

    } else if (mt == MT_PROMO) {
        // Terfiyi geri al
        remove_piece(to);
        put_piece(make_piece(us, PIYON), from);
        // Yakalanan taş varsa geri koy
        if (st_->captured != NO_PIECE)
            put_piece(st_->captured, to);

    } else {
        // Normal ve citadel hamleler
        move_piece(to, from);
        if (st_->captured != NO_PIECE)
            put_piece(st_->captured, to);
    }

    st_ = st_->prev;
}

// ─────────────────────────────────────────────────────────────────────────────
//  Null Move (NMP için)
// ─────────────────────────────────────────────────────────────────────────────
void Board::do_null_move(StateInfo& new_st) {
    new_st        = *st_;
    new_st.prev   = st_;
    new_st.last_move = MOVE_NULL;
    new_st.captured  = NO_PIECE;
    st_           = &new_st;

    stm_          = ~stm_;
    st_->hash    ^= Zobrist.side;
    st_->halfmove++;
    st_->mobility_valid[0] = false;
    st_->mobility_valid[1] = false;
}

void Board::undo_null_move() {
    stm_ = ~stm_;
    st_  = st_->prev;
}

// ─────────────────────────────────────────────────────────────────────────────
//  Saldırı Tespiti
//  is_attacked(sq, by): 'sq' karesi 'by' rengi tarafından tehdit altında mı?
// ─────────────────────────────────────────────────────────────────────────────

// Yardımcı: tahta sınırı kontrolü
static inline bool in_bounds(int f, int r) {
    return f >= 0 && f < BOARD_FILES && r >= 0 && r < BOARD_RANKS;
}

bool Board::is_attacked(Square sq, Color by) const {
    if (sq >= BOARD_NORMAL) return false; // Citadel'e saldırı yok

    // Her taş tipini sırayla kontrol et
    return attacked_by_sah   (sq, by)
        || attacked_by_kale  (sq, by)
        || attacked_by_zurafa(sq, by)
        || attacked_by_talia (sq, by)
        || attacked_by_at    (sq, by)
        || attacked_by_deve  (sq, by)
        || attacked_by_fil   (sq, by)
        || attacked_by_savas (sq, by)
        || attacked_by_ferz  (sq, by)
        || attacked_by_vali  (sq, by)
        || attacked_by_piyon (sq, by);
}

// ── Şah saldırısı: 8 yönde 1 kare ──────────────────────────────────────────
bool Board::attacked_by_sah(Square sq, Color by) const {
    int f = sq_file(sq), r = sq_rank(sq);
    static const int dx[] = {-1,-1,-1, 0, 0, 1, 1, 1};
    static const int dy[] = {-1, 0, 1,-1, 1,-1, 0, 1};
    for (int i = 0; i < 8; i++) {
        int nf = f + dx[i], nr = r + dy[i];
        if (in_bounds(nf, nr)) {
            Square s = make_sq(nf, nr);
            Piece  p = mailbox_[s];
            if (p != NO_PIECE && piece_color(p) == by && piece_type(p) == SAH)
                return true;
        }
    }
    return false;
}

// ── Kale saldırısı: yatay/dikey kayma ──────────────────────────────────────
bool Board::attacked_by_kale(Square sq, Color by) const {
    int f = sq_file(sq), r = sq_rank(sq);
    static const int dx[] = { 1,-1, 0, 0};
    static const int dy[] = { 0, 0, 1,-1};
    for (int d = 0; d < 4; d++) {
        int nf = f + dx[d], nr = r + dy[d];
        while (in_bounds(nf, nr)) {
            Square s = make_sq(nf, nr);
            Piece  p = mailbox_[s];
            if (p != NO_PIECE) {
                if (piece_color(p) == by && piece_type(p) == KALE) return true;
                break; // engel
            }
            nf += dx[d]; nr += dy[d];
        }
    }
    return false;
}

// ── Zürafa saldırısı: çapraz 1 + düz min 3 ─────────────────────────────────
bool Board::attacked_by_zurafa(Square sq, Color by) const {
    int f = sq_file(sq), r = sq_rank(sq);
    static const int cdx[] = {1,1,-1,-1};
    static const int cdy[] = {1,-1,1,-1};
    static const int sdx[] = {1,-1,0,0};
    static const int sdy[] = {0,0,1,-1};

    for (Square zsq : piece_list_[by][ZURAFA]) {
        int zf = sq_file(zsq), zr = sq_rank(zsq);
        // Çapraz 1 adım
        for (int cd = 0; cd < 4; cd++) {
            int mf = zf + cdx[cd], mr = zr + cdy[cd];
            if (!in_bounds(mf, mr)) continue;
            if (mailbox_[make_sq(mf, mr)] != NO_PIECE) continue;
            // Düz devam
            for (int sd = 0; sd < 4; sd++) {
                bool ok = true;
                for (int step = 1; step <= 3; step++) {
                    int tf = mf + sdx[sd]*step, tr = mr + sdy[sd]*step;
                    if (!in_bounds(tf, tr)) { ok = false; break; }
                    if (step < 3 && mailbox_[make_sq(tf, tr)] != NO_PIECE) { ok = false; break; }
                    if (step == 3 && tf == f && tr == r) return true;
                }
                if (!ok) continue;
                // 3'ten fazla adım da olabilir
                for (int step = 4; ; step++) {
                    int tf = mf + sdx[sd]*step, tr = mr + sdy[sd]*step;
                    if (!in_bounds(tf, tr)) break;
                    if (tf == f && tr == r) return true;
                    if (mailbox_[make_sq(tf, tr)] != NO_PIECE) break;
                }
            }
        }
    }
    return false;
}

// ── Talia: yatay/dikey tam 2 sıçrama ────────────────────────────────────────
bool Board::attacked_by_talia(Square sq, Color by) const {
    int f = sq_file(sq), r = sq_rank(sq);
    static const int dx[] = { 2,-2, 0, 0};
    static const int dy[] = { 0, 0, 2,-2};
    for (int i = 0; i < 4; i++) {
        int nf = f + dx[i], nr = r + dy[i];
        if (!in_bounds(nf, nr)) continue;
        Square s = make_sq(nf, nr);
        Piece  p = mailbox_[s];
        if (p != NO_PIECE && piece_color(p) == by && piece_type(p) == TALIA)
            return true;
    }
    return false;
}

// ── At: L şekli (2+1) ──────────────────────────────────────────────────────
bool Board::attacked_by_at(Square sq, Color by) const {
    int f = sq_file(sq), r = sq_rank(sq);
    static const int dx[] = {2,2,-2,-2,1,1,-1,-1};
    static const int dy[] = {1,-1,1,-1,2,-2,2,-2};
    for (int i = 0; i < 8; i++) {
        int nf = f + dx[i], nr = r + dy[i];
        if (!in_bounds(nf, nr)) continue;
        Square s = make_sq(nf, nr);
        Piece  p = mailbox_[s];
        if (p != NO_PIECE && piece_color(p) == by && piece_type(p) == AT)
            return true;
    }
    return false;
}

// ── Deve: (1,3) atlama ──────────────────────────────────────────────────────
bool Board::attacked_by_deve(Square sq, Color by) const {
    int f = sq_file(sq), r = sq_rank(sq);
    static const int dx[] = {3,3,-3,-3,1,1,-1,-1};
    static const int dy[] = {1,-1,1,-1,3,-3,3,-3};
    for (int i = 0; i < 8; i++) {
        int nf = f + dx[i], nr = r + dy[i];
        if (!in_bounds(nf, nr)) continue;
        Square s = make_sq(nf, nr);
        Piece  p = mailbox_[s];
        if (p != NO_PIECE && piece_color(p) == by && piece_type(p) == DEVE)
            return true;
    }
    return false;
}

// ── Fil: çapraz 2 sıçrama ───────────────────────────────────────────────────
bool Board::attacked_by_fil(Square sq, Color by) const {
    int f = sq_file(sq), r = sq_rank(sq);
    static const int dx[] = { 2,-2, 2,-2};
    static const int dy[] = { 2, 2,-2,-2};
    for (int i = 0; i < 4; i++) {
        int nf = f + dx[i], nr = r + dy[i];
        if (!in_bounds(nf, nr)) continue;
        Square s = make_sq(nf, nr);
        Piece  p = mailbox_[s];
        if (p != NO_PIECE && piece_color(p) == by && piece_type(p) == FIL)
            return true;
    }
    return false;
}

// ── Savaş Makinesi: yatay/dikey 2 sıçrama ───────────────────────────────────
bool Board::attacked_by_savas(Square sq, Color by) const {
    int f = sq_file(sq), r = sq_rank(sq);
    static const int dx[] = { 2,-2, 0, 0};
    static const int dy[] = { 0, 0, 2,-2};
    for (int i = 0; i < 4; i++) {
        int nf = f + dx[i], nr = r + dy[i];
        if (!in_bounds(nf, nr)) continue;
        Square s = make_sq(nf, nr);
        Piece  p = mailbox_[s];
        if (p != NO_PIECE && piece_color(p) == by && piece_type(p) == SAVAS)
            return true;
    }
    return false;
}

// ── Ferz: çapraz 1 kare ─────────────────────────────────────────────────────
bool Board::attacked_by_ferz(Square sq, Color by) const {
    int f = sq_file(sq), r = sq_rank(sq);
    static const int dx[] = { 1,-1, 1,-1};
    static const int dy[] = { 1, 1,-1,-1};
    for (int i = 0; i < 4; i++) {
        int nf = f + dx[i], nr = r + dy[i];
        if (!in_bounds(nf, nr)) continue;
        Square s = make_sq(nf, nr);
        Piece  p = mailbox_[s];
        if (p != NO_PIECE && piece_color(p) == by && piece_type(p) == FERZ)
            return true;
    }
    return false;
}

// ── Vali: yatay/dikey 1 kare ────────────────────────────────────────────────
bool Board::attacked_by_vali(Square sq, Color by) const {
    int f = sq_file(sq), r = sq_rank(sq);
    static const int dx[] = { 1,-1, 0, 0};
    static const int dy[] = { 0, 0, 1,-1};
    for (int i = 0; i < 4; i++) {
        int nf = f + dx[i], nr = r + dy[i];
        if (!in_bounds(nf, nr)) continue;
        Square s = make_sq(nf, nr);
        Piece  p = mailbox_[s];
        if (p != NO_PIECE && piece_color(p) == by && piece_type(p) == VALI)
            return true;
    }
    return false;
}

// ── Piyon saldırısı: çapraz ileri yeme ──────────────────────────────────────
bool Board::attacked_by_piyon(Square sq, Color by) const {
    int f = sq_file(sq), r = sq_rank(sq);
    // Beyaz piyon: rank+1 yönünde gider, yani rank-1'den saldırır
    // Siyah piyon: rank-1 yönünde gider, yani rank+1'den saldırır
    int attack_rank = (by == WHITE) ? r - 1 : r + 1;
    if (!in_bounds(f-1, attack_rank)) {
        // sol kontrol
    } else {
        Piece p = mailbox_[make_sq(f-1, attack_rank)];
        if (p != NO_PIECE && piece_color(p) == by && piece_type(p) == PIYON)
            return true;
    }
    if (!in_bounds(f+1, attack_rank)) {
        // sağ kontrol
    } else {
        Piece p = mailbox_[make_sq(f+1, attack_rank)];
        if (p != NO_PIECE && piece_color(p) == by && piece_type(p) == PIYON)
            return true;
    }
    return false;
}

// ─────────────────────────────────────────────────────────────────────────────
//  Özel Kontroller
// ─────────────────────────────────────────────────────────────────────────────
bool Board::is_citadel_move(Move m) const {
    return move_type(m) == MT_CITADEL;
}

bool Board::is_repetition(int count) const {
    int reps = 0;
    const StateInfo* s = st_->prev;
    u64 h = st_->hash;
    while (s && s->prev) {
        if (s->hash == h) {
            if (++reps >= count - 1) return true;
        }
        if (s->halfmove == 0) break; // yeme/piyon → tekrar mümkün değil
        s = s->prev->prev; // Her 2 hamlede bir kontrol (aynı sıra)
    }
    return false;
}

static bool has_mating_material(const Board& b, Color c) {
    // Şah + Ferz veya Vali dışında herhangi bir taş varsa mat mümkün
    for (int pt = KALE; pt <= PIYON; pt++) {
        if (pt == FERZ || pt == VALI) continue;
        if (!b.pieces(c, (PieceType)pt).empty()) return true;
    }
    // Sadece Ferz veya Vali ile mat zor ama mümkün — mat materyali var say
    if (!b.pieces(c, FERZ).empty()) return true;
    if (!b.pieces(c, VALI).empty()) return true;
    return false;
}

Board::GameResult Board::game_over() const {
    // Tekrar
    if (is_repetition(3)) return DRAW;
    // 50-hamle kuralı
    if (st_->halfmove >= 100) return DRAW;
    // Citadel beraberliği
    if (king_sq_[WHITE] == BLACK_CITADEL) return DRAW;
    if (king_sq_[BLACK] == WHITE_CITADEL) return DRAW;
    // Yetersiz materyal: her iki tarafta da sadece şah
    bool w_mat = has_mating_material(*this, WHITE);
    bool b_mat = has_mating_material(*this, BLACK);
    if (!w_mat && !b_mat) return DRAW;
    // Mat/Pat — hamle üretici gerekir, search tarafından kontrol edilir
    return ONGOING;
}

// ─────────────────────────────────────────────────────────────────────────────
//  Debug Çıktısı
// ─────────────────────────────────────────────────────────────────────────────
std::string Board::to_string() const {
    std::ostringstream oss;
    // Taş sembolleri
    auto piece_char = [](Piece p) -> char {
        if (p == NO_PIECE) return '.';
        PieceType pt = piece_type(p);
        Color c      = piece_color(p);
        char ch = (pt == SAVAS) ? 'W' : (pt <= PIYON ? "KRZTNCEWFVP"[pt-1] : '?');
        return (c == BLACK) ? (char)(ch + 32) : ch;
    };

    oss << "\n   +";
    for (int f = 0; f < BOARD_FILES; f++) oss << "----";
    oss << "-+    [Citadel]\n";

    for (int r = BOARD_RANKS - 1; r >= 0; r--) {
        oss << std::setw(2) << (r+1) << " |";
        for (int f = 0; f < BOARD_FILES; f++) {
            Piece p = mailbox_[make_sq(f, r)];
            oss << "  " << piece_char(p) << " ";
        }
        oss << " |";
        if (r == 8) oss << "  [←BC] Black Citadel";
        if (r == 1) oss << "  White Citadel [→WC]";
        oss << "\n";
    }

    oss << "   +";
    for (int f = 0; f < BOARD_FILES; f++) oss << "----";
    oss << "-+\n     ";
    for (int f = 0; f < BOARD_FILES; f++) {
        oss << "  " << (char)('a' + f) << " ";
    }
    oss << "\n";
    oss << "Sıra: " << (stm_ == WHITE ? "Beyaz" : "Siyah");
    oss << "  |  Hash: " << std::hex << st_->hash << std::dec;
    oss << "  |  Hamle: " << fullmove_;
    oss << "  |  50-hamle: " << (int)st_->halfmove;
    oss << "\n";
    oss << "Swap: Beyaz=" << (st_->swap_used[WHITE] ? "kullandı" : "var")
        << "  Siyah=" << (st_->swap_used[BLACK] ? "kullandı" : "var") << "\n";
    return oss.str();
}

// ─────────────────────────────────────────────────────────────────────────────
//  FEN Parsing — Timurlenk FEN Format:
//  <board> <renk> <swap> <ep> <halfmove> <fullmove>
//  Taş sembolleri: K=Şah R=Kale Z=Zürafa T=Talia N=At C=Deve
//                  E=Fil W=SavaşM F=Ferz V=Vali P=Piyon
//  Board: rank10/rank9/.../rank1  (boşluk=sayı)
//  Swap: "-" yok, "w" beyaz hakkı var, "b" siyah hakkı var
// ─────────────────────────────────────────────────────────────────────────────
bool Board::from_string(const std::string& s) {
    std::istringstream ss(s);
    std::string board_str, color_str, swap_str, ep_str;
    int halfmove = 0, fullmove = 1;

    if (!(ss >> board_str >> color_str >> swap_str >> ep_str >> halfmove >> fullmove))
        return false;

    // Tahtayı sıfırla
    for (int sq = 0; sq < BOARD_SIZE; sq++) mailbox_[sq] = NO_PIECE;
    for (auto& vv : piece_list_) for (auto& v : vv) v.clear();
    king_sq_[WHITE] = SQ_NONE;
    king_sq_[BLACK] = SQ_NONE;

    auto char_to_pt = [](char c) -> PieceType {
        switch (std::toupper((unsigned char)c)) {
            case 'K': return SAH;   case 'R': return KALE;  case 'Z': return ZURAFA;
            case 'T': return TALIA; case 'N': return AT;    case 'C': return DEVE;
            case 'E': return FIL;   case 'W': return SAVAS; case 'F': return FERZ;
            case 'V': return VALI;  case 'P': return PIYON;
            default:  return NO_PIECE_TYPE;
        }
    };

    // Board: rank10/rank9/.../rank1
    int rank = BOARD_RANKS - 1;
    int file = 0;
    for (char ch : board_str) {
        if (ch == '/') { rank--; file = 0; continue; }
        if (rank < 0) break;
        if (std::isdigit((unsigned char)ch)) {
            file += (ch - '0');
        } else {
            PieceType pt = char_to_pt(ch);
            if (pt == NO_PIECE_TYPE) return false;
            if (file >= BOARD_FILES) return false;
            Color c = std::isupper((unsigned char)ch) ? WHITE : BLACK;
            put_piece(make_piece(c, pt), make_sq(file, rank));
            file++;
        }
    }

    stm_ = (color_str == "b") ? BLACK : WHITE;

    st_idx_ = 0;
    st_ = &st_buf_[0];
    *st_ = StateInfo{};
    st_->enpassant        = SQ_NONE;
    st_->halfmove         = static_cast<u8>(halfmove);
    st_->swap_used[WHITE] = (swap_str.find('w') == std::string::npos);
    st_->swap_used[BLACK] = (swap_str.find('b') == std::string::npos);
    st_->captured         = NO_PIECE;
    st_->last_move        = MOVE_NONE;
    st_->prev             = nullptr;

    if (ep_str != "-" && ep_str.size() >= 2) {
        int ef = ep_str[0] - 'a';
        int er = std::stoi(ep_str.substr(1)) - 1;
        if (ef >= 0 && ef < BOARD_FILES && er >= 0 && er < BOARD_RANKS)
            st_->enpassant = make_sq(ef, er);
    }

    st_->material[WHITE] = st_->material[BLACK] = 0;
    for (int sq = 0; sq < BOARD_NORMAL; sq++) {
        Piece p = mailbox_[sq];
        if (p != NO_PIECE)
            st_->material[piece_color(p)] += PIECE_VALUE[piece_type(p)];
    }

    // Zobrist hash hesapla
    st_->hash = st_->pawn_hash = 0;
    for (int sq = 0; sq < BOARD_SIZE; sq++) {
        Piece p = mailbox_[sq];
        if (p != NO_PIECE) {
            Color c = piece_color(p); PieceType pt = piece_type(p);
            st_->hash ^= Zobrist.piece[sq][pt][c];
            if (pt == PIYON) st_->pawn_hash ^= Zobrist.piece[sq][pt][c];
        }
    }
    if (stm_ == BLACK)              st_->hash ^= Zobrist.side;
    if (st_->swap_used[WHITE])      st_->hash ^= Zobrist.swap_used[WHITE];
    if (st_->swap_used[BLACK])      st_->hash ^= Zobrist.swap_used[BLACK];

    fullmove_ = fullmove;
    return true;
}

std::string Board::to_fen() const {
    std::ostringstream oss;
    auto pt_to_char = [](PieceType pt, Color c) -> char {
        char ch = '?';
        switch (pt) {
            case SAH:    ch = 'K'; break; case KALE:   ch = 'R'; break;
            case ZURAFA: ch = 'Z'; break; case TALIA:  ch = 'T'; break;
            case AT:     ch = 'N'; break; case DEVE:   ch = 'C'; break;
            case FIL:    ch = 'E'; break; case SAVAS:  ch = 'W'; break;
            case FERZ:   ch = 'F'; break; case VALI:   ch = 'V'; break;
            case PIYON:  ch = 'P'; break; default:     ch = '?'; break;
        }
        return (c == BLACK) ? (char)std::tolower((unsigned char)ch) : ch;
    };

    for (int r = BOARD_RANKS - 1; r >= 0; r--) {
        int empty = 0;
        for (int f = 0; f < BOARD_FILES; f++) {
            Piece p = mailbox_[make_sq(f, r)];
            if (p == NO_PIECE) { empty++; }
            else {
                if (empty > 0) { oss << empty; empty = 0; }
                oss << pt_to_char(piece_type(p), piece_color(p));
            }
        }
        if (empty > 0) oss << empty;
        if (r > 0) oss << '/';
    }

    oss << ' ' << (stm_ == WHITE ? 'w' : 'b');

    std::string sw;
    if (!st_->swap_used[WHITE]) sw += 'w';
    if (!st_->swap_used[BLACK]) sw += 'b';
    oss << ' ' << (sw.empty() ? "-" : sw);

    Square ep = st_->enpassant;
    if (ep == SQ_NONE) oss << " -";
    else oss << ' ' << (char)('a' + sq_file(ep)) << (sq_rank(ep) + 1);

    oss << ' ' << (int)st_->halfmove << ' ' << fullmove_;
    return oss.str();
}

} // namespace Apex

namespace Apex {

bool Board::gives_check(Move m) const {
    // Hamle yapıldıktan sonra rakip şahı tehdit altına alıyor mu?
    Board& self = const_cast<Board&>(*this);
    // Arama stack'inde değil, yerel buffer kullan
    static thread_local StateInfo gc_st;
    self.do_move(m, gc_st);
    Color them = self.stm_; // do_move sonrası sıra değişti
    bool check = self.is_attacked(self.king_sq(them), ~them);
    self.undo_move(m);
    return check;
}

} // namespace Apex
