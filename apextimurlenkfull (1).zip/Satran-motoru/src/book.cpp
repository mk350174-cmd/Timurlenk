#include "book.h"
#include <fstream>
#include <cstring>
#include <random>

namespace Apex {

// ─────────────────────────────────────────────────────────────────────────────
//  OpeningBook::load — APEX binary format v3 okur
// ─────────────────────────────────────────────────────────────────────────────
bool OpeningBook::load(const std::string& path) {
    std::ifstream f(path, std::ios::binary);
    if (!f) return false;

    // Magic kontrolü
    char magic[4];
    f.read(magic, 4);
    if (!f || std::strncmp(magic, "APEX", 4) != 0) return false;

    // Versiyon kontrolü
    uint32_t version;
    f.read(reinterpret_cast<char*>(&version), 4);
    if (!f || version != 3) return false;

    // Kayıt sayısı
    uint32_t count;
    f.read(reinterpret_cast<char*>(&count), 4);
    if (!f) return false;

    entries_.reserve(count);

    for (uint32_t i = 0; i < count; ++i) {
        uint64_t hash;
        f.read(reinterpret_cast<char*>(&hash), 8);
        if (!f) break;

        BookEntry e;
        uint8_t pad;
        f.read(reinterpret_cast<char*>(&e.from_sq), 1);
        f.read(reinterpret_cast<char*>(&e.to_sq),   1);
        f.read(reinterpret_cast<char*>(&e.promo),   1);
        f.read(reinterpret_cast<char*>(&pad),        1);
        f.read(reinterpret_cast<char*>(&e.weight),  1);
        if (!f) break;

        // Geçersiz kare indeksi olan kayıtları atla
        if (e.from_sq > 111 || e.to_sq > 111) continue;
        if (e.weight == 0) e.weight = 1;

        entries_[hash].push_back(e);
    }

    return !entries_.empty();
}

// ─────────────────────────────────────────────────────────────────────────────
//  OpeningBook::probe — Ağırlıklı rastgele hamle seç
// ─────────────────────────────────────────────────────────────────────────────
Move OpeningBook::probe(uint64_t pos_hash) const {
    auto it = entries_.find(pos_hash);
    if (it == entries_.end()) return MOVE_NONE;

    const auto& cands = it->second;
    if (cands.empty()) return MOVE_NONE;

    // Ağırlıkları topla
    int total = 0;
    for (const auto& e : cands) total += e.weight;

    // Ağırlıklı rastgele seçim
    static std::mt19937 rng(std::random_device{}());
    std::uniform_int_distribution<int> dist(0, total > 0 ? total - 1 : 0);
    int r = dist(rng);

    for (const auto& e : cands) {
        r -= e.weight;
        if (r < 0) {
            // from_sq ve to_sq'den basit hamle oluştur (7 bit + 7 bit)
            // Terfi varsa MT_PROMO tipini kullan
            if (e.promo != 0)
                return make_move(static_cast<Square>(e.from_sq),
                                 static_cast<Square>(e.to_sq),
                                 MT_PROMO);
            return make_move(static_cast<Square>(e.from_sq),
                             static_cast<Square>(e.to_sq));
        }
    }

    // Yedek: ilk adayı döndür
    const auto& first = cands[0];
    if (first.promo != 0)
        return make_move(static_cast<Square>(first.from_sq),
                         static_cast<Square>(first.to_sq),
                         MT_PROMO);
    return make_move(static_cast<Square>(first.from_sq),
                     static_cast<Square>(first.to_sq));
}

} // namespace Apex
