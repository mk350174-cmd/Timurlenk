/**
 * wasm_api.cpp — Apex Timurlenk WebAssembly C API
 *
 * Emscripten ile derlendiğinde tarayıcıdan çağrılabilir C fonksiyonları sağlar.
 * Web Worker içinde kullanımı önerilir (start_search bloklayıcıdır).
 *
 * Derleme: tools/build_wasm.sh
 */

#ifdef __EMSCRIPTEN__
#include <emscripten.h>
#else
// Native debug build için stub
#define EMSCRIPTEN_KEEPALIVE
#endif

#include "board.h"
#include "movegen.h"
#include "search.h"
#include "evaluate.h"
#include "tt.h"
#include "types.h"

#include <cstring>
#include <sstream>
#include <string>
#include <vector>

namespace {

// ── Global motor nesneleri ────────────────────────────────────────────────────
Apex::Board*              g_board    = nullptr;
Apex::TranspositionTable* g_tt       = nullptr;
Apex::Searcher*           g_searcher = nullptr;
std::vector<Apex::StateInfo> g_history; // do_move için StateInfo zinciri

// Sonuç tamponu — JS bu adresten okur (her çağrıdan önce üzerine yazılır)
static char g_buf[65536];

// ── Koordinat yardımcıları (uci.cpp mantığını kopyalar — uci.h bağımlılığı yok) ──

static std::string sq_to_str(Apex::Square sq) {
    using namespace Apex;
    if (sq == WHITE_CITADEL) return "wc";
    if (sq == BLACK_CITADEL) return "bc";
    if (sq >= BOARD_NORMAL)  return "??";
    char file = 'a' + sq_file(sq);
    int  rank =  1  + sq_rank(sq);
    return std::string(1, file) + std::to_string(rank);
}

static Apex::Square str_to_sq(const std::string& s) {
    using namespace Apex;
    if (s == "wc") return WHITE_CITADEL;
    if (s == "bc") return BLACK_CITADEL;
    if (s.size() < 2) return SQ_NONE;
    int f = s[0] - 'a';
    int r = std::stoi(s.substr(1)) - 1;
    if (f < 0 || f >= BOARD_FILES || r < 0 || r >= BOARD_RANKS) return SQ_NONE;
    return make_sq(f, r);
}

static std::string move_to_str(Apex::Move m, Apex::PieceType promo = Apex::NO_PIECE_TYPE) {
    using namespace Apex;
    if (m == MOVE_NONE) return "0000";
    if (m == MOVE_NULL) return "null";

    Square from = move_from(m);
    Square to   = move_to(m);
    MoveType mt = move_type(m);

    std::string s = sq_to_str(from) + sq_to_str(to);
    if (mt == MT_PROMO && promo != NO_PIECE_TYPE) {
        s += '=';
        s += PIECE_TYPE_STR[promo];
    } else if (mt == MT_SWAP) {
        s = "swap:" + sq_to_str(from) + sq_to_str(to);
    }
    return s;
}

static Apex::Move str_to_move(const std::string& s) {
    using namespace Apex;
    if (!g_board) return MOVE_NONE;
    if (s == "0000" || s == "(none)") return MOVE_NONE;

    // Swap: "swap:e1h4"
    if (s.size() >= 5 && s.substr(0, 5) == "swap:") {
        std::string rest = s.substr(5);
        std::string from_s = rest.substr(0, 2);
        std::string to_s   = rest.substr(2);
        if (rest.size() >= 3 && rest[2] == '1' && rest.size() > 3)
            to_s = rest.substr(2);
        Square from = str_to_sq(from_s);
        Square to   = str_to_sq(to_s);
        if (from == SQ_NONE || to == SQ_NONE) return MOVE_NONE;
        return make_move(from, to, MT_SWAP);
    }

    // Citadel: "a9bc" veya "k2wc"
    if (s.size() >= 4) {
        std::string to_s = s.substr(s.size() - 2);
        if (to_s == "wc" || to_s == "bc") {
            std::string from_s = s.substr(0, s.size() - 2);
            Square from = str_to_sq(from_s);
            Square to   = str_to_sq(to_s);
            if (from != SQ_NONE && to != SQ_NONE)
                return make_move(from, to, MT_CITADEL);
        }
    }

    // Normal / terfi: "e5f7" veya "b9b10=K"
    std::string move_s = s;
    PieceType promo_pt = NO_PIECE_TYPE;
    auto eq_pos = move_s.find('=');
    if (eq_pos != std::string::npos) {
        std::string promo_str = move_s.substr(eq_pos + 1);
        move_s = move_s.substr(0, eq_pos);
        for (int pt = 1; pt < PIECE_TYPE_NB; pt++) {
            if (promo_str == PIECE_TYPE_STR[pt]) {
                promo_pt = static_cast<PieceType>(pt);
                break;
            }
        }
    }

    Square from = SQ_NONE, to = SQ_NONE;
    if (move_s.size() >= 4) {
        size_t i = 1;
        while (i < move_s.size() && std::isdigit(move_s[i])) i++;
        from = str_to_sq(move_s.substr(0, i));
        to   = str_to_sq(move_s.substr(i));
    }

    if (from == SQ_NONE || to == SQ_NONE) return MOVE_NONE;
    if (promo_pt != NO_PIECE_TYPE) return make_move(from, to, MT_PROMO);
    return make_move(from, to);
}

// Yasal hamleler arasında MoveExt bul (promo için)
static Apex::MoveExt find_legal_ext(Apex::Move m) {
    using namespace Apex;
    MoveList ml;
    MoveGenerator::generate_legal(*g_board, ml);
    for (int i = 0; i < ml.size(); i++) {
        if (ml.begin()[i].move == m) return ml.begin()[i];
    }
    MoveExt dummy; dummy.move = m; dummy.promo = NO_PIECE_TYPE;
    return dummy;
}

} // anonymous namespace

// ─────────────────────────────────────────────────────────────────────────────
//  Dışa aktarılan C API
// ─────────────────────────────────────────────────────────────────────────────
extern "C" {

/**
 * engine_init — Motoru başlat
 * hash_mb: TT boyutu MB cinsinden (0 → 16 MB)
 */
EMSCRIPTEN_KEEPALIVE
void engine_init(int hash_mb) {
    delete g_searcher; g_searcher = nullptr;
    delete g_tt;       g_tt       = nullptr;
    delete g_board;    g_board    = nullptr;
    g_history.clear();

    g_board    = new Apex::Board();
    g_tt       = new Apex::TranspositionTable();
    g_tt->resize(hash_mb > 0 ? hash_mb : 16);
    g_searcher = new Apex::Searcher(*g_board, *g_tt);
    g_board->setup();

    // WASM'da tek iş parçacığı
    g_searcher->set_threads(1);
}

/**
 * engine_new_game — Yeni oyun: TT temizle, startpos kur
 */
EMSCRIPTEN_KEEPALIVE
void engine_new_game() {
    if (!g_board || !g_tt) return;
    g_tt->clear();
    g_history.clear();
    g_board->setup();
}

/**
 * engine_set_position — Pozisyonu kur
 * pos: "startpos" | FEN string
 * Dönüş: 1 başarılı, 0 hata
 */
EMSCRIPTEN_KEEPALIVE
int engine_set_position(const char* pos) {
    if (!g_board) return 0;
    g_history.clear();
    if (std::string(pos) == "startpos") {
        g_board->setup();
        return 1;
    }
    return g_board->from_string(std::string(pos)) ? 1 : 0;
}

/**
 * engine_do_moves — Hamle listesini uygula (boşlukla ayrılmış UCI format)
 * moves: "e2e4 e7e5 g1f3"
 * Dönüş: uygulanan hamle sayısı
 */
EMSCRIPTEN_KEEPALIVE
int engine_do_moves(const char* moves) {
    if (!g_board) return 0;
    std::istringstream ss(moves);
    std::string token;
    int count = 0;
    while (ss >> token) {
        Apex::Move m = str_to_move(token);
        if (m == Apex::MOVE_NONE) break;
        Apex::MoveExt ext = find_legal_ext(m);
        g_history.emplace_back();
        g_board->do_move(m, g_history.back(), ext.promo);
        count++;
    }
    return count;
}

/**
 * engine_best_move — En iyi hamleyi ara
 * depth: maksimum derinlik (0 → MAX_PLY)
 * movetime_ms: zaman sınırı ms (0 → sadece depth)
 * Dönüş: hamle string ("e2e4" | "swap:e1h4" | "0000" hata)
 */
EMSCRIPTEN_KEEPALIVE
const char* engine_best_move(int depth, int movetime_ms) {
    if (!g_searcher) { std::strcpy(g_buf, "0000"); return g_buf; }

    Apex::SearchLimits lim;
    lim.depth = (depth > 0) ? depth : Apex::MAX_PLY;
    if (movetime_ms > 0) lim.movetime = movetime_ms;

    g_searcher->start_search(lim);

    Apex::Move best = g_searcher->best_move();
    if (best == Apex::MOVE_NONE) { std::strcpy(g_buf, "0000"); return g_buf; }

    // Terfi için MoveExt bul
    Apex::MoveList ml;
    Apex::MoveGenerator::generate_legal(*g_board, ml);
    Apex::PieceType promo = Apex::NO_PIECE_TYPE;
    for (int i = 0; i < ml.size(); i++) {
        if (ml.begin()[i].move == best) { promo = ml.begin()[i].promo; break; }
    }

    std::string s = move_to_str(best, promo);
    std::strncpy(g_buf, s.c_str(), sizeof(g_buf) - 1);
    return g_buf;
}

/**
 * engine_get_eval — Mevcut pozisyonun statik değerlendirmesi (cp)
 * Pozitif: sıradaki oyuncu avantajlı
 */
EMSCRIPTEN_KEEPALIVE
int engine_get_eval() {
    if (!g_board || !g_searcher) return 0;
    return g_searcher->evaluator().evaluate(*g_board, g_board->side_to_move());
}

/**
 * engine_get_legal_moves — Yasal hamleleri JSON dizisi olarak döndür
 * Dönüş: '["e2e4","d2d4",...]' formatında C string
 */
EMSCRIPTEN_KEEPALIVE
const char* engine_get_legal_moves() {
    if (!g_board) { std::strcpy(g_buf, "[]"); return g_buf; }

    Apex::MoveList ml;
    Apex::MoveGenerator::generate_legal(*g_board, ml);

    std::string json = "[";
    for (int i = 0; i < ml.size(); i++) {
        if (i > 0) json += ",";
        json += '"';
        json += move_to_str(ml.begin()[i].move, ml.begin()[i].promo);
        json += '"';
    }
    json += "]";
    std::strncpy(g_buf, json.c_str(), sizeof(g_buf) - 1);
    return g_buf;
}

/**
 * engine_get_fen — Mevcut pozisyonun FEN string'i
 */
EMSCRIPTEN_KEEPALIVE
const char* engine_get_fen() {
    if (!g_board) { std::strcpy(g_buf, ""); return g_buf; }
    std::string fen = g_board->to_fen();
    std::strncpy(g_buf, fen.c_str(), sizeof(g_buf) - 1);
    return g_buf;
}

/**
 * engine_is_game_over — Oyun bitti mi?
 * Dönüş: 0=devam, 1=mat (stm kaybetti), 2=pat (beraberlik), 3=citadel beraberlik
 */
EMSCRIPTEN_KEEPALIVE
int engine_is_game_over() {
    if (!g_board) return 0;

    // Citadel beraberlik
    if (g_board->king_on_citadel(Apex::WHITE) ||
        g_board->king_on_citadel(Apex::BLACK)) return 3;

    // Yasal hamle yok mu?
    Apex::MoveList ml;
    Apex::MoveGenerator::generate_legal(*g_board, ml);
    if (ml.size() > 0) return 0;

    // Şah altında → mat; değilse → pat
    return g_board->in_check() ? 1 : 2;
}

/**
 * engine_get_side_to_move — Sıradaki taraf
 * Dönüş: 0=beyaz, 1=siyah
 */
EMSCRIPTEN_KEEPALIVE
int engine_get_side_to_move() {
    if (!g_board) return 0;
    return g_board->side_to_move() == Apex::WHITE ? 0 : 1;
}

/**
 * engine_clear_tt — Transpozisyon tablosunu temizle
 */
EMSCRIPTEN_KEEPALIVE
void engine_clear_tt() {
    if (g_tt) g_tt->clear();
}

} // extern "C"
