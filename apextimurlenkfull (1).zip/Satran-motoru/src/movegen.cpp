#include "movegen.h"
#include <algorithm>
#include <cstring>

namespace Apex {

// ─────────────────────────────────────────────────────────────────────────────
//  Yardımcılar
// ─────────────────────────────────────────────────────────────────────────────
static inline bool in_bounds(int f, int r) {
    return f >= 0 && f < BOARD_FILES && r >= 0 && r < BOARD_RANKS;
}

bool MoveGenerator::can_go(const Board& b, Color c, int file, int rank) {
    if (!in_bounds(file, rank)) return false;
    Square s = make_sq(file, rank);
    Piece  p = b.piece_on(s);
    return p == NO_PIECE || piece_color(p) != c;
}

void MoveGenerator::slide(const Board& b, Square from, Color c,
                          int dx, int dy, MoveList& ml)
{
    int f = sq_file(from) + dx;
    int r = sq_rank(from) + dy;
    while (in_bounds(f, r)) {
        Square to = make_sq(f, r);
        Piece  p  = b.piece_on(to);
        if (p == NO_PIECE) {
            ml.push(make_move(from, to));
        } else {
            if (piece_color(p) != c) ml.push(make_move(from, to)); // yeme
            break; // engel
        }
        f += dx; r += dy;
    }
}

void MoveGenerator::jump(const Board& b, Square from, Color c,
                         int dx, int dy, MoveList& ml)
{
    int f = sq_file(from) + dx;
    int r = sq_rank(from) + dy;
    if (!in_bounds(f, r)) return;
    Square to = make_sq(f, r);
    Piece  p  = b.piece_on(to);
    if (p == NO_PIECE || piece_color(p) != c)
        ml.push(make_move(from, to));
}

// ─────────────────────────────────────────────────────────────────────────────
//  Taş Bazlı Üreticiler
// ─────────────────────────────────────────────────────────────────────────────

// ── Şah ─────────────────────────────────────────────────────────────────────
void MoveGenerator::gen_sah(const Board& b, Square from, Color c, MoveList& ml)
{
    static const int dx[] = {-1,-1,-1, 0, 0, 1, 1, 1};
    static const int dy[] = {-1, 0, 1,-1, 1,-1, 0, 1};
    for (int i = 0; i < 8; i++)
        jump(b, from, c, dx[i], dy[i], ml);

    // Citadel girişi — rakibin kalesine komşuysa
    // Beyaz şah: BLACK_CITADEL'e girebilir (a9 = sq 88 komşusuysa)
    // Siyah şah: WHITE_CITADEL'e girebilir (k2 = sq 21 komşusuysa)
    if (c == WHITE && from == BLACK_CITADEL_NEIGHBOR) {
        ml.push(make_move(from, BLACK_CITADEL, MT_CITADEL));
    }
    if (c == BLACK && from == WHITE_CITADEL_NEIGHBOR) {
        ml.push(make_move(from, WHITE_CITADEL, MT_CITADEL));
    }
}

// ── Kale ─────────────────────────────────────────────────────────────────────
void MoveGenerator::gen_kale(const Board& b, Square from, Color c, MoveList& ml)
{
    slide(b, from, c,  1,  0, ml);
    slide(b, from, c, -1,  0, ml);
    slide(b, from, c,  0,  1, ml);
    slide(b, from, c,  0, -1, ml);
}

// ── Zürafa (Gryphon): çapraz 1 + düz min 3 ──────────────────────────────────
void MoveGenerator::zurafa_ray(const Board& b, Square from, Color c,
                                int df, int dr, MoveList& ml)
{
    int f0 = sq_file(from), r0 = sq_rank(from);

    // Çapraz 1 adım
    int cf = f0 + df, cr = r0 + dr;
    if (!in_bounds(cf, cr)) return;
    if (b.piece_on(make_sq(cf, cr)) != NO_PIECE) return; // çapraz kare dolu

    // 4 düz yön × minimum 3 adım devam
    static const int sdx[] = { 1,-1, 0, 0};
    static const int sdy[] = { 0, 0, 1,-1};

    for (int s = 0; s < 4; s++) {
        // Ara kareler (adım 1,2) boş olmalı; adım 3'ten itibaren hedef
        bool blocked = false;
        for (int step = 1; ; step++) {
            int tf = cf + sdx[s]*step, tr = cr + sdy[s]*step;
            if (!in_bounds(tf, tr)) break;
            Square to = make_sq(tf, tr);
            Piece  p  = b.piece_on(to);

            if (step < 3) {
                // Ara kare: boş olmalı
                if (p != NO_PIECE) { blocked = true; break; }
            } else {
                // Hedef kare: boş veya düşman
                if (p == NO_PIECE) {
                    ml.push(make_move(from, to));
                } else {
                    if (piece_color(p) != c) ml.push(make_move(from, to));
                    break; // engel
                }
            }
        }
        if (blocked) continue;
    }
}

void MoveGenerator::gen_zurafa(const Board& b, Square from, Color c, MoveList& ml)
{
    zurafa_ray(b, from, c,  1,  1, ml);
    zurafa_ray(b, from, c,  1, -1, ml);
    zurafa_ray(b, from, c, -1,  1, ml);
    zurafa_ray(b, from, c, -1, -1, ml);
}

// ── Talia: yatay/dikey tam 2 sıçrama (atlayabilir) ──────────────────────────
void MoveGenerator::gen_talia(const Board& b, Square from, Color c, MoveList& ml)
{
    jump(b, from, c,  2,  0, ml);
    jump(b, from, c, -2,  0, ml);
    jump(b, from, c,  0,  2, ml);
    jump(b, from, c,  0, -2, ml);
}

// ── At: L şekli 2+1 (atlayabilir) ───────────────────────────────────────────
void MoveGenerator::gen_at(const Board& b, Square from, Color c, MoveList& ml)
{
    static const int dx[] = { 2, 2,-2,-2, 1, 1,-1,-1};
    static const int dy[] = { 1,-1, 1,-1, 2,-2, 2,-2};
    for (int i = 0; i < 8; i++)
        jump(b, from, c, dx[i], dy[i], ml);
}

// ── Deve: 3+1 atlama (atlayabilir) ──────────────────────────────────────────
void MoveGenerator::gen_deve(const Board& b, Square from, Color c, MoveList& ml)
{
    static const int dx[] = { 3, 3,-3,-3, 1, 1,-1,-1};
    static const int dy[] = { 1,-1, 1,-1, 3,-3, 3,-3};
    for (int i = 0; i < 8; i++)
        jump(b, from, c, dx[i], dy[i], ml);
}

// ── Fil: çapraz 2 sıçrama (atlayabilir) ─────────────────────────────────────
void MoveGenerator::gen_fil(const Board& b, Square from, Color c, MoveList& ml)
{
    jump(b, from, c,  2,  2, ml);
    jump(b, from, c,  2, -2, ml);
    jump(b, from, c, -2,  2, ml);
    jump(b, from, c, -2, -2, ml);
}

// ── Savaş Makinesi: yatay/dikey 2 sıçrama (atlayabilir) ─────────────────────
void MoveGenerator::gen_savas(const Board& b, Square from, Color c, MoveList& ml)
{
    jump(b, from, c,  2,  0, ml);
    jump(b, from, c, -2,  0, ml);
    jump(b, from, c,  0,  2, ml);
    jump(b, from, c,  0, -2, ml);
}

// ── Ferz: çapraz 1 kare ──────────────────────────────────────────────────────
void MoveGenerator::gen_ferz(const Board& b, Square from, Color c, MoveList& ml)
{
    jump(b, from, c,  1,  1, ml);
    jump(b, from, c,  1, -1, ml);
    jump(b, from, c, -1,  1, ml);
    jump(b, from, c, -1, -1, ml);
}

// ── Vali: yatay/dikey 1 kare ─────────────────────────────────────────────────
void MoveGenerator::gen_vali(const Board& b, Square from, Color c, MoveList& ml)
{
    jump(b, from, c,  1,  0, ml);
    jump(b, from, c, -1,  0, ml);
    jump(b, from, c,  0,  1, ml);
    jump(b, from, c,  0, -1, ml);
}

// ── Piyon ────────────────────────────────────────────────────────────────────
void MoveGenerator::gen_piyon(const Board& b, Square from, Color c, MoveList& ml)
{
    int f  = sq_file(from);
    int r  = sq_rank(from);
    int dr = (c == WHITE) ? 1 : -1; // ilerleme yönü
    int promo_rank = (c == WHITE) ? BOARD_RANKS - 1 : 0;

    // İleri 1 adım (çift adım YOK — tarihsel kural)
    int nf = f, nr = r + dr;
    if (in_bounds(nf, nr)) {
        Square to = make_sq(nf, nr);
        if (b.piece_on(to) == NO_PIECE) {
            if (nr == promo_rank) {
                // Terfi: Kale, Zürafa, Talia, At, Deve, Fil, SavaşM, Ferz, Vali'ye
                static const PieceType promo_opts[] = {
                    KALE, ZURAFA, TALIA, AT, DEVE, FIL, SAVAS, FERZ, VALI
                };
                for (PieceType pt : promo_opts)
                    ml.push(make_move(from, to, MT_PROMO), pt);
            } else {
                ml.push(make_move(from, to));
            }
        }
    }

    // Çapraz yeme
    static const int captures[] = {-1, 1};
    for (int dcf : captures) {
        int cf = f + dcf, cr = r + dr;
        if (!in_bounds(cf, cr)) continue;
        Square to = make_sq(cf, cr);
        Piece  p  = b.piece_on(to);
        if (p != NO_PIECE && piece_color(p) != c) {
            if (cr == promo_rank) {
                static const PieceType promo_opts[] = {
                    KALE, ZURAFA, TALIA, AT, DEVE, FIL, SAVAS, FERZ, VALI
                };
                for (PieceType pt : promo_opts)
                    ml.push(make_move(from, to, MT_PROMO), pt);
            } else {
                ml.push(make_move(from, to));
            }
        }
    }
}

// ── Swap (Yer Değiştirme) ────────────────────────────────────────────────────
void MoveGenerator::gen_swap(const Board& b, Color c, MoveList& ml)
{
    if (b.swap_used(c)) return; // Hak kullanıldı
    if (b.in_check()) return;   // Şah altında swap yasak

    Square ksq = b.king_sq(c);
    if (ksq == SQ_NONE) return;

    // Tüm tahtayı tara
    for (int r = 0; r < BOARD_RANKS; r++) {
        for (int f = 0; f < BOARD_FILES; f++) {
            Square sq = make_sq(f, r);
            if (sq == ksq) continue;
            Piece p = b.piece_on(sq);
            if (p == NO_PIECE || piece_color(p) != c) continue;
            // Şah ile bu taş yer değiştirecek
            ml.push(make_move(ksq, sq, MT_SWAP));
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
//  Ana Üretim Fonksiyonları
// ─────────────────────────────────────────────────────────────────────────────
void MoveGenerator::generate_pseudo(const Board& b, MoveList& ml)
{
    Color c = b.side_to_move();

    for (int rank = 0; rank < BOARD_RANKS; rank++) {
        for (int file = 0; file < BOARD_FILES; file++) {
            Square from = make_sq(file, rank);
            Piece  p    = b.piece_on(from);
            if (p == NO_PIECE || piece_color(p) != c) continue;

            switch (piece_type(p)) {
                case SAH:    gen_sah   (b, from, c, ml); break;
                case KALE:   gen_kale  (b, from, c, ml); break;
                case ZURAFA: gen_zurafa(b, from, c, ml); break;
                case TALIA:  gen_talia (b, from, c, ml); break;
                case AT:     gen_at    (b, from, c, ml); break;
                case DEVE:   gen_deve  (b, from, c, ml); break;
                case FIL:    gen_fil   (b, from, c, ml); break;
                case SAVAS:  gen_savas (b, from, c, ml); break;
                case FERZ:   gen_ferz  (b, from, c, ml); break;
                case VALI:   gen_vali  (b, from, c, ml); break;
                case PIYON:  gen_piyon (b, from, c, ml); break;
                default: break;
            }
        }
    }

    // Swap hamlesi
    gen_swap(b, c, ml);
}

// generate_legal — const Board& alır ama do_move/undo_move ile geçici mutasyon yapar.
// Board iç durumu çağrı sonrası aynı kalır (undo_move tam geri alır).
// do_move non-const gerektirir; const_cast yerine overload kullanılır.
void MoveGenerator::generate_legal(Board& b, MoveList& ml)
{
    MoveList pseudo;
    generate_pseudo(b, pseudo);

    Color c = b.side_to_move();
    for (auto& me : pseudo) {
        StateInfo st;
        b.do_move(me.move, st);
        if (!b.is_attacked(b.king_sq(c), ~c))
            ml.push(me.move, me.promo);
        b.undo_move(me.move);
    }
}

// const overload — uci.cpp ve diğer const bağlamlar için
void MoveGenerator::generate_legal(const Board& b, MoveList& ml)
{
    generate_legal(const_cast<Board&>(b), ml);
}

void MoveGenerator::generate_captures(const Board& b, MoveList& ml)
{
    // Tek paylaşımlı buffer: per-piece MoveList yerine tek geçiş
    MoveList all;
    generate_pseudo(b, all);
    for (int i = 0; i < all.count; i++) {
        Move m = all.moves[i].move;
        Square to = move_to(m);
        if ((b.piece_on(to) != NO_PIECE && move_type(m) != MT_SWAP)
            || move_type(m) == MT_PROMO)
            ml.push(m, all.moves[i].promo);
    }
}

void MoveGenerator::generate_evasions(const Board& b, MoveList& ml)
{
    // Şah altındayken sadece şahı kurtaran hamleler
    // 1. Şahı hareket ettir
    Square ksq = b.king_sq(b.side_to_move());
    Color  c   = b.side_to_move();
    gen_sah(b, ksq, c, ml);

    // 2. Tüm yasal hamleleri üret (şah bloğu veya saldırıyı kesme)
    // Basit implementasyon: generate_legal kullan
    MoveList all;
    generate_legal(b, all);
    for (auto& me : all)
        if (move_from(me.move) != ksq) // Şah dışı hamleler
            ml.push(me.move, me.promo);
}

// ─────────────────────────────────────────────────────────────────────────────
//  Mobilite Sayısı (değerlendirici için)
// ─────────────────────────────────────────────────────────────────────────────
int MoveGenerator::mobility(const Board& b, Color c)
{
    MoveList ml;
    // Pseudo-legal sayımı (hız için)
    Color saved = b.side_to_move();
    (void)saved;
    // Board const olduğu için doğrudan üretemiyoruz
    // Bu çağrı evaluate.cpp'den gelir — board const değil
    generate_pseudo(b, ml);
    return ml.count;
}

// ─────────────────────────────────────────────────────────────────────────────
//  LMR Tablosu
// ─────────────────────────────────────────────────────────────────────────────
int LMR_TABLE[MAX_PLY][MAX_MOVES];

void init_lmr_table() {
    for (int d = 1; d < MAX_PLY; d++) {
        for (int m = 1; m < MAX_MOVES; m++) {
            // 53 dallanma faktörü için daha agresif LMR
            double r = std::log(d) * std::log(m) / 1.25;
            LMR_TABLE[d][m] = std::max(0, static_cast<int>(r));
        }
    }
    // Derinlik 0-1 için azaltma yok
    for (int m = 0; m < MAX_MOVES; m++)
        LMR_TABLE[0][m] = LMR_TABLE[1][m] = 0;
}

} // namespace Apex
