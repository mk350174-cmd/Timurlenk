#include "persona.h"
#include <cstdlib>

namespace Apex {

int PersonaLayer::contempt() const {
    switch (type) {
        case PersonaType::NONE:        return 0;
        case PersonaType::MACHIAVELLI: return 10 + psyche / 10;
        case PersonaType::NIETZSCHE:   return 30 + psyche / 10;
        // Türk-Altay personaları
        case PersonaType::ULGEN:       return 15 + psyche / 10;  // Zafer tanrısı — beraberliği hafif reddeder
        case PersonaType::ERLIK:       return 40 + psyche / 10;  // Karanlık güç — beraberliğe sıfır tolerans
        case PersonaType::BOZKURT:     return 20 + psyche / 10;  // Avcı — beraberliği tercih etmez
        case PersonaType::TENGRI:      return 0;                  // Tarafsız kozmik denge
        case PersonaType::DEDE_KORKUT: return  5 + psyche / 10;  // Bilge — deneyim kazancını kabul eder
        case PersonaType::UMAY:        return -10 + psyche / 10; // Koruyucu — kötü konumda beraberlik iyidir
        default:                       return 0;
    }
}

int PersonaLayer::aspiration_delta() const {
    constexpr int BASE = 25;
    // Mevcut özel modlar
    if (vezuv_protocol())   return BASE * 3;   // Nietzsche Vezüv: çok geniş
    if (erlik_dark_depth()) return BASE * 4;   // Erlik Karanlık Derinlik: mat araması
    if (necessita_mode())   return BASE / 2;   // Necessità: dar, kesin
    if (umay_shield())      return BASE / 2;   // Umay Kalkan: dar, güvenli

    switch (type) {
        case PersonaType::ULGEN:       return 20 + std::abs(psyche) / 5;  // Dar — kaçınılmaz ilerleme
        case PersonaType::ERLIK:       return 35 + std::abs(psyche) / 5;  // Geniş — saldırı kombinasyonu
        case PersonaType::BOZKURT:     return 28 + std::abs(psyche) / 5;  // Orta — reaktif tempo
        case PersonaType::TENGRI:      return BASE + std::abs(psyche) / 5; // Standart — saf hesap
        case PersonaType::DEDE_KORKUT: return 18 + std::abs(psyche) / 5;  // Dar — bilinen yolda git
        case PersonaType::UMAY:        return 15 + std::abs(psyche) / 5;  // Çok dar — güvenlik önce
        default:                       return BASE + std::abs(psyche) / 5;
    }
}

std::string PersonaLayer::commentary(int depth, i32 score) const {
    if (type == PersonaType::NONE) return "";

    switch (type) {
        case PersonaType::MACHIAVELLI:
            if (score >  150) return "Fortuna favor ediyor — ilerle.";
            if (score < -150) return "Necessità zamanı — tüm araçlar meşru.";
            if (depth >= 8)   return "Verità effettuale: gerçeği gör.";
            return "Aslan ve tilki — seç.";

        case PersonaType::NIETZSCHE:
            if (score >  150) return "Güç istenci açık — baskıla.";
            if (score < -150) return "Vezüv: her şeyi feda et, kazan.";
            if (depth >= 8)   return "Übermensch — sınırı aş.";
            return "Bengi dönüş: bu hamle ebedidir.";

        case PersonaType::ULGEN:
            if (score >  150) return "Ülgen görüyor — ışık açık, ilerle.";
            if (score < -150) return "Karanlık geçici — altın yol bulunur.";
            if (depth >= 8)   return "17. kattan baktım — hamle yazgıda.";
            return "Gök düzeni: her taşın yeri var.";

        case PersonaType::ERLIK:
            if (score >  150) return "Erlik güler — demiri çatlat, ilerle.";
            if (score < -150) return "Yeraltından bile çıkılır — saldır.";
            if (depth >= 8)   return "Demir saçlı görüyor — mat yakın.";
            return "Kaos düzeni bozar — boz ve kazan.";

        case PersonaType::BOZKURT:
            if (score >  150) return "Kurt kokuyor — av yakın, baskıya devam.";
            if (score < -150) return "Sürüden ayrılma — savun ve fırsat bekle.";
            if (depth >= 8)   return "Bozkurtun gözü: zayıf halka görünüyor.";
            return "Ötüken'den esen yel — hamle rüzgar gibi.";

        case PersonaType::TENGRI:
            if (score >  150) return "Tengri buyurdu — zafer yazgıda.";
            if (score < -150) return "Gök değişmez — yol başka yerde.";
            if (depth >= 8)   return "Kök Tengri görüyor — mavi sonsuzluktan.";
            return "Gökyüzü gibi: sınırsız, tarafsız, kesin.";

        case PersonaType::DEDE_KORKUT:
            if (score >  150) return "Dede bilirdi — bu pozisyon destanda geçer.";
            if (score < -150) return "Ozan söyledi: yenilgi de öğretir.";
            if (depth >= 8)   return "Korkut'un sazı çalıyor — derin yol açılıyor.";
            return "Her hamle bir beyit — destanı tamamla.";

        case PersonaType::UMAY:
            if (score >  150) return "Umay koruyor — taşlar yerinde, ilerliyoruz.";
            if (score < -150) return "Ana toplar — savun, yeniden dene.";
            if (depth >= 8)   return "Altın kartal görüyor: her şey yerli yerinde.";
            return "Umay'ın kanadı — taşlarını koru.";

        default: return "";
    }
}

} // namespace Apex
