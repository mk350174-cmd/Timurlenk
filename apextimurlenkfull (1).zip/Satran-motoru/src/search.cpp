#include "search.h"
#include "movegen.h"
#include <algorithm>
#include <cmath>
#include <cstring>
#include <iostream>
#include <sstream>

namespace Apex {

// ─────────────────────────────────────────────────────────────────────────────
//  Zaman Yönetimi
// ─────────────────────────────────────────────────────────────────────────────
void TimeManager::init(int64_t wtime, int64_t btime, int64_t winc, int64_t binc,
                       int movestogo, Color stm)
{
    start = Clock::now();
    int64_t my_time = (stm == WHITE) ? wtime : btime;
    int64_t my_inc  = (stm == WHITE) ? winc  : binc;

    if (movestogo > 0) {
        // Belirli hamle sayısı için zaman
        soft_limit_ms = (my_time / movestogo) + my_inc * 3 / 4;
    } else {
        // Genel formül: kalan sürenin ~%5'i + artış
        soft_limit_ms = my_time / 20 + my_inc * 3 / 4;
    }

    // Hard limit: soft'un 3×'i veya toplam sürenin %80'i
    hard_limit_ms = std::min(soft_limit_ms * 3, my_time * 4 / 5);

    // Güvenlik marjı
    hard_limit_ms = std::max(hard_limit_ms - 50, (int64_t)10);
    soft_limit_ms = std::max(soft_limit_ms - 30, (int64_t)5);
}

// ─────────────────────────────────────────────────────────────────────────────
//  Searcher — Kurucu
// ─────────────────────────────────────────────────────────────────────────────
Searcher::Searcher(Board& board, TranspositionTable& tt)
    : board_(board), tt_(tt), orderer_(), evaluator_(),
      best_move_(MOVE_NONE), ponder_move_(MOVE_NONE),
      best_score_(SCORE_NONE), stopped_(false)
{}

void Searcher::new_game() {
    tt_.clear();
    orderer_.reset();
    stats_.reset();
    std::memset(cont_hist_, 0, sizeof(cont_hist_));
    best_move_  = MOVE_NONE;
    best_score_ = SCORE_NONE;
}

// ─────────────────────────────────────────────────────────────────────────────
//  Zaman Kontrolü (her ~1024 düğümde)
// ─────────────────────────────────────────────────────────────────────────────
bool Searcher::time_check() {
    if (stopped_.load()) return true;
    if (extern_stop_ && extern_stop_->load()) {
        stopped_.store(true);
        return true;
    }
    if ((stats_.nodes & 1023) != 0) return false;
    if (node_limit_ > 0 && stats_.nodes >= node_limit_) {
        stopped_.store(true);
        return true;
    }
    if (tm_.hard_expired()) {
        stopped_.store(true);
        return true;
    }
    return false;
}

void Searcher::ponderhit() {
    pondering_ = false;
    tm_.infinite = false; // ponder'dan normal zamanlı aramaya geç
}

// ─────────────────────────────────────────────────────────────────────────────
//  Ana Arama Başlatıcı
// ─────────────────────────────────────────────────────────────────────────────
void Searcher::start_search(const SearchLimits& lim) {
    stopped_.store(false);
    stats_.reset();
    node_limit_ = lim.nodes;

    Color stm = board_.side_to_move();

    // Zaman yöneticisini ayarla
    tm_.start = TimeManager::Clock::now();
    pondering_ = lim.ponder;
    if (lim.infinite || lim.ponder) {
        tm_.init_infinite();
    } else if (lim.movetime > 0) {
        tm_.init_movetime(lim.movetime);
    } else if (lim.wtime > 0 || lim.btime > 0) {
        tm_.init(lim.wtime, lim.btime, lim.winc, lim.binc, lim.movestogo, stm);
    } else {
        // Sadece depth limiti (go depth N) — sonsuz gibi davran
        tm_.init_infinite();
    }

    tt_.new_search();
    orderer_.reset();
    best_move_  = MOVE_NONE;
    best_score_ = SCORE_NONE;
    root_pv_.clear();
    time_adj_.store(0);

    // Contempt'i persona'dan başlat
    contempt_ = persona_.contempt();

    // Açılış stili — sadece ilk 10 hamlede (fullmove <= 10)
    opening_adj_.store(0);
    if (board_.fullmove() <= 10 && opening_cb_) {
        bool is_white = (board_.side_to_move() == WHITE);
        opening_cb_(persona_.name(), board_.fullmove(), is_white,
            [this](const std::string& style) {
                if (style == "aggressive") opening_adj_.store(1);
                else if (style == "gambit") opening_adj_.store(2);
            });
    }

    // Citadel stratejisi — az taş kaldığında (<16 taş)
    citadel_adj_.store(0);
    citadel_bias_ = 0;
    if (citadel_cb_) {
        int npieces_citadel = 0;
        for (int c = 0; c <= 1; c++)
            for (int pt = 2; pt < PIECE_TYPE_NB; pt++)
                npieces_citadel += static_cast<int>(
                    board_.pieces(static_cast<Color>(c),
                                  static_cast<PieceType>(pt)).size());
        if (npieces_citadel < 16) {
            Color stm_cit = board_.side_to_move();
            Square ksq      = board_.king_sq(stm_cit);
            Square neighbor = (stm_cit == WHITE) ? BLACK_CITADEL_NEIGHBOR
                                                 : WHITE_CITADEL_NEIGHBOR;
            int dist = std::abs(sq_rank(ksq) - sq_rank(neighbor))
                     + std::abs(sq_file(ksq) - sq_file(neighbor));
            int mat = static_cast<int>(best_score_ != SCORE_NONE ? best_score_ : 0);
            int phase_approx_cit = std::min(255, npieces_citadel * 9);
            citadel_cb_(persona_.name(), phase_approx_cit, dist, mat,
                [this](const std::string& strategy) {
                    if (strategy == "rush_citadel") citadel_adj_.store(1);
                    else if (strategy == "ignore")   citadel_adj_.store(-1);
                });
        }
    }

    // Contempt başlangıç değerini persona'dan al (zaten contempt_ = persona_.contempt() yukarıda)
    contempt_pending_.store(0);

    // Needle zaman kararı — sadece wtime modunda ve callback ayarlıysa
    if (!tm_.infinite && time_adj_cb_) {
        // Faz tahmini: taş sayısına göre (0=endgame .. 255=middlegame)
        int npieces = 0;
        for (int c = 0; c <= 1; c++)
            for (int pt = 2; pt < PIECE_TYPE_NB; pt++)
                npieces += static_cast<int>(
                    board_.pieces(static_cast<Color>(c),
                                  static_cast<PieceType>(pt)).size());
        int phase_approx = std::min(255, npieces * 9);

        // Materyal dengesi: son bilinen skor (yeni oyunda 0)
        int mat_balance = static_cast<int>(best_score_ != SCORE_NONE ? best_score_ : 0);

        time_adj_cb_(persona_.name(), phase_approx, mat_balance,
            [this](const std::string& decision) {
                if (decision == "spend_more")
                    time_adj_.store(1);
                else if (decision == "spend_less")
                    time_adj_.store(-1);
                // "normal" → 0 zaten
            });
    }

    int max_depth = std::min(lim.depth, MAX_PLY - 1);

    // Lazy SMP: n_threads_-1 helper thread başlat
    for (int t = 1; t < n_threads_; t++) {
        helpers_.emplace_back([this, max_depth]() {
            run_as_helper(stopped_, max_depth);
        });
    }

    iterative_deepening(max_depth);

    // Ana iterasyon bitti, helper'ları durdur ve bekle
    stopped_.store(true);
    for (auto& h : helpers_) h.join();
    helpers_.clear();
}

void Searcher::run_as_helper(std::atomic<bool>& parent_stop, int max_depth) {
    // Helper kendi Board kopyasını alır (TT paylaşımlı)
    Board local_board = board_;
    Searcher helper(local_board, tt_);
    helper.extern_stop_ = &parent_stop;
    helper.n_threads_   = 1;
    helper.tm_          = tm_;
    helper.node_limit_  = 0;
    helper.stopped_.store(false);
    helper.stats_.reset();
    helper.orderer_.reset();

    // Biraz farklı derinlik sırası (TT çeşitliliği için)
    for (int depth = 1; depth <= max_depth && !parent_stop.load(); depth++) {
        helper.stack_[0].ply = 0;
        helper.search(depth, -SCORE_INFINITE, SCORE_INFINITE, 0, true, false, nullptr);
    }
}

// ─────────────────────────────────────────────────────────────────────────────
//  Iterative Deepening
// ─────────────────────────────────────────────────────────────────────────────
void Searcher::iterative_deepening(int max_depth) {
    // NNUE artımlı güncelleme için tahta↔ağ bağlantısını kur
    if (evaluator_.use_nnue()) {
        board_.set_nnue_net(evaluator_.get_nnue_ptr());
        board_.refresh_nnue_acc(); // Kök akümülatörü sıfırla → artımlı güncellemeler etkin
    }

    i32 prev_score = SCORE_NONE;
    i32 delta      = persona_.aspiration_delta();
    bool time_adj_applied    = false;
    bool opening_adj_applied = false;
    bool citadel_adj_applied = false;
    Move prev_best = MOVE_NONE;    // Hamle kararlılığı takibi
    int  stability = 0;            // Kaç derinlikte aynı en iyi hamle seçildi

    for (int depth = 1; depth <= max_depth; depth++) {
        if (stopped_.load()) break;

        // Contempt dinamik ayarını uygula (önceki derinlikten gelen karar)
        {
            int cpend = contempt_pending_.exchange(0);
            if (cpend == 1)       contempt_ = std::min(contempt_ + 5, 100);
            else if (cpend == -1) contempt_ = std::max(contempt_ - 5, -100);
        }

        // Aspiration Windows
        i32 alpha, beta;
        if (depth >= 5 && prev_score != SCORE_NONE) {
            alpha = prev_score - delta;
            beta  = prev_score + delta;
        } else {
            alpha = -SCORE_INFINITE;
            beta  =  SCORE_INFINITE;
        }

        i32 score;
        while (true) {
            stack_[0].ply = 0;
            score = search(depth, alpha, beta, 0, true, false, nullptr);

            if (stopped_.load()) break;

            if (score <= alpha) {
                // Alpha kaçtı: pencereyi aşağı genişlet
                alpha = std::max(-SCORE_INFINITE, alpha - delta);
                delta *= 2;
            } else if (score >= beta) {
                // Beta kaçtı: pencereyi yukarı genişlet
                beta = std::min(SCORE_INFINITE, beta + delta);
                delta *= 2;
            } else {
                break; // Pencere içinde kaldı
            }
            if (alpha <= -SCORE_INFINITE && beta >= SCORE_INFINITE) break;
        }

        if (stopped_.load() && best_move_ != MOVE_NONE) break;

        // Needle zaman kararını ilk geldiğinde uygula (bir kez)
        // Python subprocess ~200-500ms sürer; her derinlikte kontrol ederek
        // karar gelir gelmez uygularız
        if (!time_adj_applied && !tm_.infinite) {
            int adj = time_adj_.load();
            if (adj != 0) {
                time_adj_applied = true;
                time_adj_.store(0);
                if (adj == 1) {
                    tm_.soft_limit_ms = tm_.soft_limit_ms * 13 / 10;  // +%30
                    std::cout << "info string [NeedleTime] spend_more → soft_limit +%30"
                                 " (depth " << depth << ")\n" << std::flush;
                } else {
                    tm_.soft_limit_ms = tm_.soft_limit_ms * 7 / 10;   // -%30
                    std::cout << "info string [NeedleTime] spend_less → soft_limit -%30"
                                 " (depth " << depth << ")\n" << std::flush;
                }
                // hard_limit_ms değişmez — güvenli üst sınır sabit
            }
        }

        // Açılış stili — yanıt gelir gelmez uygula (bir kez)
        if (!opening_adj_applied) {
            int oadj = opening_adj_.load();
            if (oadj != 0) {
                opening_adj_applied = true;
                opening_adj_.store(0);
                if (oadj == 1) {
                    delta = std::max(10, delta * 7 / 10);
                    contempt_ = std::min(contempt_ + 10, 100);
                    std::cout << "info string [NeedleOpening] aggressive → dar aspiration"
                                 " (depth " << depth << ")\n" << std::flush;
                } else if (oadj == 2) {
                    contempt_ = std::max(contempt_ - 15, -100);
                    std::cout << "info string [NeedleOpening] gambit → feda toleransi"
                                 " (depth " << depth << ")\n" << std::flush;
                }
            }
        }

        // Citadel stratejisi — yanıt gelir gelmez uygula (bir kez)
        if (!citadel_adj_applied) {
            int cadj = citadel_adj_.load();
            if (cadj != 0) {
                citadel_adj_applied = true;
                citadel_adj_.store(0);
                if (cadj == 1) {
                    citadel_bias_ = 30;
                    std::cout << "info string [NeedleCitadel] rush_citadel → cazibe +30"
                                 " (depth " << depth << ")\n" << std::flush;
                } else {
                    citadel_bias_ = -30;
                    std::cout << "info string [NeedleCitadel] ignore → cazibe -30"
                                 " (depth " << depth << ")\n" << std::flush;
                }
            }
        }

        // Contempt dinamik — her 5 derinlikte bir Needle çağrısı yap
        if (depth >= 5 && depth % 5 == 0 && contempt_cb_) {
            int trend = static_cast<int>(prev_score != SCORE_NONE ? prev_score : 0);
            contempt_cb_(persona_.name(), trend, board_.fullmove(),
                [this](const std::string& action) {
                    if      (action == "raise") contempt_pending_.store(1);
                    else if (action == "lower") contempt_pending_.store(-1);
                    else                        contempt_pending_.store(0);
                    if (action != "hold" && !action.empty())
                        std::cout << "info string [NeedleContempt] " << action
                                  << " → contempt ayarlaniyor\n" << std::flush;
                });
        }

        prev_score = score;
        best_score_ = score;
        if (root_pv_.length > 0) {
            best_move_   = root_pv_.moves[0];
            ponder_move_ = (root_pv_.length > 1) ? root_pv_.moves[1] : MOVE_NONE;
        }
        delta = persona_.aspiration_delta(); // Sıfırla

        // Hamle kararlılığı: aynı hamle derinleşince zaman tasarrufu
        if (depth >= 4 && !tm_.infinite) {
            if (best_move_ == prev_best) {
                stability = std::min(stability + 1, 8);
            } else {
                stability = 0;
                prev_best = best_move_;
                // Hamle değişti → soft limit'i hafifçe uzat (daha iyi araştır)
                tm_.soft_limit_ms = tm_.soft_limit_ms * 11 / 10;
            }
            // Kararlı hamle → soft limit'i kısalt (erken dur)
            if (stability >= 4) {
                double factor = 1.0 - (stability - 3) * 0.05; // max %25 kısalt
                factor = std::max(factor, 0.75);
                tm_.soft_limit_ms = static_cast<int64_t>(tm_.soft_limit_ms * factor);
            }
        }

        // UCI bilgi çıktısı
        int64_t ms = tm_.elapsed_ms();
        u64 nps    = ms > 0 ? (stats_.nodes + stats_.qnodes) * 1000 / ms : 0;
        (void)nps;
        if (info_cb_) {
            info_cb_(depth, stats_.sel_depth, score,
                     stats_.nodes + stats_.qnodes, ms, root_pv_);
        }
        // Persona yorumu — sadece derin aramalarda
        if (depth >= 4) {
            std::string comment = persona_.commentary(depth, score);
            if (!comment.empty())
                std::cout << "info string [" << persona_.name() << "] " << comment << "\n";
            // Needle bridge isteği (asenkron — search bloke olmaz)
            if (needle_cb_)
                needle_cb_(persona_.name(), static_cast<int>(score), depth);
        }

        // Zaman yönetimi: derinlik tamamlandı — devam edilmeli mi?
        if (!tm_.infinite && tm_.soft_expired()) break;
    }
}

// ─────────────────────────────────────────────────────────────────────────────
//  Alpha-Beta Negamax (fail-soft)
// ─────────────────────────────────────────────────────────────────────────────
i32 Searcher::search(int depth, i32 alpha, i32 beta, int ply,
                     bool pv_node, bool cut_node, PVLine* pv_line)
{
    if (time_check()) return SCORE_NONE;

    // ── Terminal kontroller ────────────────────────────────────────────────
    if (ply >= MAX_PLY) return evaluator_.evaluate(board_, board_.side_to_move());
    if (board_.is_repetition(2)) return citadel_score(); // beraberlik
    if (board_.halfmove() >= 100) return citadel_score();

    // Citadel beraberlik: şah rakibin kalesine girmişse draw
    if (board_.king_on_citadel(board_.side_to_move())) return 0;
    if (board_.king_on_citadel(~board_.side_to_move())) return 0;

    // Citadel'e girilmişse beraberlik
    auto gr = board_.game_over();
    if (gr == Board::DRAW) return citadel_score();

    // Quiescence'a geç
    if (depth <= 0) return qsearch(alpha, beta, ply);

    stats_.nodes++;
    if (ply > stats_.sel_depth) stats_.sel_depth = ply;

    bool  root    = (ply == 0);
    bool  in_check= board_.in_check();
    i32   alpha0  = alpha; // Orijinal alpha (TT flag için)

    // Şah altında qsearch'e düşmeyi engelle (uzatmadan kaçın)
    if (in_check && depth <= 0) depth = 1;

    // ── Transposition Table sorgusu ───────────────────────────────────────
    u64            hash = board_.hash();
    const TTEntry* tte  = tt_.probe(hash);
    Move           tt_move = MOVE_NONE;
    i32            tt_score = SCORE_NONE;

    if (tte) {
        stats_.tt_hits++;
        tt_move  = tte->move;
        tt_score = tte->score;
        // Mat skorunu ply'ya normalize et (saklanan skor ply-bağımsız)
        if (tt_score >  SCORE_MATE - 500) tt_score -= ply;
        if (tt_score < -SCORE_MATE + 500) tt_score += ply;

        if (!pv_node && tte->depth >= depth) {
            if (tte->flag == TT_EXACT) {
                return tt_score;
            }
            if (tte->flag == TT_LOWER && tt_score >= beta) {
                stats_.tt_cuts++;
                return tt_score;
            }
            if (tte->flag == TT_UPPER && tt_score <= alpha) {
                return tt_score;
            }
        }
    }

    // IIR: TT miss durumunda depth azalt (daha hızlı iterasyon)
    if (!tte && depth >= 4 && !pv_node) depth--;

    // ── Statik Değerlendirme ───────────────────────────────────────────────
    i32 static_eval = SCORE_NONE;
    if (!in_check) {
        static_eval = tte ? tte->eval : evaluator_.evaluate(board_, board_.side_to_move());
        stack_[ply].static_eval = static_eval;
    }

    // Improving: bu pozisyon 2 hamle öncesinden iyi mi?
    bool improving = false;
    if (!in_check && ply >= 2) {
        improving = (static_eval > stack_[ply-2].static_eval);
    }

    // ── Pruning (şah altında değilken, PV düğümünde değilken) ─────────────
    if (!pv_node && !in_check && static_eval != SCORE_NONE) {

        // Ters futility (statik değerlendirme beta'nın üstündeyse kes)
        // İyileşiyorsak daha küçük marjla kes; improving=true → depth-1
        if (depth <= 7 && static_eval - 100 * (depth - (int)improving) >= beta)
            return static_eval;

        // Razoring (depth <= 3)
        if (depth <= 3) {
            i32 razor_score;
            if (try_razoring(depth, alpha, static_eval, in_check, razor_score))
                return razor_score;
        }

        // Null Move Pruning (depth >= 3)
        if (depth >= 3) {
            i32 null_score;
            if (try_null_move(depth, beta, static_eval, in_check, pv_node, ply, null_score))
                return null_score;
        }

        // Probcut (depth >= 5)
        if (depth >= 5) {
            i32 pc_score;
            if (try_probcut(depth, beta, in_check, ply, static_eval, pc_score))
                return pc_score;
        }
    }

    // ── Hamle döngüsü ──────────────────────────────────────────────────────
    MoveList ml;
    if (in_check)
        MoveGenerator::generate_evasions(board_, ml);
    else
        MoveGenerator::generate_pseudo(board_, ml);

    Move prev_move = (ply > 0) ? stack_[ply - 1].current_move : MOVE_NONE;
    orderer_.score_moves(ml, board_, tt_move, ply, board_.side_to_move(),
                         prev_move, cont_hist_);

    i32  best_score = -SCORE_INFINITE;
    Move best_move  = MOVE_NONE;
    int  tried      = 0;
    MoveList tried_quiets;   // Killer/history güncelleme için
    MoveList tried_captures; // Capture history güncelleme için

    PVLine child_pv;
    child_pv.clear();

    for (int mi = 0; mi < ml.size(); mi++) {
        auto& me = orderer_.next_move(ml, mi);
        Move m = me.move;
        if (m == stack_[ply].excluded_move) continue;

        Square to   = move_to(m);
        bool is_capture = (board_.piece_on(to) != NO_PIECE);

        // SEE futility: sığ aramada kayıplı yemeler atla (do_move öncesi)
        if (depth <= 2 && is_capture && !root && !in_check
            && m != tt_move && move_type(m) != MT_PROMO
            && orderer_.see(board_, m) < 0)
            continue;

        // ── Singular Extension ──────────────────────────────────────────
        int extension = 0;
        if (!root && depth >= 8 && m == tt_move
            && tt_score != SCORE_NONE && !is_mate_score(tt_score)
            && tte && tte->flag == TT_LOWER && tte->depth >= depth - 3)
        {
            i32 s_beta   = tt_score - depth;
            i32 se_score = is_singular_score(m, depth, tt_score, ply);
            if (!stopped_.load() && se_score < s_beta) {
                // Çok tekil: se_score çok düşükse double extension
                extension = (!pv_node && se_score < s_beta - 20) ? 2 : 1;
            }
        }

        // History pruning: geçmişi çok olumsuz sessiz hamleler budanır
        // depth<=2: düşük eşik, depth==3: daha sıkı eşik
        if (!pv_node && !in_check && tried >= 1
            && move_type(m) != MT_PROMO && !board_.piece_on(to))
        {
            if ((depth <= 2 && me.score < -2000) ||
                (depth == 3 && me.score < -4000))
                continue;
        }

        // ── Hamleyi uygula ──────────────────────────────────────────────
        Color us = board_.side_to_move(); // Hamleyi yapan (do_move ÖNCE)
        StateInfo new_st;
        board_.do_move(m, new_st, me.promo);
        tried++;

        // Şah altına girdik mi? (yasal kontrol)
        // us: hamleyi yapan taraf; do_move sonrası stm = rakip
        Square ks = board_.king_sq(us);
        if (ks == SQ_NONE || board_.is_attacked(ks, board_.side_to_move())) {
            board_.undo_move(m);
            tried--;
            continue; // Yasadışı hamle
        }

        // Hamle rakip şahı tehdit ediyor mu? (LMR kararı için)
        // do_move sonrası stm = rakip; attacker = us
        bool gives_check = board_.is_attacked(board_.king_sq(board_.side_to_move()), us);

        // Check extension: şah veren hamleler daha derin aranır
        if (!extension && gives_check && depth >= 4)
            extension = 1;

        // Futility: sığ sessiz hamleler için erken kes
        // İyileşiyorsak büyük marj (az budama); değilse küçük marj (fazla budama)
        if (depth <= 5 && !pv_node && !in_check && !gives_check
            && !is_capture && move_type(m) != MT_PROMO
            && tried >= 2 && static_eval != SCORE_NONE
            && static_eval + (improving ? 90 : 65) * depth < alpha)
        {
            board_.undo_move(m);
            tried--;
            continue;
        }

        // FMC (Futility Move Count): derinlik + sessiz hamle sayısına göre budama
        // tried_quiets.size() = şimdiye kadar denenen sessiz hamle sayısı
        if (!pv_node && !in_check && !gives_check
            && !is_capture && move_type(m) != MT_PROMO
            && static_eval != SCORE_NONE && static_eval < alpha - 20)
        {
            static const int FMC_LIMIT[9] = { 0, 5, 8, 12, 17, 22, 28, 35, 42 };
            int lim = (depth <= 8) ? FMC_LIMIT[depth] : 42 + depth * 5;
            // İyileşiyorsak daha fazla hamle araştır; iyileşmiyorsak daha az
            if (improving) lim = lim * 3 / 2;
            if ((int)tried_quiets.size() >= lim) {
                board_.undo_move(m);
                tried--;
                continue;
            }
        }

        i32 score;

        // LMP: düşük derinlikte şah vermeyen geç sessiz hamleler atla
        if (!pv_node && !in_check && !gives_check && !is_capture
            && move_type(m) != MT_PROMO && depth <= 4)
        {
            static const int LMP_LIMIT[5] = { 0, 4, 7, 12, 18 };
            int lmp_lim = LMP_LIMIT[depth];
            if (improving) lmp_lim += lmp_lim / 2;
            if ((int)tried_quiets.size() >= lmp_lim) {
                board_.undo_move(m);
                tried--;
                continue;
            }
        }

        // ── Late Move Reductions (LMR) ──────────────────────────────────
        if (tried >= 3 && depth >= 3 && !in_check && !gives_check
            && !is_capture && move_type(m) != MT_PROMO)
        {
            int R = lmr_reduction(depth, tried, pv_node, gives_check, is_capture);
            R -= improving  ? 1 : 0;  // İyileşme: daha az azalt
            R += cut_node   ? 1 : 0;  // Cut düğümü: daha agresif azalt
            // Geçmiş skoru çok olumsuzsa daha agresif indir
            if (me.score < -5000) R += 1;
            R  = std::max(1, R);

            // LMR ile sığ arama
            score = -search(depth - 1 - R, -alpha - 1, -alpha,
                            ply + 1, false, true);
            stats_.lmr_count++;

            // Umut verirse tam derinlikte tekrar ara
            if (score > alpha && R > 0)
                score = -search(depth - 1 + extension, -alpha - 1, -alpha,
                                ply + 1, false, !cut_node);
        } else {
            // İlk hamle veya erken hamleler — tam arama
            if (tried == 1 || pv_node) {
                score = -search(depth - 1 + extension, -beta, -alpha,
                                ply + 1, pv_node, false, pv_node ? &child_pv : nullptr);
            } else {
                // Zero window
                score = -search(depth - 1 + extension, -alpha - 1, -alpha,
                                ply + 1, false, !cut_node);
                if (score > alpha && score < beta)
                    score = -search(depth - 1 + extension, -beta, -alpha,
                                    ply + 1, true, false, &child_pv);
            }
        }

        board_.undo_move(m);
        if (stopped_.load()) return SCORE_NONE;

        if (!is_capture)
            tried_quiets.push(m);
        else
            tried_captures.push(m);

        // ── Skor güncelle ───────────────────────────────────────────────
        if (score > best_score) {
            best_score = score;
            best_move  = m;

            if (score > alpha) {
                alpha = score;
                if (pv_node) {
                    if (root) {
                        root_pv_.copy_from(m, child_pv);
                    } else if (pv_line) {
                        pv_line->copy_from(m, child_pv);
                    }
                }
                if (alpha >= beta) {
                    // Beta kesimi
                    update_stats(depth, m, score, alpha0, beta, ply,
                                 tried_quiets, tried_captures);
                    break;
                }
            }
        }
    } // hamle döngüsü sonu

    // ── Mat / Pat ──────────────────────────────────────────────────────────
    if (best_score == -SCORE_INFINITE) {
        // Hiç yasal hamle yok
        if (in_check)
            return -SCORE_MATE + ply; // Mat yedik
        else
            return SCORE_DRAW;        // Pat
    }

    // ── TT'ye yaz ─────────────────────────────────────────────────────────
    TTFlag flag = (best_score >= beta)   ? TT_LOWER :
                  (best_score <= alpha0) ? TT_UPPER : TT_EXACT;

    tt_.store(hash, depth, flag, best_score,
              static_eval != SCORE_NONE ? static_eval : 0, best_move, ply);

    return best_score;
}

// ─────────────────────────────────────────────────────────────────────────────
//  Quiescence Search
// ─────────────────────────────────────────────────────────────────────────────
i32 Searcher::qsearch(i32 alpha, i32 beta, int ply) {
    if (time_check()) return SCORE_NONE;
    if (ply >= MAX_PLY) return evaluator_.evaluate(board_, board_.side_to_move());

    // Citadel beraberlik kontrolü (qsearch'te de)
    if (board_.king_on_citadel(board_.side_to_move())) return 0;
    if (board_.king_on_citadel(~board_.side_to_move())) return 0;

    stats_.qnodes++;

    bool in_check = board_.in_check();
    i32 alpha0 = alpha;

    // TT sorgusu
    u64 qhash = board_.hash();
    const TTEntry* qtte = tt_.probe(qhash);
    Move qtt_move = MOVE_NONE;
    if (qtte) {
        stats_.tt_hits++;
        i32 qtt_score = qtte->score;
        if (qtt_score >  SCORE_MATE - 500) qtt_score -= ply;
        if (qtt_score < -SCORE_MATE + 500) qtt_score += ply;
        qtt_move = qtte->move;
        if (qtte->depth >= 0) { // qsearch depth = 0
            if (qtte->flag == TT_EXACT)                          return qtt_score;
            if (qtte->flag == TT_LOWER && qtt_score >= beta)     return qtt_score;
            if (qtte->flag == TT_UPPER && qtt_score <= alpha)    return qtt_score;
        }
    }

    // Şah altında değilse stand-pat ile alt sınır belirle
    i32 stand_pat = 0;
    if (!in_check) {
        stand_pat = qtte ? (i32)qtte->eval : evaluator_.evaluate(board_, board_.side_to_move());
        if (stand_pat >= beta)  return stand_pat;
        if (stand_pat > alpha)  alpha = stand_pat;
    }

    // Şah altında → tüm kaçış hamlelerini üret; değilse → sadece yemeler
    MoveList ml;
    if (in_check)
        MoveGenerator::generate_evasions(board_, ml);
    else
        MoveGenerator::generate_captures(board_, ml);

    // MVV-LVA sıralama (sadece yeme modunda)
    if (!in_check) {
        for (auto& me : ml) {
            Piece victim   = board_.piece_on(move_to(me.move));
            Piece attacker = board_.piece_on(move_from(me.move));
            me.score = (victim != NO_PIECE)
                ? PIECE_VALUE[piece_type(victim)] * 10 - PIECE_VALUE[piece_type(attacker)]
                : 0;
        }
    }

    int legal = 0;
    for (int qi = 0; qi < ml.size(); qi++) {
        auto& me = orderer_.next_move(ml, qi);
        Move m = me.move;
        Square to = move_to(m);

        // Delta + SEE pruning: sadece şah altında değilken
        if (!in_check) {
            Piece victim = board_.piece_on(to);
            if (victim != NO_PIECE) {
                // Delta pruning: kurbanı kazansak bile alpha'yı geçemeyiz
                i32 delta = stand_pat + PIECE_VALUE[piece_type(victim)] + 200;
                if (delta < alpha) continue;
                // SEE pruning: kayıplı yakalamayı araştırma
                if (MoveOrderer::see(board_, m) < 0) continue;
            }
        }

        Color us = board_.side_to_move();
        StateInfo new_st;
        board_.do_move(m, new_st, me.promo);

        if (board_.is_attacked(board_.king_sq(us), board_.side_to_move())) {
            board_.undo_move(m);
            continue;
        }
        legal++;

        i32 score = -qsearch(-beta, -alpha, ply + 1);
        board_.undo_move(m);
        if (stopped_.load()) return SCORE_NONE;

        if (score > alpha) {
            alpha = score;
            if (alpha >= beta) return alpha;
        }
    }

    // Şah altında yasal hamle yoksa → mat
    if (in_check && legal == 0) return -SCORE_MATE + ply;

    // TT'ye yaz (depth=0 ile qsearch sonucu)
    TTFlag qflag = (alpha >= beta)   ? TT_LOWER :
                   (alpha <= alpha0) ? TT_UPPER : TT_EXACT;
    tt_.store(qhash, 0, qflag, alpha,
              in_check ? 0 : stand_pat, qtt_move, ply);

    return alpha;
}

// ─────────────────────────────────────────────────────────────────────────────
//  Pruning Yardımcıları
// ─────────────────────────────────────────────────────────────────────────────

bool Searcher::try_razoring(int depth, i32 alpha, i32 static_eval,
                             bool in_check, i32& score)
{
    if (in_check) return false;
    static const i32 margins[] = {0, 300, 500, 750};
    if (depth > 3 || static_eval + margins[depth] > alpha) return false;

    score = qsearch(alpha - 1, alpha, 0);
    return score < alpha;
}

bool Searcher::try_null_move(int depth, i32 beta, i32 static_eval,
                              bool in_check, bool pv_node, int ply, i32& score)
{
    if (in_check || pv_node) return false;
    if (static_eval < beta) return false;

    // Zugzwang riski: yalnızca şah + piyon varsa NMP tehlikeli
    // En az bir süvari taş (şah+piyon dışı) varsa devam et
    {
        Color us = board_.side_to_move();
        int nonpawn = 0;
        for (int sq = 0; sq < BOARD_NORMAL; sq++) {
            Piece p = board_.piece_on(sq);
            if (p != NO_PIECE && piece_color(p) == us) {
                PieceType pt = piece_type(p);
                if (pt != SAH && pt != PIYON) nonpawn++;
            }
        }
        if (nonpawn == 0) return false;
    }

    // R değeri: depth ve materyal farkına göre adaptif
    i32 R = 3 + depth / 6 + std::min((i32)3, (static_eval - beta) / 200);

    StateInfo new_st;
    board_.do_null_move(new_st);
    score = -search(depth - R, -beta, -beta + 1, ply + 1, false, !false);
    board_.undo_null_move();

    if (stopped_.load()) return false;

    if (score >= beta) {
        stats_.null_cuts++;
        // Mate skorunu döndürme (verifikasyon gerekebilir)
        return !is_mate_score(score);
    }
    return false;
}

bool Searcher::try_probcut(int depth, i32 beta, bool in_check,
                            int ply, i32 static_eval, i32& score)
{
    if (in_check) return false;
    i32 pc_beta = beta + 200;

    MoveList ml;
    MoveGenerator::generate_captures(board_, ml);

    for (auto& me : ml) {
        Move m = me.move;
        if (MoveOrderer::see(board_, m) < pc_beta - static_eval) continue;

        StateInfo new_st;
        board_.do_move(m, new_st, me.promo);
        Color us = ~board_.side_to_move();
        if (board_.is_attacked(board_.king_sq(us), board_.side_to_move())) {
            board_.undo_move(m);
            continue;
        }

        score = -search(depth - 4, -pc_beta, -pc_beta + 1, ply + 1, false, true);
        board_.undo_move(m);

        if (stopped_.load()) return false;
        if (score >= pc_beta) return true;
    }
    return false;
}

int Searcher::lmr_reduction(int depth, int move_idx, bool pv_node,
                             bool gives_check, bool is_capture) const
{
    if (gives_check || is_capture) return 0;
    int d = std::min(depth, MAX_PLY - 1);
    int m = std::min(move_idx, MAX_MOVES - 1);
    int R = LMR_TABLE[d][m];
    if (pv_node) R--;
    return std::max(0, R);
}

bool Searcher::is_singular(Move m, int depth, i32 tt_score, int ply) {
    i32 s_beta = tt_score - depth;
    return is_singular_score(m, depth, tt_score, ply) < s_beta;
}

i32 Searcher::is_singular_score(Move m, int depth, i32 tt_score, int ply) {
    i32 s_beta = tt_score - depth;
    stack_[ply].excluded_move = m;
    i32 score = search(depth / 2, s_beta - 1, s_beta, ply, false, true);
    stack_[ply].excluded_move = MOVE_NONE;
    if (stopped_.load()) return s_beta; // Durdurulduysa "tekil değil" döndür
    stats_.singular_ext++;
    return score;
}

// ─────────────────────────────────────────────────────────────────────────────
//  İstatistik Güncelleme (beta kesimi sonrası)
// ─────────────────────────────────────────────────────────────────────────────
void Searcher::update_stats(int depth, Move best, i32 best_score,
                             i32 alpha0, i32 beta, int ply,
                             const MoveList& tried_quiets,
                             const MoveList& tried_captures)
{
    Color  us             = board_.side_to_move();
    bool   best_is_capture = (board_.piece_on(move_to(best)) != NO_PIECE);

    if (!best_is_capture) {
        // Killer güncelle
        orderer_.add_killer(best, ply);

        // History güncelle: iyi hamle +, denenen ama kötü hamleler -
        orderer_.update_history(best, depth, true, us);
        for (auto& me : tried_quiets) {
            if (me.move != best)
                orderer_.update_history(me.move, depth, false, us);
        }

        // CMH güncelle: [taş_tipi][hedef] için devam bonusu
        {
            PieceType pt = piece_type(board_.piece_on(move_from(best)));
            if (pt != NO_PIECE_TYPE) {
                i32 bonus = depth * depth;
                i32& h    = cont_hist_[pt][move_to(best)];
                h += bonus - h * std::abs(bonus) / 16384;
            }
            for (auto& me : tried_quiets) {
                if (me.move != best) {
                    PieceType mpt = piece_type(board_.piece_on(move_from(me.move)));
                    if (mpt != NO_PIECE_TYPE) {
                        i32 bonus = depth * depth;
                        i32& mh   = cont_hist_[mpt][move_to(me.move)];
                        mh -= bonus - mh * std::abs(bonus) / 16384;
                    }
                }
            }
        }

        // Counter-move güncelle
        if (ply > 0) {
            Move prev = stack_[ply-1].current_move;
            orderer_.update_counter(prev, best);
        }
    } else {
        // Capture history: en iyi yeme + (diğer denemeler -)
        PieceType cap_pt = piece_type(board_.piece_on(move_to(best)));
        orderer_.update_cap_history(best, depth, true, us, cap_pt);
    }

    // Denenen yakalamalar için capture history cezası (en iyi değilse)
    for (auto& me : tried_captures) {
        if (me.move != best) {
            Piece victim = board_.piece_on(move_to(me.move));
            if (victim != NO_PIECE)
                orderer_.update_cap_history(me.move, depth, false, us,
                                            piece_type(victim));
        }
    }

    (void)best_score; (void)alpha0; (void)beta;
}

bool Searcher::is_bare_king(Color c) const {
    // Şah dışında taş kalmadı mı?
    for (int pt = KALE; pt < PIECE_TYPE_NB; pt++) {
        // piece_list erişimi için Board'a getter gerekir
        // Şimdilik tahtayı tara
        for (int r = 0; r < BOARD_RANKS; r++)
            for (int f = 0; f < BOARD_FILES; f++) {
                Square sq = make_sq(f, r);
                Piece  p  = board_.piece_on(sq);
                if (p != NO_PIECE && piece_color(p) == c && piece_type(p) != SAH)
                    return false;
            }
    }
    return true;
}

i32 Searcher::static_eval(const Board& b) {
    return evaluator_.evaluate(b, b.side_to_move());
}

} // namespace Apex
