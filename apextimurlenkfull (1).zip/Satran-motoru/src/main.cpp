#include "uci.h"
#include "movegen.h"
#include "evaluate.h"
#include "search.h"
#include "tt.h"
#include <iostream>
#include <chrono>

// Timurlenk benchmark pozisyonları (başlangıç + çeşitli orta oyun pozisyonları)
static const char* BENCH_FENS[] = {
    // Başlangıç pozisyonu
    "RE2WNCZTFRK/ZT1PNWECVKR/PPPPPPPPPPP/11/11/11/11/ppppppppppp/zt1pnwecvkr/re2wncztfrk w wb - 0 1",
    // Beyaz açılış hamlelerinden sonra
    "RE2WNCZTFRK/ZT1PNWECVKR/PPPPPP1PPPP/11/11/6P4/11/ppppppppppp/zt1pnwecvkr/re2wncztfrk b wb - 0 2",
    // Orta oyun pozisyonu
    "R3WN1TFRK/ZT2PNEC1KR/PPP2PPPPPP/11/3pp5/3PP5/11/pp1pp1ppppp/zt2pnec1kr/r3wn1tfrk w - - 4 8",
    // Piyon yapısı testi
    "R4N1TFRK/ZT3NECVKR/PPPPPP1PPPP/11/11/5p5/11/pppppp1pppp/zt3necvkr/r4n1tfrk w wb - 0 5",
    // Kale açık hat
    "R4NZTFRK/ZT4NECVKR/PPPPPP1PPPP/11/11/11/11/pp3pppppp/zt4necvkr/r4nztfrk w w - 2 10",
};
static const int BENCH_DEPTH = 6;
static const int BENCH_COUNT = 5;

int main(int argc, char* argv[]) {
    Apex::Zobrist.init();
    Apex::init_lmr_table();
    Apex::init_pst();

    std::cout.setf(std::ios::unitbuf);
    std::cin.setf(std::ios::unitbuf);

    if (argc > 1 && std::string(argv[1]) == "bench") {
        std::cout << "Apex Timurlenk " << Apex::ENGINE_VERSION
                  << " — Benchmark (depth " << BENCH_DEPTH << ")\n";

        Apex::TranspositionTable tt;
        tt.resize(64);
        Apex::Board board;
        board.setup();
        Apex::Searcher searcher(board, tt);

        Apex::u64 total_nodes = 0;
        auto t0 = std::chrono::steady_clock::now();

        for (int pos = 0; pos < BENCH_COUNT; pos++) {
            if (!board.from_string(BENCH_FENS[pos])) {
                board.setup(); // FEN geçersizse başlangıç pozisyonu
            }
            std::cout << "Position " << (pos+1) << "/" << BENCH_COUNT << "\n";

            Apex::SearchLimits lim;
            lim.depth = BENCH_DEPTH;

            searcher.set_info_callback([&](int depth, int, Apex::i32 score,
                                           Apex::u64 nodes, int64_t ms, const Apex::PVLine&) {
                total_nodes = nodes;
                std::cout << "info depth " << depth
                          << " score cp " << score
                          << " nodes " << nodes
                          << " time " << ms << "\n";
            });
            searcher.start_search(lim);
        }

        auto t1 = std::chrono::steady_clock::now();
        int64_t ms = std::chrono::duration_cast<std::chrono::milliseconds>(t1 - t0).count();
        int64_t nps = ms > 0 ? (total_nodes * 1000 / ms) : 0;

        std::cout << "\nBenchmark tamamlandı:\n"
                  << "  Toplam node: " << total_nodes << "\n"
                  << "  Toplam süre: " << ms << " ms\n"
                  << "  NPS:         " << nps << "\n";
        return 0;
    }

    Apex::UCI uci;
    uci.loop();
    return 0;
}
