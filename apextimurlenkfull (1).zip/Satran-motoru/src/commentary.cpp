#include "commentary.h"
#include <cstdio>
#include <sstream>
#include <chrono>
#include <thread>

namespace Apex {

// Komut satırı argümanını shell single-quote ile escape et
// Kullanım: script yolu için — shell injection önlemi
static std::string sanitize_shell_arg(const std::string& s) {
    std::string r = "'";
    for (char c : s) {
        if (c == '\'') r += "'\\''";
        else r += c;
    }
    r += "'";
    return r;
}

// JSON string değerini hem JSON hem shell single-quote için escape et
// Çıktı doğrudan JSON object'in "field":"ÇIKIŞ" yerine yazılır
// Strateji: JSON kaçışları (\ ve ") + shell bağlamındaki ' karakterini kır-ve-yapıştır
static std::string json_str_escape(const std::string& s) {
    std::string r;
    for (unsigned char c : s) {
        if      (c == '\\') r += "\\\\";     // JSON: ters eğik çizgi
        else if (c == '"')  r += "\\\"";     // JSON: çift tırnak
        else if (c == '\'') r += "'\\''";    // Shell single-quote bağlamı
        else if (c < 0x20) {                 // Kontrol karakterleri
            char buf[8]; snprintf(buf, sizeof(buf), "\\u%04x", c); r += buf;
        } else r += c;
    }
    return r;
}

// JSON'dan belirtilen string alanını çıkar (minimal, bağımlılıksız)
// "field": "value" ve "field":"value" her iki formatı da destekler
static std::string parse_field(const std::string& json, const std::string& field) {
    // Önce "field":"value" dene, sonra "field": "value"
    for (const auto& key : { "\"" + field + "\":\"", "\"" + field + "\": \"" }) {
        auto pos = json.find(key);
        if (pos == std::string::npos) continue;
        pos += key.size();
        auto end = json.find('"', pos);
        if (end == std::string::npos) continue;
        return json.substr(pos, end - pos);
    }
    return "";
}

static std::string parse_commentary(const std::string& json) {
    return parse_field(json, "commentary");
}

std::string CommentaryBridge::call_bridge(const std::string& script,
                                           const std::string& persona,
                                           int score, int depth) {
    // echo '{"persona":"...","score":N,"depth":N}' | python3 bridge.py
    std::ostringstream cmd;
    cmd << "echo '{\"persona\":\"" << json_str_escape(persona)
        << "\",\"score\":"         << score
        << ",\"depth\":"           << depth
        << "}' | python3 "         << sanitize_shell_arg(script)
        << " 2>/dev/null";

    FILE* pipe = popen(cmd.str().c_str(), "r");
    if (!pipe) return "";

    char buf[512] = {};
    std::string output;
    while (fgets(buf, sizeof(buf), pipe))
        output += buf;
    pclose(pipe);

    return parse_commentary(output);
}

std::string CommentaryBridge::call_bridge_time(const std::string& script,
                                                const std::string& persona,
                                                int phase_score,
                                                int material_balance) {
    std::ostringstream cmd;
    cmd << "echo '{\"tool\":\"time\",\"persona\":\"" << json_str_escape(persona)
        << "\",\"phase_score\":"   << phase_score
        << ",\"material_balance\":" << material_balance
        << "}' | python3 "          << sanitize_shell_arg(script)
        << " 2>/dev/null";

    FILE* pipe = popen(cmd.str().c_str(), "r");
    if (!pipe) return "normal";

    char buf[256] = {};
    std::string output;
    while (fgets(buf, sizeof(buf), pipe))
        output += buf;
    pclose(pipe);

    std::string decision = parse_field(output, "decision");
    if (decision.empty()) return "normal";
    return decision;
}

void CommentaryBridge::request_time_async(const std::string& persona,
                                           int phase_score, int material_balance,
                                           Callback cb) {
    if (script_path_.empty()) return;

    pending_.fetch_add(1);
    std::string script = script_path_;

    std::thread([this, script, persona, phase_score, material_balance,
                 cb = std::move(cb)]() {
        std::string result = call_bridge_time(script, persona,
                                              phase_score, material_balance);
        if (cb) cb(result);
        pending_.fetch_sub(1);
    }).detach();
}

std::string CommentaryBridge::call_bridge_opening(const std::string& script,
                                                   const std::string& persona,
                                                   int move_num, bool is_white) {
    std::ostringstream cmd;
    cmd << "echo '{\"tool\":\"opening\",\"persona\":\"" << json_str_escape(persona)
        << "\",\"move_num\":"  << move_num
        << ",\"color\":\""     << (is_white ? "w" : "b")
        << "\"}' | python3 "   << sanitize_shell_arg(script)
        << " 2>/dev/null";

    FILE* pipe = popen(cmd.str().c_str(), "r");
    if (!pipe) return "solid";

    char buf[256] = {};
    std::string output;
    while (fgets(buf, sizeof(buf), pipe))
        output += buf;
    pclose(pipe);

    std::string style = parse_field(output, "style");
    if (style.empty()) return "solid";
    return style;
}

std::string CommentaryBridge::call_bridge_citadel(const std::string& script,
                                                   const std::string& persona,
                                                   int phase, int king_dist, int material) {
    std::ostringstream cmd;
    cmd << "echo '{\"tool\":\"citadel\",\"persona\":\"" << json_str_escape(persona)
        << "\",\"phase\":"     << phase
        << ",\"king_dist\":"   << king_dist
        << ",\"material\":"    << material
        << "}' | python3 "     << sanitize_shell_arg(script)
        << " 2>/dev/null";

    FILE* pipe = popen(cmd.str().c_str(), "r");
    if (!pipe) return "consolidate";

    char buf[256] = {};
    std::string output;
    while (fgets(buf, sizeof(buf), pipe))
        output += buf;
    pclose(pipe);

    std::string strategy = parse_field(output, "strategy");
    if (strategy.empty()) return "consolidate";
    return strategy;
}

std::string CommentaryBridge::call_bridge_contempt(const std::string& script,
                                                    const std::string& persona,
                                                    int score_trend, int move_num) {
    std::ostringstream cmd;
    cmd << "echo '{\"tool\":\"contempt\",\"persona\":\"" << json_str_escape(persona)
        << "\",\"score_trend\":" << score_trend
        << ",\"move_num\":"      << move_num
        << "}' | python3 "       << sanitize_shell_arg(script)
        << " 2>/dev/null";

    FILE* pipe = popen(cmd.str().c_str(), "r");
    if (!pipe) return "hold";

    char buf[256] = {};
    std::string output;
    while (fgets(buf, sizeof(buf), pipe))
        output += buf;
    pclose(pipe);

    std::string action = parse_field(output, "action");
    if (action.empty()) return "hold";
    return action;
}

void CommentaryBridge::request_opening_async(const std::string& persona,
                                              int move_num, bool is_white,
                                              Callback cb) {
    if (script_path_.empty()) return;

    pending_.fetch_add(1);
    std::string script = script_path_;

    std::thread([this, script, persona, move_num, is_white,
                 cb = std::move(cb)]() {
        std::string result = call_bridge_opening(script, persona, move_num, is_white);
        if (cb) cb(result);
        pending_.fetch_sub(1);
    }).detach();
}

void CommentaryBridge::request_citadel_async(const std::string& persona,
                                              int phase, int king_dist, int material,
                                              Callback cb) {
    if (script_path_.empty()) return;

    pending_.fetch_add(1);
    std::string script = script_path_;

    std::thread([this, script, persona, phase, king_dist, material,
                 cb = std::move(cb)]() {
        std::string result = call_bridge_citadel(script, persona, phase, king_dist, material);
        if (cb) cb(result);
        pending_.fetch_sub(1);
    }).detach();
}

void CommentaryBridge::request_contempt_async(const std::string& persona,
                                               int score_trend, int move_num,
                                               Callback cb) {
    if (script_path_.empty()) return;

    pending_.fetch_add(1);
    std::string script = script_path_;

    std::thread([this, script, persona, score_trend, move_num,
                 cb = std::move(cb)]() {
        std::string result = call_bridge_contempt(script, persona, score_trend, move_num);
        if (cb) cb(result);
        pending_.fetch_sub(1);
    }).detach();
}

void CommentaryBridge::request_async(const std::string& persona, int score,
                                      int depth, Callback cb) {
    if (script_path_.empty()) return;

    pending_.fetch_add(1);
    std::string script = script_path_;

    std::thread([this, script, persona, score, depth, cb = std::move(cb)]() {
        std::string result = call_bridge(script, persona, score, depth);
        if (!result.empty() && cb)
            cb(result);
        pending_.fetch_sub(1);
    }).detach();
}

void CommentaryBridge::wait() {
    // Async thread'lerin bitmesini bekle (en fazla 1 saniye)
    auto deadline = std::chrono::steady_clock::now() + std::chrono::seconds(1);
    while (pending_.load() > 0 &&
           std::chrono::steady_clock::now() < deadline)
        std::this_thread::sleep_for(std::chrono::milliseconds(50));
}

} // namespace Apex
