#include "evaluate.h"
#include "nnue.h"
#include "movegen.h"
#include <cmath>
#include <cstring>
#include <algorithm>

namespace Apex {

PSTTable PST[PIECE_TYPE_NB];
i32 KING_SAFETY_TABLE[64];

// ── PST Başlatma ──────────────────────────────────────────────────────────
// İndeks: rank * 11 + file (beyaz perspektifi, rank 0 = beyaz başlangıç)
void init_pst() {
    std::memset(PST, 0, sizeof(PST));

    // Kral güvenlik tablosu: saldırı birimi → ceza (quadratic)
    for (int i = 0; i < 64; i++)
        KING_SAFETY_TABLE[i] = (i32)std::min(i * i * 4, 500);

    // ── Piyon PST ────────────────────────────────────────────────────────
    // Rank bonusu: ilerleme ödüllendirilir
    static const i16 pawn_rank_mg[10] = { 0, 0, 5, 10, 15, 25, 35, 50, 70, 0 };
    static const i16 pawn_rank_eg[10] = { 0, 0, 8, 15, 22, 35, 55, 80,110, 0 };
    // Merkez file bonusu (file 3-7)
    static const i16 pawn_file_mg[11] = { -5,-3, 0, 3, 5, 7, 5, 3, 0,-3,-5 };
    for (int r = 0; r < BOARD_RANKS; r++) {
        for (int f = 0; f < BOARD_FILES; f++) {
            int idx = r * BOARD_FILES + f;
            PST[PIYON].mg[idx] = pawn_rank_mg[r] + pawn_file_mg[f];
            PST[PIYON].eg[idx] = pawn_rank_eg[r];
        }
    }

    // ── At PST ───────────────────────────────────────────────────────────
    // Merkez (file 3-7, rank 2-7) tercih edilir; köşeler ceza alır
    for (int r = 0; r < BOARD_RANKS; r++) {
        for (int f = 0; f < BOARD_FILES; f++) {
            int idx = r * BOARD_FILES + f;
            int cf = f - 5, cr = r - 4; // Merkeze uzaklık (file 5, rank 4 merkez)
            int dist = std::abs(cf) + std::abs(cr);
            i16 val_mg = (i16)std::max(-30, 25 - dist * 8);
            i16 val_eg = (i16)std::max(-25, 20 - dist * 7);
            PST[AT].mg[idx] = val_mg;
            PST[AT].eg[idx] = val_eg;
        }
    }

    // ── Deve PST ─────────────────────────────────────────────────────────
    // 3+1 atlayan taş; merkez ona 4 farklı yön sağlar — güçlü teşvik
    for (int r = 0; r < BOARD_RANKS; r++) {
        for (int f = 0; f < BOARD_FILES; f++) {
            int idx = r * BOARD_FILES + f;
            int cf = f - 5, cr = r - 4;
            int dist = std::abs(cf) + std::abs(cr);
            PST[DEVE].mg[idx] = (i16)std::max(-25, 22 - dist * 5);
            PST[DEVE].eg[idx] = (i16)std::max(-20, 18 - dist * 4);
        }
    }

    // ── Fil PST ──────────────────────────────────────────────────────────
    // Renk bağımlı; tek renk kare kalır; açık pozisyon tercih
    for (int r = 0; r < BOARD_RANKS; r++) {
        for (int f = 0; f < BOARD_FILES; f++) {
            int idx = r * BOARD_FILES + f;
            int cf = f - 5, cr = r - 4;
            int dist = std::abs(cf) + std::abs(cr);
            PST[FIL].mg[idx] = (i16)std::max(-15, 12 - dist * 5);
            PST[FIL].eg[idx] = (i16)std::max(-12, 10 - dist * 4);
        }
    }

    // ── Savaş Makinesi PST ────────────────────────────────────────────────
    // Tam 2 kare atlar; kenarda hedef az, merkezde çok — daha dik eğri
    for (int r = 0; r < BOARD_RANKS; r++) {
        for (int f = 0; f < BOARD_FILES; f++) {
            int idx = r * BOARD_FILES + f;
            int cf = f - 5, cr = r - 4;
            int dist = std::abs(cf) + std::abs(cr);
            PST[SAVAS].mg[idx] = (i16)std::max(-18, 15 - dist * 4);
            PST[SAVAS].eg[idx] = (i16)std::max(-15, 12 - dist * 3);
        }
    }

    // ── Ferz PST ─────────────────────────────────────────────────────────
    // Küçük taş; kenar ceza, orta hafif bonus
    for (int r = 0; r < BOARD_RANKS; r++) {
        for (int f = 0; f < BOARD_FILES; f++) {
            int idx = r * BOARD_FILES + f;
            bool edge = (f == 0 || f == 10 || r == 0 || r == 9);
            PST[FERZ].mg[idx] = edge ? -5 : 3;
            PST[FERZ].eg[idx] = edge ? -3 : 2;
        }
    }

    // ── Vali PST ─────────────────────────────────────────────────────────
    for (int r = 0; r < BOARD_RANKS; r++) {
        for (int f = 0; f < BOARD_FILES; f++) {
            int idx = r * BOARD_FILES + f;
            bool edge = (f == 0 || f == 10 || r == 0 || r == 9);
            PST[VALI].mg[idx] = edge ? -4 : 2;
            PST[VALI].eg[idx] = edge ? -3 : 2;
        }
    }

    // ── Talia PST ────────────────────────────────────────────────────────
    // Yatay/dikey tam 2 sıçrama; merkez erişim daha fazla
    for (int r = 0; r < BOARD_RANKS; r++) {
        for (int f = 0; f < BOARD_FILES; f++) {
            int idx = r * BOARD_FILES + f;
            int cf = f - 5, cr = r - 4;
            int dist = std::abs(cf) + std::abs(cr);
            PST[TALIA].mg[idx] = (i16)std::max(-12, 12 - dist * 3);
            PST[TALIA].eg[idx] = (i16)std::max(-10,  9 - dist * 3);
        }
    }

    // ── Kale PST ─────────────────────────────────────────────────────────
    // 10 satırlı tahtada: 8-9. satır çok ileri, 6-7 rakip bölgesi, 4-5 merkez
    for (int r = 0; r < BOARD_RANKS; r++) {
        for (int f = 0; f < BOARD_FILES; f++) {
            int idx = r * BOARD_FILES + f;
            i16 rank_bonus = (r >= 8) ? 30 : (r >= 6) ? 15 : (r >= 4) ? 5 : 0;
            i16 file_bonus = (f >= 4 && f <= 6) ? 5 : 0; // merkez dosyalar
            PST[KALE].mg[idx] = rank_bonus + file_bonus;
            PST[KALE].eg[idx] = (i16)(rank_bonus * 4 / 3); // biraz daha endgame değerli
        }
    }

    // ── Zürafa PST ───────────────────────────────────────────────────────
    // Çapraz+düz uzun menzil: hem dosya hem satır merkezi birlikte değer
    for (int r = 0; r < BOARD_RANKS; r++) {
        for (int f = 0; f < BOARD_FILES; f++) {
            int idx = r * BOARD_FILES + f;
            int fc = std::min(f, 10 - f);   // dosya merkez uzaklığı 0..5
            int rc = std::min(r, 9 - r);    // satır merkez uzaklığı 0..4
            int center = fc + rc;           // 0=kenar köşe, 9=tam merkez
            PST[ZURAFA].mg[idx] = (i16)std::max(-20, center * 3 - 5);
            PST[ZURAFA].eg[idx] = (i16)std::max(-16, center * 2 - 4);
        }
    }

    // ── Şah PST ──────────────────────────────────────────────────────────
    // MG: güvenli köşe/kanat tercih; merkez tehlikeli
    // EG: merkeze yaklaş, rakip piyonları avla
    for (int r = 0; r < BOARD_RANKS; r++) {
        for (int f = 0; f < BOARD_FILES; f++) {
            int idx = r * BOARD_FILES + f;
            // MG: rank 0-1 güvenli (kendi tarafı), file uç güvenli
            bool safe_mg = (r <= 1 && (f <= 2 || f >= 8));
            int center_dist = std::abs(f-5) + std::abs(r-4);
            PST[SAH].mg[idx] = safe_mg ? 15 : (i16)std::max(-40, 5 - center_dist * 6);
            PST[SAH].eg[idx] = (i16)std::max(-10, 30 - center_dist * 5);
        }
    }
}

// ── Persona Ağırlık Çarpanları ────────────────────────────────────────────
// idx: PersonaType int değeri (0=None, 1=Machiavelli, 4=Erlik, 5=Bozkurt...)
// Görev tanımı: idx 0 → Machiavelli ayarları, idx 4 → Bozkurt ayarları
void Evaluator::setPersona(int idx) {
    pw_ = PersonaWeights{}; // Tümünü 1.0'a sıfırla
    switch (idx) {
        case 0: // Machiavelli: kaleye güven, piyonu küçümse
            pw_.rook_mult = 1.15f;
            pw_.pawn_mult = 0.90f;
            break;
        case 4: // Bozkurt: ata ağırlık ver, şah güvenliğini öne çıkar
            pw_.knight_mult      = 1.20f;
            pw_.king_safety_mult = 1.30f;
            break;
        default: // Diğerleri: tüm çarpanlar varsayılan 1.0
            break;
    }
}

// ── Oyun Fazı ────────────────────────────────────────────────────────────
int Evaluator::game_phase(const Board& b) {
    int phase = 0;
    for (int r = 0; r < BOARD_RANKS; r++)
        for (int f = 0; f < BOARD_FILES; f++) {
            Square sq = make_sq(f, r);
            Piece  p  = b.piece_on(sq);
            if (p == NO_PIECE) continue;
            phase += PHASE_WEIGHT[piece_type(p)];
        }
    return std::min(phase, MAX_PHASE);
}

// ── Mobilite Değerlendirmesi ──────────────────────────────────────────────
i32 Evaluator::eval_mobility(const Board& b, Color c, int phase) const {
    int ci = (int)c;
    auto* st = const_cast<StateInfo*>(b.state());

    if (st->mobility_valid[ci])
        return st->mobility_cache[ci];

    i32 score = 0;

    // Piyon ve şah hariç her taş tipi için mobilite say
    for (int pt_int = KALE; pt_int <= VALI; pt_int++) {
        PieceType pt = (PieceType)pt_int;
        for (Square sq : b.pieces(c, pt)) {
            MoveList ml;
            switch (pt) {
                case KALE:   MoveGenerator::gen_kale  (b, sq, c, ml); break;
                case ZURAFA: MoveGenerator::gen_zurafa(b, sq, c, ml); break;
                case TALIA:  MoveGenerator::gen_talia (b, sq, c, ml); break;
                case AT:     MoveGenerator::gen_at    (b, sq, c, ml); break;
                case DEVE:   MoveGenerator::gen_deve  (b, sq, c, ml); break;
                case FIL:    MoveGenerator::gen_fil   (b, sq, c, ml); break;
                case SAVAS:  MoveGenerator::gen_savas (b, sq, c, ml); break;
                case FERZ:   MoveGenerator::gen_ferz  (b, sq, c, ml); break;
                case VALI:   MoveGenerator::gen_vali  (b, sq, c, ml); break;
                default: break;
            }
            int mob = std::clamp((int)ml.size(), 0, 31);
            i32 mg = MOBILITY_BONUS_MG[pt_int][mob];
            i32 eg = MOBILITY_BONUS_EG[pt_int][mob];
            score += (mg * phase + eg * (MAX_PHASE - phase)) / MAX_PHASE;
        }
    }

    // Cache yaz (phase-independent raw score yerine phase-weighted sonuç kaydediyoruz)
    // Phase değişmez aynı pozisyonda, bu nedenle güvenli.
    st->mobility_cache[ci] = score;
    st->mobility_valid[ci] = true;
    return score;
}


// ── Kral Güvenliği Değerlendirmesi ────────────────────────────────────────
i32 Evaluator::eval_king_safety(const Board& b, Color c, int phase) const {
    Square ksq = b.king_sq(c);
    if (ksq == SQ_NONE || !sq_valid(ksq)) return 0;

    Color them = ~c;
    // Endgame'de kral güvenliği daha az kritik
    if (phase < MAX_PHASE / 3) return 0;

    int attack_units = 0;
    int kf = sq_file(ksq), kr = sq_rank(ksq);
    // 5×5 bölge etrafında tara — O(110) yerine O(25)
    for (int dr = -2; dr <= 2; dr++) {
        int r = kr + dr;
        if (r < 0 || r >= BOARD_RANKS) continue;
        for (int df = -2; df <= 2; df++) {
            int f = kf + df;
            if (f < 0 || f >= BOARD_FILES) continue;
            Square sq = make_sq(f, r);
            Piece p = b.piece_on(sq);
            if (p == NO_PIECE || piece_color(p) != them) continue;
            PieceType pt = piece_type(p);
            attack_units += KING_ATTACK_WEIGHT[pt];
        }
    }
    attack_units = std::min(attack_units, 63);
    i32 penalty = KING_SAFETY_TABLE[attack_units];
    // Persona çarpanı: şah güvenliği ağırlığını ayarla
    penalty = (i32)(penalty * pw_.king_safety_mult);

    // Piyon kalkanı: şahın önündeki 3 kare (merkez + yan dosyalar)
    // Her eksik kalkan piyonu için ceza artır
    int shelter_dir = (c == WHITE) ? 1 : -1;
    for (int df = -1; df <= 1; df++) {
        int sf = kf + df, sr = kr + shelter_dir;
        if (sf < 0 || sf >= BOARD_FILES || sr < 0 || sr >= BOARD_RANKS) continue;
        Piece shield = b.piece_on(make_sq(sf, sr));
        if (shield == NO_PIECE || piece_type(shield) != PIYON || piece_color(shield) != c)
            penalty += 18; // Eksik kalkan → ceza artır (KING_SHELTER_PENALTY büyüklüğü)
    }

    // Midgame'de daha ağırlıklı
    return -(penalty * phase / MAX_PHASE);
}

// ── Piyon Yardımcıları ────────────────────────────────────────────────────
static bool is_passed(const Board& b, Square sq, Color c) {
    int f = sq_file(sq), r = sq_rank(sq);
    Color them = ~c;
    int dir = (c == WHITE) ? 1 : -1;
    // Önünde ve komşu dosyalarda rakip piyon var mı?
    for (int r2 = r + dir; r2 >= 0 && r2 < BOARD_RANKS; r2 += dir) {
        for (int df = -1; df <= 1; df++) {
            int f2 = f + df;
            if (f2 < 0 || f2 >= BOARD_FILES) continue;
            Square s2 = make_sq(f2, r2);
            Piece p = b.piece_on(s2);
            if (p != NO_PIECE && piece_color(p) == them && piece_type(p) == PIYON)
                return false;
        }
    }
    return true;
}

static bool is_doubled(const Board& b, Square sq, Color c) {
    int f = sq_file(sq), r = sq_rank(sq);
    for (int r2 = 0; r2 < BOARD_RANKS; r2++) {
        if (r2 == r) continue;
        Square s2 = make_sq(f, r2);
        Piece p = b.piece_on(s2);
        if (p != NO_PIECE && piece_color(p) == c && piece_type(p) == PIYON)
            return true;
    }
    return false;
}

static bool is_isolated(const Board& b, Square sq, Color c) {
    int f = sq_file(sq);
    for (int df : {-1, 1}) {
        int f2 = f + df;
        if (f2 < 0 || f2 >= BOARD_FILES) continue;
        for (int r2 = 0; r2 < BOARD_RANKS; r2++) {
            Piece p = b.piece_on(make_sq(f2, r2));
            if (p != NO_PIECE && piece_color(p) == c && piece_type(p) == PIYON)
                return false;
        }
    }
    return true;
}

static bool is_backward(const Board& b, Square sq, Color c) {
    int f = sq_file(sq), r = sq_rank(sq);
    int dir = (c == WHITE) ? 1 : -1;
    int next_r = r + dir;
    if (next_r < 0 || next_r >= BOARD_RANKS) return false;
    // Destekleyen kendi piyonu yok (yan dosyalarda geride)
    bool supported = false;
    for (int df : {-1, 1}) {
        int f2 = f + df;
        if (f2 < 0 || f2 >= BOARD_FILES) continue;
        // Kendi piyonu bu piyon ile aynı satırda veya gerisinde mi?
        for (int r2 = r; r2 != r - dir * 3 && r2 >= 0 && r2 < BOARD_RANKS; r2 -= dir) {
            Piece p = b.piece_on(make_sq(f2, r2));
            if (p != NO_PIECE && piece_color(p) == c && piece_type(p) == PIYON) {
                supported = true;
                break;
            }
        }
        if (supported) break;
    }
    if (supported) return false;
    // Rakip piyon bir sonraki karede bekliyorsa geri piyon
    for (int df : {-1, 1}) {
        int f2 = f + df;
        if (f2 < 0 || f2 >= BOARD_FILES) continue;
        Piece p = b.piece_on(make_sq(f2, next_r));
        if (p != NO_PIECE && piece_color(p) != c && piece_type(p) == PIYON)
            return true;
    }
    return false;
}

// ── Piyon Yapısı Değerlendirmesi ─────────────────────────────────────────
i32 Evaluator::eval_pawn_structure(const Board& b, Color c) {
    // PawnTable cache kontrolü
    PawnEntry* pe = pawn_table_.probe(b.pawn_hash());
    if (pe) return pe->score[c];

    // Her iki taraf için hesapla, sonra cache'e yaz
    i32 scores[2] = {0, 0};
    for (int ci = 0; ci < 2; ci++) {
        Color cc = (Color)ci;
        for (Square sq : b.pieces(cc, PIYON)) {
            int rank = sq_rank(sq);
            int prank = (cc == WHITE) ? rank : (9 - rank); // 0=başlangıç, 9=son sıra
            if (is_passed(b, sq, cc))
                scores[ci] += PASSED_PAWN_BONUS[prank];
            if (is_doubled(b, sq, cc))
                scores[ci] += DOUBLED_PAWN_PENALTY;
            if (is_isolated(b, sq, cc))
                scores[ci] += ISOLATED_PAWN_PENALTY;
            if (is_backward(b, sq, cc))
                scores[ci] += BACKWARD_PAWN_PENALTY;
        }
    }
    pawn_table_.store(b.pawn_hash(), scores[WHITE], scores[BLACK]);
    return scores[c];
}

// ── Citadel Değerlendirmesi ───────────────────────────────────────────────
i32 Evaluator::eval_citadel(const Board& b, Color c, int phase) const {
    Square ksq    = b.king_sq(c);
    Square target = (c == WHITE) ? BLACK_CITADEL_NEIGHBOR : WHITE_CITADEL_NEIGHBOR;
    if (ksq == SQ_NONE || ksq >= BOARD_NORMAL) return 0;

    int kf = sq_file(ksq), kr = sq_rank(ksq);
    int tf = sq_file(target), tr = sq_rank(target);
    int dist = std::abs(kf-tf) + std::abs(kr-tr);

    i32 score = 0;

    // Yakınlık bonusu — endgame'de daha değerli
    int eg_weight = MAX_PHASE - phase; // endgame'de daha yüksek

    if (dist <= 1) {
        score = CITADEL_ADJACENT_BONUS + eg_weight / 4;
    } else if (dist <= 2) {
        score = CITADEL_THREAT_BONUS + eg_weight / 8;
    } else if (dist <= 4) {
        score = 10; // Uzaktan hafif bonus
    }

    // Rakibin citadel savunması: rakip şah citadel'e yakınsa ceza
    Color them = ~c;
    Square their_target = (them == WHITE) ? BLACK_CITADEL_NEIGHBOR : WHITE_CITADEL_NEIGHBOR;
    Square their_ksq = b.king_sq(them);
    if (their_ksq != SQ_NONE && their_ksq < BOARD_NORMAL) {
        int their_dist = std::abs(sq_file(their_ksq) - sq_file(their_target))
                       + std::abs(sq_rank(their_ksq) - sq_rank(their_target));
        if (their_dist <= 1) score -= 20; // Rakip de yakında, rekabet
    }

    return score;
}

i32 Evaluator::eval_material(const Board& b) const {
    return b.material(WHITE) - b.material(BLACK);
}

// ── Ana Değerlendirme ─────────────────────────────────────────────────────
i32 Evaluator::evaluate(const Board& b, Color side) {
    int   phase = game_phase(b);
    float t     = static_cast<float>(phase) / MAX_PHASE; // 1.0=midgame

    i32 score = 0;

    // Materyal + PST (beyaz perspektifi)
    for (int r = 0; r < BOARD_RANKS; r++) {
        for (int f = 0; f < BOARD_FILES; f++) {
            Square sq = make_sq(f, r);
            Piece  p  = b.piece_on(sq);
            if (p == NO_PIECE) continue;

            PieceType pt = piece_type(p);
            Color     c  = piece_color(p);
            i32       val = PIECE_VALUE[pt];

            // Persona çarpanları: kale ve at materyal değerine uygulanır
            if (pt == KALE) val = (i32)(val * pw_.rook_mult);
            if (pt == AT)   val = (i32)(val * pw_.knight_mult);

            // PST bonusu (renk için doğru yönelim)
            int pst_sq = (c == WHITE) ? sq : ((BOARD_RANKS-1-r)*BOARD_FILES + f);
            if (pst_sq < BOARD_NORMAL) {
                i32 mg_bonus = PST[pt].mg[pst_sq];
                i32 eg_bonus = PST[pt].eg[pst_sq];
                val += (i32)(t * mg_bonus + (1.0f-t) * eg_bonus);
            }

            score += (c == WHITE ? +val : -val);
        }
    }

    // Mobilite
    score += eval_mobility(b, WHITE, phase);
    score -= eval_mobility(b, BLACK, phase);

    // Kral güvenliği
    score += eval_king_safety(b, WHITE, phase);
    score -= eval_king_safety(b, BLACK, phase);

    // Piyon yapısı
    score += eval_pawn_structure(b, WHITE);
    score -= eval_pawn_structure(b, BLACK);

    // Citadel yakınlık
    score += eval_citadel(b, WHITE, phase);
    score -= eval_citadel(b, BLACK, phase);

    // Fil çifti bonusu
    for (Color c2 : {WHITE, BLACK}) {
        if ((int)b.pieces(c2, FIL).size() >= 2) {
            int bonus = (int)(t * BISHOP_PAIR_BONUS + (1.0f - t) * (BISHOP_PAIR_BONUS / 2));
            score += (c2 == WHITE ? +bonus : -bonus);
        }
    }

    // Kale açık / yarı-açık dosya bonusu
    for (Color c2 : {WHITE, BLACK}) {
        for (Square rsq : b.pieces(c2, KALE)) {
            int rf = sq_file(rsq);
            bool own_pawn = false, opp_pawn = false;
            for (int rr = 0; rr < BOARD_RANKS; rr++) {
                Piece p = b.piece_on(make_sq(rf, rr));
                if (p == NO_PIECE) continue;
                if (piece_type(p) == PIYON) {
                    if (piece_color(p) == c2) own_pawn = true;
                    else opp_pawn = true;
                }
            }
            int rbonus = 0;
            if (!own_pawn && !opp_pawn) rbonus = ROOK_OPEN_FILE_BONUS;
            else if (!own_pawn)         rbonus = ROOK_SEMI_OPEN_BONUS;
            score += (c2 == WHITE ? +rbonus : -rbonus);
        }
    }

    // Outpost bonusu: at ve fil için rakip piyonların saldıramadığı ileri kareler
    for (Color c2 : {WHITE, BLACK}) {
        Color opp = ~c2;
        int fwd_dir = (c2 == WHITE) ? 1 : -1;
        int min_rank = (c2 == WHITE) ? 4 : 0;  // Beyaz için en az rank 4 (rakip bölgesi)
        int max_rank = (c2 == WHITE) ? 9 : 5;
        for (PieceType pt : {AT, FIL}) {
            for (Square psq : b.pieces(c2, pt)) {
                int pr = sq_rank(psq), pf = sq_file(psq);
                if (pr < min_rank || pr > max_rank) continue;
                // Rakip piyon bu kareyi saldırıyor mu?
                bool attacked_by_pawn = false;
                for (int df : {-1, 1}) {
                    int af = pf + df, ar = pr - fwd_dir; // Rakibin piyonu önden saldırır
                    if (af < 0 || af >= BOARD_FILES || ar < 0 || ar >= BOARD_RANKS) continue;
                    Piece ap = b.piece_on(make_sq(af, ar));
                    if (ap != NO_PIECE && piece_color(ap) == opp && piece_type(ap) == PIYON) {
                        attacked_by_pawn = true;
                        break;
                    }
                }
                if (attacked_by_pawn) continue;
                int bonus = OUTPOST_BONUS;
                // Kendi piyonu arkadan destekliyor mu?
                for (int df : {-1, 1}) {
                    int sf = pf + df, sr = pr - fwd_dir;
                    if (sf < 0 || sf >= BOARD_FILES || sr < 0 || sr >= BOARD_RANKS) continue;
                    Piece sp = b.piece_on(make_sq(sf, sr));
                    if (sp != NO_PIECE && piece_color(sp) == c2 && piece_type(sp) == PIYON) {
                        bonus += OUTPOST_SUPPORTED_BONUS;
                        break;
                    }
                }
                score += (c2 == WHITE ? +bonus : -bonus);
            }
        }
    }

    // Kale bağlantısı: iki kale aynı satır/dosyada, aralarında taş yok
    for (Color c2 : {WHITE, BLACK}) {
        auto rooks = b.pieces(c2, KALE);
        if (rooks.size() >= 2) {
            bool connected = false;
            for (int i = 0; i < (int)rooks.size() && !connected; i++) {
                for (int j = i+1; j < (int)rooks.size() && !connected; j++) {
                    Square r1 = rooks[i], r2 = rooks[j];
                    int f1 = sq_file(r1), rk1 = sq_rank(r1);
                    int f2 = sq_file(r2), rk2 = sq_rank(r2);
                    if (rk1 == rk2) { // Aynı satır
                        int lo = std::min(f1,f2)+1, hi = std::max(f1,f2);
                        bool clear = true;
                        for (int ff = lo; ff < hi && clear; ff++)
                            clear = (b.piece_on(make_sq(ff, rk1)) == NO_PIECE);
                        connected = clear;
                    } else if (f1 == f2) { // Aynı dosya
                        int lo = std::min(rk1,rk2)+1, hi = std::max(rk1,rk2);
                        bool clear = true;
                        for (int rr = lo; rr < hi && clear; rr++)
                            clear = (b.piece_on(make_sq(f1, rr)) == NO_PIECE);
                        connected = clear;
                    }
                }
            }
            if (connected)
                score += (c2 == WHITE ? +ROOK_CONNECTIVITY_BONUS : -ROOK_CONNECTIVITY_BONUS);
        }
    }

    // Tempo: hamle sırası tarafına küçük bonus
    score += (side == WHITE ? +TEMPO_BONUS : -TEMPO_BONUS);

    // Bare king cezası
    auto bare_king = [&](Color c2) -> bool {
        return b.pieces(c2, KALE).empty() && b.pieces(c2, ZURAFA).empty()
            && b.pieces(c2, TALIA).empty() && b.pieces(c2, AT).empty()
            && b.pieces(c2, DEVE).empty()  && b.pieces(c2, FIL).empty()
            && b.pieces(c2, SAVAS).empty() && b.pieces(c2, FERZ).empty()
            && b.pieces(c2, VALI).empty()  && b.pieces(c2, PIYON).empty();
    };
    if (bare_king(WHITE)) score -= (i32)(t * BARE_KING_PENALTY_MG + (1.0f-t) * BARE_KING_PENALTY_EG);
    if (bare_king(BLACK)) score += (i32)(t * BARE_KING_PENALTY_MG + (1.0f-t) * BARE_KING_PENALTY_EG);

    i32 hce_score = (side == WHITE) ? score : -score;

    // NNUE blend: faz bazlı ağırlıklı ortalama
    // Erken eğitim aşaması: NNUE ağırlığı düşük tutulur (HCE'nin güvenilirliği yüksek)
    // phase=0(endgame): %30 NNUE, phase=MAX_PHASE(opening): %20 NNUE
    if (use_nnue()) {
        i32 nnue_score = nnue_.evaluate(b, side);
        int nnue_w = 20 + (MAX_PHASE - phase) * 10 / MAX_PHASE; // 20..30
        int hce_w  = 100 - nnue_w;
        return (nnue_score * nnue_w + hce_score * hce_w) / 100;
    }

    return hce_score;
}

i32 Evaluator::evaluate_fast(const Board& b, Color side) {
    i32 score = b.material(WHITE) - b.material(BLACK);
    return (side == WHITE) ? score : -score;
}

// eval_pst: ana evaluate() içinde satır içi yapıldı, bağımsız stub
i32 Evaluator::eval_pst(const Board&, Color, int) const { return 0; }

} // namespace Apex
