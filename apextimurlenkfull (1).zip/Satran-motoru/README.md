# Apex Timurlenk — Satranç Motoru

**Gök Umay Oyun Stüdyosu** tarafından geliştirilen, Timurlenk satranç varyantı için C++20 motoru.

## Özellikler

- 11×10 tahta (110 normal kare + 2 citadel)
- 11 özgün taş tipi (Zürafa, Deve, Talia, Savaş Makinesi...)
- Timurlenk'e özgü kurallar: swap hakkı, citadel girişi
- UCI protokol desteği (Arena, Cute Chess uyumlu)
- Alpha-beta arama + TT + NMP + LMR + Aspiration Windows

## Derleme

```bash
cmake -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j$(nproc)
```

## Kullanım

```bash
# Motor başlat (UCI modunda)
./build/apex_timur

# Perft testi
printf "position startpos\nperft 2\nquit\n" | ./build/apex_timur
# Beklenen: Perft(2) = 2809

# Arama testi
printf "position startpos\ngo depth 8\nquit\n" | ./build/apex_timur
```

## Proje Yapısı

```
include/   → Başlık dosyaları
src/       → Kaynak dosyalar
build/     → Derleme çıktısı (git'te yok)
```

Detaylı geliştirici belgesi için [`CLAUDE.md`](CLAUDE.md) dosyasına bakın.
