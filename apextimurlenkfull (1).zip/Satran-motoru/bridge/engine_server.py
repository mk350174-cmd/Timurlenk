#!/usr/bin/env python3
"""
engine_server.py — Apex Timurlenk UCI ↔ WebSocket köprüsü

Tarayıcıdaki timurlenk_ui_v2.html ile C++ motoru (build/apex_timur) arasında
JSON tabanlı bir WebSocket katmanı kurar. Her bağlantı kendi motor sürecini
açar; tarayıcı kapatılınca süreç temizlenir.

Çalıştırma:
    pip install websockets PyJWT
    python3 bridge/engine_server.py --engine build/apex_timur --port 8765

    # Üretim ortamı (CORS + JWT):
    python3 bridge/engine_server.py \
        --engine build/apex_timur \
        --port 8765 \
        --allowed-origins "https://siten.com,https://www.siten.com" \
        --jwt-secret "supabase-jwt-secret-buraya"

Mesaj protokolü (JSON):
    Client → Server:
        {"type": "auth", "token": "<supabase-jwt>"}   ← zorunlu, ilk mesaj
        {"type": "ucinewgame"}
        {"type": "position", "fen": "startpos", "moves": ["e1e4"]}
        {"type": "go", "depth": 5}        # veya "movetime": 3000
        {"type": "setoption", "name": "UseNNUE", "value": "true"}
        {"type": "stop"}
    Server → Client:
        {"type": "ready"}
        {"type": "info", "depth": N, "score": cp, "nodes": N, "time": ms, "pv": [...]}
        {"type": "bestmove", "move": "e1e4", "ponder": null}
        {"type": "error", "message": "..."}
"""

import argparse
import asyncio
import json
import logging
import os
import sys
from pathlib import Path

import websockets

try:
    import jwt as pyjwt
    _JWT_AVAILABLE = True
except ImportError:
    _JWT_AVAILABLE = False


logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)
log = logging.getLogger("ws_bridge")

# Global config — main() içinde doldurulur
_allowed_origins: list[str] = []
_jwt_secret: str = ""


def verify_jwt(token: str) -> dict | None:
    """Supabase JWT'yi doğrular. Başarısızsa None döner."""
    if not _jwt_secret:
        return {"sub": "anonymous"}  # JWT kapalıysa herkese izin ver
    if not _JWT_AVAILABLE:
        log.warning("PyJWT kurulu değil, JWT doğrulaması atlanıyor. pip install PyJWT")
        return {"sub": "anonymous"}
    try:
        payload = pyjwt.decode(
            token,
            _jwt_secret,
            algorithms=["HS256"],
            options={"verify_aud": False},
        )
        return payload
    except pyjwt.ExpiredSignatureError:
        log.warning("JWT süresi dolmuş")
        return None
    except pyjwt.InvalidTokenError as e:
        log.warning("Geçersiz JWT: %s", e)
        return None


class EnginePool:
    """Eş zamanlı motor süreçlerini sınırlar (varsayılan: maks 4)."""

    def __init__(self, engine_path: str, max_engines: int = 4):
        self.engine_path = engine_path
        self.max_engines = max_engines
        self._count = 0
        self._lock = asyncio.Lock()

    async def acquire(self) -> "UCIEngine | None":
        async with self._lock:
            if self._count >= self.max_engines:
                return None
            self._count += 1
            return UCIEngine(self.engine_path)

    async def release(self):
        async with self._lock:
            self._count = max(0, self._count - 1)


# Global pool — main() içinde başlatılır
pool: "EnginePool | None" = None


class UCIEngine:
    """build/apex_timur sürecini stdin/stdout üzerinden yönetir."""

    def __init__(self, engine_path: str):
        self.engine_path = engine_path
        self.proc: asyncio.subprocess.Process | None = None
        self._reader_task: asyncio.Task | None = None
        self._on_line = None  # callback(line: str)

    async def start(self):
        if not Path(self.engine_path).exists():
            raise FileNotFoundError(f"Motor bulunamadı: {self.engine_path}")
        self.proc = await asyncio.create_subprocess_exec(
            self.engine_path,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.DEVNULL,
            cwd=os.getcwd(),
        )
        self._reader_task = asyncio.create_task(self._read_loop())
        await self.send("uci")
        await self.wait_for("uciok", timeout=5.0)
        await self.send("isready")
        await self.wait_for("readyok", timeout=5.0)
        log.info("Motor hazır")

    async def _read_loop(self):
        assert self.proc and self.proc.stdout
        while True:
            line = await self.proc.stdout.readline()
            if not line:
                break
            text = line.decode("utf-8", errors="replace").rstrip()
            if self._on_line:
                try:
                    await self._on_line(text)
                except Exception as e:
                    log.warning("on_line hatası: %s", e)
        # Döngü bitti — motor çökmüş
        log.warning("Motor süreci beklenmedik şekilde kapandı, yeniden başlatılıyor...")

    async def send(self, cmd: str):
        if not self.proc or not self.proc.stdin:
            raise RuntimeError("Motor başlatılmadı")
        self.proc.stdin.write((cmd + "\n").encode())
        await self.proc.stdin.drain()

    async def wait_for(self, token: str, timeout: float = 10.0):
        """Stdout'tan belirli bir token gelene kadar bekler."""
        fut = asyncio.get_event_loop().create_future()

        async def hook(line: str):
            if token in line and not fut.done():
                fut.set_result(line)

        prev = self._on_line
        self._on_line = hook
        try:
            return await asyncio.wait_for(fut, timeout=timeout)
        finally:
            self._on_line = prev

    def set_callback(self, cb):
        self._on_line = cb

    async def close(self):
        if self.proc and self.proc.returncode is None:
            try:
                await self.send("quit")
                await asyncio.wait_for(self.proc.wait(), timeout=2.0)
            except (asyncio.TimeoutError, BrokenPipeError, ConnectionResetError):
                self.proc.kill()
        if self._reader_task:
            self._reader_task.cancel()


def parse_info_line(line: str) -> dict | None:
    """UCI 'info ...' satırını dict'e dönüştürür."""
    if not line.startswith("info "):
        return None
    parts = line.split()
    out: dict = {}
    i = 1
    while i < len(parts):
        k = parts[i]
        if k in ("depth", "seldepth", "nodes", "time", "nps", "hashfull", "multipv"):
            i += 1
            try:
                out[k] = int(parts[i])
            except (ValueError, IndexError):
                pass
            i += 1
        elif k == "score":
            i += 1
            kind = parts[i] if i < len(parts) else ""
            i += 1
            val = int(parts[i]) if i < len(parts) else 0
            out["score"] = {"type": kind, "value": val}
            i += 1
        elif k == "pv":
            out["pv"] = parts[i + 1 :]
            break
        elif k == "string":
            out["string"] = " ".join(parts[i + 1 :])
            break
        else:
            i += 1
    return out


async def watch_engine(engine: "UCIEngine", send_json, engine_path: str, max_retries: int = 3):
    """Motor çöktüğünde otomatik yeniden başlatır (maks 3 deneme)."""
    retries = 0
    while retries < max_retries:
        if engine.proc:
            await engine.proc.wait()
        if retries < max_retries - 1:
            await send_json({"type": "status", "ready": False, "message": "Motor yeniden başlatılıyor..."})
            try:
                await engine.start()
                await send_json({"type": "ready"})
                retries = 0  # başarılı — sayacı sıfırla
                return
            except Exception as e:
                log.warning("Motor yeniden başlatma hatası (%d): %s", retries + 1, e)
                retries += 1
                await asyncio.sleep(1)
        else:
            break
    await send_json({"type": "error", "message": "Motor kurtarılamadı (3 deneme)"})


async def handle_client(websocket, engine_path: str):
    """Bir tarayıcı bağlantısı = bir motor süreci."""
    peer = getattr(websocket, "remote_address", "?")
    log.info("İstemci bağlandı: %s", peer)

    # JWT kimlik doğrulaması — ilk mesajı bekle
    user_payload: dict | None = None
    if _jwt_secret:
        try:
            first_raw = await asyncio.wait_for(websocket.recv(), timeout=10.0)
            first_msg = json.loads(first_raw)
            if first_msg.get("type") != "auth":
                await websocket.send(json.dumps({"type": "error", "message": "İlk mesaj 'auth' tipi olmalı"}))
                return
            token = first_msg.get("token", "")
            user_payload = verify_jwt(token)
            if user_payload is None:
                await websocket.send(json.dumps({"type": "error", "message": "Geçersiz veya süresi dolmuş token"}))
                return
            log.info("Kimlik doğrulandı: sub=%s peer=%s", user_payload.get("sub"), peer)
        except asyncio.TimeoutError:
            await websocket.send(json.dumps({"type": "error", "message": "Auth zaman aşımı (10s)"}))
            return
        except (json.JSONDecodeError, websockets.ConnectionClosed):
            return

    # B7 — EnginePool ile kapasite kontrolü
    engine: UCIEngine | None = None
    if pool is not None:
        engine = await pool.acquire()
        if engine is None:
            await websocket.send(json.dumps({"type": "error", "message": "Kapasite dolu (maks 4 bağlantı)"}))
            log.warning("Bağlantı reddedildi (kapasite dolu): %s", peer)
            return
    else:
        engine = UCIEngine(engine_path)

    async def send_json(obj):
        try:
            await websocket.send(json.dumps(obj))
        except websockets.ConnectionClosed:
            pass

    async def on_engine_line(line: str):
        if line.startswith("info "):
            info = parse_info_line(line)
            if info:
                await send_json({"type": "info", **info})
        elif line.startswith("bestmove"):
            parts = line.split()
            move = parts[1] if len(parts) > 1 else None
            ponder = parts[3] if len(parts) > 3 and parts[2] == "ponder" else None
            await send_json({"type": "bestmove", "move": move, "ponder": ponder})

    watch_task: asyncio.Task | None = None
    try:
        await engine.start()
        engine.set_callback(on_engine_line)
        await send_json({"type": "ready"})

        # B6 — Motor sağlık izleyicisi
        watch_task = asyncio.create_task(watch_engine(engine, send_json, engine_path))

        async for raw in websocket:
            try:
                msg = json.loads(raw)
            except json.JSONDecodeError as e:
                await send_json({"type": "error", "message": f"Geçersiz JSON: {e}"})
                continue

            t = msg.get("type")
            if t == "ucinewgame":
                await engine.send("ucinewgame")
            elif t == "position":
                fen = msg.get("fen", "startpos")
                moves = msg.get("moves", [])
                cmd = f"position {'startpos' if fen == 'startpos' else f'fen {fen}'}"
                if moves:
                    cmd += " moves " + " ".join(moves)
                await engine.send(cmd)
            elif t == "go":
                if "depth" in msg:
                    await engine.send(f"go depth {int(msg['depth'])}")
                elif "movetime" in msg:
                    await engine.send(f"go movetime {int(msg['movetime'])}")
                elif "wtime" in msg:
                    wt = int(msg.get("wtime", 60000))
                    bt = int(msg.get("btime", 60000))
                    wi = int(msg.get("winc", 0))
                    bi = int(msg.get("binc", 0))
                    await engine.send(f"go wtime {wt} btime {bt} winc {wi} binc {bi}")
                else:
                    await engine.send("go depth 5")
            elif t == "go_ponder":
                await engine.send("go ponder")
            elif t == "ponderhit":
                await engine.send("ponderhit")
            elif t == "analyze":
                # B3 — Analiz modu: go infinite (stop gelinceye kadar info aktar)
                fen = msg.get("fen", "startpos")
                moves = msg.get("moves", [])
                cmd = f"position {'startpos' if fen == 'startpos' else f'fen {fen}'}"
                if moves:
                    cmd += " moves " + " ".join(moves)
                await engine.send(cmd)
                await engine.send("go infinite")
            elif t == "stop":
                await engine.send("stop")
            elif t == "setoption":
                name = msg.get("name", "")
                value = msg.get("value", "")
                await engine.send(f"setoption name {name} value {value}")
            elif t == "raw":
                # Hata ayıklama için ham UCI komutu
                await engine.send(str(msg.get("cmd", "")))
            else:
                await send_json({"type": "error", "message": f"Bilinmeyen tip: {t}"})

    except websockets.ConnectionClosed:
        log.info("İstemci ayrıldı: %s", peer)
    except Exception as e:
        log.exception("Köprü hatası: %s", e)
        await send_json({"type": "error", "message": str(e)})
    finally:
        if watch_task is not None:
            watch_task.cancel()
        await engine.close()
        if pool is not None:
            await pool.release()
        log.info("Motor süreci kapatıldı: %s", peer)


async def main():
    global pool, _allowed_origins, _jwt_secret
    ap = argparse.ArgumentParser()
    ap.add_argument("--engine", default="build/apex_timur")
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=8765)
    ap.add_argument("--max-engines", type=int, default=4)
    ap.add_argument(
        "--allowed-origins",
        default="",
        help="Virgülle ayrılmış izin verilen origin'ler. Boşsa herkese izin verilir.",
    )
    ap.add_argument(
        "--jwt-secret",
        default=os.environ.get("SUPABASE_JWT_SECRET", ""),
        help="Supabase JWT secret. Boşsa kimlik doğrulama kapalı.",
    )
    args = ap.parse_args()

    if not Path(args.engine).exists():
        log.error("Motor binary bulunamadı: %s", args.engine)
        sys.exit(1)

    # Globals
    _jwt_secret = args.jwt_secret
    if args.allowed_origins:
        _allowed_origins = [o.strip() for o in args.allowed_origins.split(",") if o.strip()]

    pool = EnginePool(args.engine, max_engines=args.max_engines)
    log.info("EnginePool başlatıldı (maks %d bağlantı)", args.max_engines)

    if _jwt_secret:
        log.info("JWT doğrulaması: AÇIK")
    else:
        log.warning("JWT doğrulaması: KAPALI (geliştirme modu)")

    if _allowed_origins:
        log.info("İzin verilen origin'ler: %s", _allowed_origins)
    else:
        log.info("Origin kısıtlaması: YOK (herkese açık)")

    async def handler(ws):
        await handle_client(ws, args.engine)

    serve_kwargs: dict = {"host": args.host, "port": args.port}
    if _allowed_origins:
        serve_kwargs["origins"] = _allowed_origins

    log.info("WebSocket köprüsü dinliyor: ws://%s:%d", args.host, args.port)
    log.info("Motor: %s", args.engine)
    async with websockets.serve(handler, **serve_kwargs):
        await asyncio.Future()  # sonsuza kadar


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nKöprü durduruldu.")
