/* ══════════════════════════════════════════════════════════════
   EVENTBUS — Bağımsız modül
   Tüm Bozkır Platform oyunları bu dosyayı yükler:
     <script src="bridge/eventbus.js"></script>
   ══════════════════════════════════════════════════════════════ */

const EventBus = (() => {
  const listeners = {};
  return {
    on(event, fn) {
      (listeners[event] = listeners[event] || []).push(fn);
    },
    emit(event, data) {
      (listeners[event] || []).forEach(fn => fn(data));
    }
  };
})();
