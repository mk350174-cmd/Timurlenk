/* ══════════════════════════════════════════════════════════════
   ENGINE UI BRIDGE — WebSocket köprüsü
   Tarayıcıyı bridge/engine_server.py'ye bağlar, mesajları EventBus'a
   yönlendirir. timurlenk_ui_v2.html'in mevcut EventBus mimarisine
   minimal müdahale ile entegre olur.
   ══════════════════════════════════════════════════════════════ */

const EngineClient = (() => {
  // Board config — varsayılan Timurlenk (11×10)
  // Satrancı Rumi (8×8): EngineClient.configure({ranks:8, files:8, fileLetters:'abcdefgh'})
  let RANKS = 10, FILES = 11;
  let FILE_LETTERS = 'abcdefghijk';

  function configure(config = {}) {
    if (config.ranks)       RANKS        = config.ranks;
    if (config.files)       FILES        = config.files;
    if (config.fileLetters) FILE_LETTERS = config.fileLetters;
  }

  let ws = null;
  let url = null;
  let connected = false;
  let reconnectTimer = null;
  let moveHistoryUCI = [];      // motor için sıralı UCI hamleleri
  let lastSentDepth = 5;
  let onReady = null;
  let ponderMove = null;        // B4: mevcut ponder hamlesi
  let isPondering = false;
  let analyzeMode = false;      // B3: analiz modu bayrağı

  // ── Koordinat dönüşümü ───────────────────────────────────────
  // Frontend: [rank 0-9, file 0-10] (rank 0 = beyaz tabanı)
  // UCI: "<file><rank>" (file: a-k, rank: 1-10)
  function rfToUCI(rank, file) {
    return FILE_LETTERS[file] + (rank + 1);
  }

  function uciToRF(sq) {
    // sq örn: "e1", "k10"
    const f = FILE_LETTERS.indexOf(sq[0]);
    const r = parseInt(sq.slice(1), 10) - 1;
    return [r, f];
  }

  function parseUCIMove(uci) {
    // Standart: "e1e4", "a9a10", terfi: "a9a10=Z", swap: "swap:e1g1",
    // citadel: "k2-wc" / "a9-bc"
    if (!uci) return null;
    if (uci.startsWith("swap:")) {
      const inner = uci.slice(5);
      // swap:e1g1 — iki kare
      return { kind: "swap", from: uciToRF(inner.slice(0, 2)), to: uciToRF(inner.slice(2)) };
    }
    if (uci.includes("-wc") || uci.includes("-bc")) {
      return { kind: "citadel", from: uciToRF(uci.split("-")[0]), citadel: uci.split("-")[1] };
    }
    let promo = null;
    let body = uci;
    const eq = body.indexOf("=");
    if (eq > 0) { promo = body.slice(eq + 1); body = body.slice(0, eq); }
    // "a10" gibi 3 karakterli kare olabilir — manuel parse
    const m = body.match(/^([a-k])(\d+)([a-k])(\d+)$/);
    if (!m) return null;
    const from = [parseInt(m[2], 10) - 1, FILE_LETTERS.indexOf(m[1])];
    const to = [parseInt(m[4], 10) - 1, FILE_LETTERS.indexOf(m[3])];
    return { kind: "move", from, to, promo };
  }

  function rfMoveToUCI(fromR, fromF, toR, toF, promo) {
    let s = rfToUCI(fromR, fromF) + rfToUCI(toR, toF);
    if (promo) s += "=" + promo.toUpperCase();
    return s;
  }

  // ── WebSocket bağlantısı ─────────────────────────────────────
  function connect(wsUrl) {
    url = wsUrl;
    setStatus("Bağlanıyor...");
    try {
      ws = new WebSocket(wsUrl);
    } catch (e) {
      setStatus("Bağlantı hatası: " + e.message);
      scheduleReconnect();
      return;
    }
    ws.onopen = () => {
      connected = true;
      setStatus("Bağlı");
      if (typeof EventBus !== "undefined") {
        EventBus.emit("ENGINE_CONNECTED", {});
      }
    };
    ws.onclose = () => {
      connected = false;
      setStatus("Bağlantı koptu");
      scheduleReconnect();
    };
    ws.onerror = () => {
      setStatus("WebSocket hatası");
    };
    ws.onmessage = (evt) => {
      let msg;
      try { msg = JSON.parse(evt.data); }
      catch { return; }
      handleServerMessage(msg);
    };
  }

  function scheduleReconnect() {
    if (reconnectTimer) return;
    reconnectTimer = setTimeout(() => {
      reconnectTimer = null;
      if (url) connect(url);
    }, 2000);
  }

  function setStatus(text) {
    const el = document.getElementById("engine-status");
    if (el) el.textContent = "Motor: " + text;
    console.log("[EngineClient]", text);
  }

  function send(obj) {
    if (!connected || !ws) return false;
    try { ws.send(JSON.stringify(obj)); return true; }
    catch (e) { console.warn("WS send error:", e); return false; }
  }

  // ── Sunucudan gelen mesajlar ─────────────────────────────────
  function handleServerMessage(msg) {
    switch (msg.type) {
      case "ready":
        setStatus("Hazır");
        if (onReady) { onReady(); onReady = null; }
        if (typeof EventBus !== "undefined") {
          EventBus.emit("ENGINE_READY", {});
        }
        break;
      case "info":
        if (typeof EventBus !== "undefined") {
          EventBus.emit("ENGINE_INFO", {
            depth: msg.depth, score: msg.score, nodes: msg.nodes,
            time: msg.time, nps: msg.nps, pv: msg.pv
          });
        }
        break;
      case "bestmove":
        isPondering = false;
        if (msg.move && msg.move !== "(none)" && msg.move !== "0000") {
          const parsed = parseUCIMove(msg.move);
          ponderMove = msg.ponder || null;
          if (typeof EventBus !== "undefined") {
            EventBus.emit("ENGINE_BESTMOVE", { uci: msg.move, parsed, ponder: ponderMove });
          }
        } else {
          ponderMove = null;
          if (typeof EventBus !== "undefined") {
            EventBus.emit("ENGINE_BESTMOVE", { uci: null, parsed: null, ponder: null });
          }
        }
        break;
      case "error":
        console.error("[Motor hatası]", msg.message);
        if (typeof EventBus !== "undefined") {
          EventBus.emit("ENGINE_ERROR", { message: msg.message });
        }
        break;
    }
  }

  // ── Üst seviye API ───────────────────────────────────────────
  function newGame(opts = {}) {
    moveHistoryUCI = [];
    send({ type: "ucinewgame" });
    if (opts.nnuePath) {
      send({ type: "setoption", name: "UseNNUE", value: "true" });
      send({ type: "setoption", name: "NNUEPath", value: opts.nnuePath });
    }
    send({ type: "position", fen: "startpos", moves: [] });
  }

  function recordPlayerMove(fromR, fromF, toR, toF, promo) {
    const uci = rfMoveToUCI(fromR, fromF, toR, toF, promo);
    moveHistoryUCI.push(uci);
    return uci;
  }

  function requestEngineMove(depth, movetime) {
    lastSentDepth = depth || lastSentDepth;
    send({ type: "position", fen: "startpos", moves: moveHistoryUCI });
    if (movetime) {
      send({ type: "go", movetime });
    } else {
      send({ type: "go", depth: lastSentDepth });
    }
  }

  function setOption(name, value) {
    send({ type: "setoption", name, value: String(value) });
  }

  function recordEngineMove(uci) {
    moveHistoryUCI.push(uci);
  }

  function stop() {
    send({ type: "stop" });
  }

  // ── Analiz Modu (B3) ────────────────────────────────────────
  function startAnalyze() {
    analyzeMode = true;
    send({ type: "analyze", fen: "startpos", moves: moveHistoryUCI });
  }

  function stopAnalyze() {
    analyzeMode = false;
    send({ type: "stop" });
  }

  // ── FEN Konumu (B8) ─────────────────────────────────────────
  function loadPosition(fen, moves = []) {
    moveHistoryUCI = [...moves];
    send({ type: "position", fen: fen === "startpos" ? "startpos" : fen, moves: moveHistoryUCI });
  }

  function undoLastMove() {
    if (moveHistoryUCI.length === 0) return;
    if (isPondering) { send({ type: "stop" }); isPondering = false; }
    moveHistoryUCI.pop();
    // Siyah son hamleyi de geri al (ikisi birden — oyuncu + motor)
    if (moveHistoryUCI.length > 0) moveHistoryUCI.pop();
    send({ type: "position", fen: "startpos", moves: moveHistoryUCI });
  }

  // ── Ponder (B4) ─────────────────────────────────────────────
  function startPonder(ponderUCI) {
    if (!ponderUCI || !connected) return;
    isPondering = true;
    ponderMove = ponderUCI;
    send({ type: "position", fen: "startpos", moves: [...moveHistoryUCI, ponderUCI] });
    send({ type: "go_ponder" });
  }

  function ponderHit(fromR, fromF, toR, toF, promo) {
    if (!isPondering || !ponderMove) return false;
    const uci = rfMoveToUCI(fromR, fromF, toR, toF, promo);
    if (uci !== ponderMove) {
      // Oyuncu farklı hamle yaptı — ponder miss, normal arama başlat
      send({ type: "stop" });
      isPondering = false;
      moveHistoryUCI.push(uci);
      return false;
    }
    // Ponder hit — doğru hamle tahmin edildi
    moveHistoryUCI.push(uci);
    isPondering = false;
    send({ type: "ponderhit" });
    return true;
  }

  function isConnected() { return connected; }

  function getMoveHistory() { return [...moveHistoryUCI]; }

  return {
    connect, newGame, recordPlayerMove, requestEngineMove,
    recordEngineMove, undoLastMove, stop, isConnected, setOption,
    startPonder, ponderHit,
    startAnalyze, stopAnalyze, loadPosition,
    getMoveHistory,
    rfMoveToUCI, parseUCIMove, uciToRF, rfToUCI,
    configure
  };
})();
