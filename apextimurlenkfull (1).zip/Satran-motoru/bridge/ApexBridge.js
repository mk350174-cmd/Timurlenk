/**
 * ApexBridge.js — UI ↔ Apex Motor Köprüsü
 *
 * Claude Design ile yapılan UI'yı Apex Timurlenk motoruna bağlar.
 * EventBus üzerinden çalışır — UI'nın motor hakkında hiçbir şey bilmesi gerekmez.
 *
 * Kullanım:
 *   import { ApexBridge } from './ApexBridge.js';
 *   const bridge = new ApexBridge({ enginePath: '/engine/apex_timur.js' });
 *   await bridge.init();
 *
 * Dinlenecek EventBus olayları (UI → Motor):
 *   'game:start'          { persona, psyche, difficulty, timeControl }
 *   'game:move'           { from, to, promo? }
 *   'game:undo'           {}
 *   'game:resign'         {}
 *   'game:new'            {}
 *   'engine:setPersona'   { name, psyche }
 *   'engine:setDepth'     { depth }
 *
 * Yayınlanan EventBus olayları (Motor → UI):
 *   'board:update'        { pieces, turn, inCheck, legalMoves, fen }
 *   'engine:thinking'     { thinking: true/false }
 *   'engine:move'         { move, from, to, info }
 *   'engine:info'         { depth, score, pv, nps, nodes }
 *   'game:over'           { reason: 'checkmate'|'stalemate'|'citadel', winner: 'w'|'b'|null }
 *   'game:check'          { side: 'w'|'b' }
 *   'error'               { message }
 */

'use strict';

// ── Taş tipi eşleştirme tablosu ──────────────────────────────────────────────
const PIECE_NAMES_TR = {
  K: 'Şah',    R: 'Kale',    Z: 'Zürafa',
  T: 'Talia',  N: 'At',      C: 'Deve',
  E: 'Fil',    M: 'Savaş Makinesi',
  D: 'Ferz',   V: 'Vali',    P: 'Piyon',
};

const PIECE_NAMES_EN = {
  K: 'King',   R: 'Rook',    Z: 'Giraffe',
  T: 'Guard',  N: 'Knight',  C: 'Camel',
  E: 'Elephant', M: 'War Machine',
  D: 'Queen',  V: 'Viceroy', P: 'Pawn',
};

// Zorluk → derinlik + süre eşleştirmesi
const DIFFICULTY = {
  easy:   { depth: 3,  movetime: 500  },
  medium: { depth: 5,  movetime: 1500 },
  hard:   { depth: 8,  movetime: 3000 },
  master: { depth: 12, movetime: 5000 },
};

// ── ApexBridge Sınıfı ─────────────────────────────────────────────────────────
class ApexBridge {
  /**
   * @param {object} opts
   * @param {string}   opts.enginePath  - apex_timur.js URL'i
   * @param {string}   opts.workerPath  - ApexWorker.js URL'i
   * @param {object}   opts.eventBus    - EventBus nesnesi { on, emit }
   * @param {string}   opts.playerColor - 'w' | 'b' (varsayılan 'w')
   * @param {string}   opts.difficulty  - 'easy'|'medium'|'hard'|'master'
   * @param {string}   opts.lang        - 'tr' | 'en'
   */
  constructor(opts = {}) {
    this._enginePath  = opts.enginePath  || '/engine/apex_timur.js';
    this._workerPath  = opts.workerPath  || '/engine/ApexWorker.js';
    this._bus         = opts.eventBus    || this._createSimpleBus();
    this._playerColor = opts.playerColor || 'w';
    this._difficulty  = opts.difficulty  || 'medium';
    this._lang        = opts.lang        || 'tr';

    this._engine      = null;   // ApexEngineWorker
    this._moves       = [];     // Oyundaki tüm hamleler ["e2e4","e7e5",...]
    this._thinking    = false;
    this._gameActive  = false;
    this._depth       = DIFFICULTY[this._difficulty]?.depth  || 5;
    this._movetime    = DIFFICULTY[this._difficulty]?.movetime || 1500;
  }

  // ── Başlatma ────────────────────────────────────────────────────────────────

  /** Motoru yükle ve EventBus'u bağla */
  async init() {
    try {
      // ApexEngineWorker yüklü mü kontrol et
      if (typeof ApexEngineWorker === 'undefined') {
        throw new Error('ApexWorker.js yüklenmemiş. <script src="ApexWorker.js"> eklendi mi?');
      }

      this._engine = new ApexEngineWorker(this._enginePath, this._workerPath);

      // Analiz bilgisi callback
      this._engine.onInfo = (info) => {
        this._bus.emit('engine:info', info);
      };

      await this._engine.init(16);
      this._listenBus();

      console.log('[ApexBridge] Motor hazır.');
      return this;
    } catch (err) {
      this._bus.emit('error', { message: 'Motor yüklenemedi: ' + err.message });
      throw err;
    }
  }

  // ── EventBus Dinleyicileri ───────────────────────────────────────────────────

  _listenBus() {
    const bus = this._bus;

    bus.on('game:start', (data) => this._onGameStart(data));
    bus.on('game:move',  (data) => this._onPlayerMove(data));
    bus.on('game:undo',  ()     => this._onUndo());
    bus.on('game:resign',()     => this._onResign());
    bus.on('game:new',   ()     => this._onNewGame());

    bus.on('engine:setPersona', (data) => {
      if (this._engine) this._engine.setPersona(data.name, data.psyche || 0);
    });
    bus.on('engine:setDepth', (data) => {
      this._depth = data.depth || 5;
    });
  }

  // ── Oyun Olayları ───────────────────────────────────────────────────────────

  async _onGameStart(data = {}) {
    const eng = this._engine;
    if (!eng) return;

    this._moves        = [];
    this._gameActive   = true;
    this._playerColor  = data.playerColor || this._playerColor;
    this._difficulty   = data.difficulty  || this._difficulty;
    const diff = DIFFICULTY[this._difficulty] || DIFFICULTY.medium;
    this._depth    = diff.depth;
    this._movetime = diff.movetime;

    await eng.newGame();

    // Persona ayarla
    if (data.persona && data.persona !== 'None') {
      await eng.setPersona(data.persona, data.psyche || 0);
    }

    // Tahta durumunu yayınla
    await this._broadcastBoard();

    // Siyah oynar başlarsa (oyuncu siyah seçtiyse) AI başlar
    if (this._playerColor === 'b') {
      await this._engineMove();
    }
  }

  async _onPlayerMove(data) {
    if (!this._gameActive || this._thinking) return;

    const eng = this._engine;
    const moveStr = _buildMoveStr(data.from, data.to, data.promo);

    // Yasal hamle mi kontrol et
    const legal = await eng.getLegalMoves();
    if (!legal.includes(moveStr)) {
      this._bus.emit('error', { message: 'Geçersiz hamle: ' + moveStr });
      return;
    }

    // Hamleyi uygula
    await eng.setPosition('startpos');
    this._moves.push(moveStr);
    await eng.doMoves(this._moves.join(' '));

    // Oyun bitti mi?
    const over = await eng.isGameOver();
    await this._broadcastBoard();
    if (over !== 0) { this._endGame(over); return; }

    // AI hamlesi
    await this._engineMove();
  }

  async _onUndo() {
    if (!this._gameActive || this._thinking || this._moves.length < 2) return;

    // Hem AI hem oyuncu hamlesini geri al
    this._moves.splice(-2);
    await this._engine.setPosition('startpos');
    if (this._moves.length > 0) {
      await this._engine.doMoves(this._moves.join(' '));
    }
    await this._broadcastBoard();
  }

  async _onResign() {
    if (!this._gameActive) return;
    this._gameActive = false;
    const winner = this._playerColor === 'w' ? 'b' : 'w';
    this._bus.emit('game:over', { reason: 'resign', winner });
  }

  async _onNewGame() {
    this._moves       = [];
    this._gameActive  = false;
    this._thinking    = false;
    if (this._engine) {
      await this._engine.newGame();
      await this._broadcastBoard();
    }
  }

  // ── AI Hamlesi ──────────────────────────────────────────────────────────────

  async _engineMove() {
    if (!this._gameActive || this._thinking) return;

    this._thinking = true;
    this._bus.emit('engine:thinking', { thinking: true });

    try {
      const { move, info } = await this._engine.bestMove(this._depth, this._movetime);

      if (!move || move === '0000') {
        // Yasal hamle yok — oyun bitmeli
        const over = await this._engine.isGameOver();
        this._endGame(over || 1);
        return;
      }

      this._moves.push(move);
      await this._engine.setPosition('startpos');
      await this._engine.doMoves(this._moves.join(' '));

      // Hamleyi parse et ve yayınla
      const parsed = _parseMoveStr(move);
      this._bus.emit('engine:move', { move, ...parsed, info });

      // Tahta güncelle
      await this._broadcastBoard();

      // Oyun bitti mi?
      const over = await this._engine.isGameOver();
      if (over !== 0) this._endGame(over);

    } finally {
      this._thinking = false;
      this._bus.emit('engine:thinking', { thinking: false });
    }
  }

  // ── Yardımcılar ─────────────────────────────────────────────────────────────

  async _broadcastBoard() {
    const eng = this._engine;
    const [boardData, legal, fen] = await Promise.all([
      eng.getBoardJson(),
      eng.getLegalMoves(),
      eng.getFen(),
    ]);

    const sideToMove = boardData.turn; // 'w' | 'b'

    // Şah kontrolü
    if (boardData.inCheck) {
      this._bus.emit('game:check', { side: sideToMove });
    }

    this._bus.emit('board:update', {
      pieces:      boardData.pieces,
      turn:        sideToMove,
      inCheck:     boardData.inCheck,
      legalMoves:  legal,
      fen,
    });
  }

  _endGame(code) {
    this._gameActive = false;
    const sideToMove = this._engine
      ? null
      : (this._moves.length % 2 === 0 ? 'w' : 'b');

    let reason = 'unknown';
    let winner = null;

    if (code === 1) {
      reason = 'checkmate';
      // Hamlesi yapılan taraf kazandı — sıra diğerindeydi
      winner = this._moves.length % 2 === 0 ? 'b' : 'w';
    } else if (code === 2) {
      reason = 'stalemate';
    } else if (code === 3) {
      reason = 'citadel';
      // Citadel'e giren taraf beraberliği sağladı
    }

    this._bus.emit('game:over', { reason, winner });
  }

  // ── Basit Dahili EventBus (dışarıdan verilmezse) ─────────────────────────────
  _createSimpleBus() {
    const listeners = {};
    return {
      on(event, fn) {
        if (!listeners[event]) listeners[event] = [];
        listeners[event].push(fn);
      },
      emit(event, data) {
        (listeners[event] || []).forEach(fn => {
          try { fn(data); } catch(e) { console.error('[Bus]', e); }
        });
      },
    };
  }

  // ── Kamuya Açık Erişimciler ──────────────────────────────────────────────────

  get engine()     { return this._engine; }
  get moves()      { return [...this._moves]; }
  get isThinking() { return this._thinking; }
  get isActive()   { return this._gameActive; }
  get bus()        { return this._bus; }

  /** Taş adını döndür */
  pieceName(type) {
    return (this._lang === 'tr' ? PIECE_NAMES_TR : PIECE_NAMES_EN)[type] || type;
  }
}

// ── Hamle String Yardımcıları ────────────────────────────────────────────────

/** { from: "e2", to: "e4", promo?: "Q" } → "e2e4" veya "swap:e1g1" */
function _buildMoveStr(from, to, promo) {
  if (!from || !to) return '0000';
  // Swap hamlesi UI'dan "swap" flag ile gelebilir
  if (from.startsWith('swap:') || to === 'swap') {
    return 'swap:' + from.replace('swap:', '') + to.replace('swap:', '');
  }
  let s = from + to;
  if (promo) s += '=' + promo.toUpperCase();
  return s;
}

/** "e2e4" → { from: "e2", to: "e4", isSwap: false }
 *  "swap:e1g1" → { from: "e1", to: "g1", isSwap: true } */
function _parseMoveStr(move) {
  if (!move || move === '0000') return { from: null, to: null, isSwap: false };
  if (move.startsWith('swap:')) {
    const rest = move.slice(5);
    const mid  = rest.length === 4 ? 2 : rest.search(/[0-9]/, 2) + 1;
    return { from: rest.slice(0, mid), to: rest.slice(mid), isSwap: true };
  }
  // Koordinat uzunluğu: e2=2, e10=3 (11×10 tahta için satır 10 var)
  const i = move.search(/[0-9]/);
  const j = move.search(/[0-9]/, i + 1);
  const mid = (j > 0 && j < move.length && move[j-1] !== '=') ? j : i + 1;
  return { from: move.slice(0, mid), to: move.slice(mid).replace(/=.*/, ''), isSwap: false };
}

// ── Dışa Aktar ───────────────────────────────────────────────────────────────
if (typeof window    !== 'undefined') window.ApexBridge    = ApexBridge;
if (typeof module    !== 'undefined') module.exports       = { ApexBridge };
if (typeof globalThis!== 'undefined') globalThis.ApexBridge = ApexBridge;
