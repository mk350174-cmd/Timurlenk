'use strict';

/**
 * main.js — Apex Timurlenk Web Entegrasyonu Ana Dosyası
 *
 * ApexBridge + BoardManager birleştirici.
 * Claude Design UI elementlerini bridge olaylarına bağlar.
 */

// ApexBridge ve BoardManager modüler import
// (build sistemi olmadan: <script type="module"> veya bundler ile kullan)
import { BoardManager } from './board/BoardManager.js';

// ─── Yardımcılar ─────────────────────────────────────────────────────────────

/**
 * Centipawn skorunu görsel stringe çevir
 * +120cp → "+1.20", -340cp → "-3.40", +9500cp → "+M"
 */
function scoreToDisplay(cp) {
  if (Math.abs(cp) > 9000) return cp > 0 ? '+M' : '-M';
  const pawns = cp / 100;
  return (pawns >= 0 ? '+' : '') + pawns.toFixed(2);
}

/** Persona bilgileri */
const PERSONA_INFO = {
  None:        { icon: '⚪', desc: 'Dengeli, standart AI' },
  Machiavelli: { icon: '🦊', desc: 'Kurnaz, taktik odaklı. Kurban yapmayı sever.' },
  Nietzsche:   { icon: '⚡', desc: 'Güç odaklı. Psyche>60 olunca üst güç mod aktif.' },
  Ulgen:       { icon: '☀️', desc: 'Dengeli, pozisyonel. Uzun vadeli plan.' },
  Erlik:       { icon: '🔥', desc: 'Kaotik. Beklenmedik hamleler.' },
  Bozkurt:     { icon: '🐺', desc: 'Saldırgan, keskin. Sürekli baskı.' },
  Tengri:      { icon: '🌌', desc: 'Evrensel denge. En çok yönlü.' },
  DedeKorkut:  { icon: '📜', desc: 'Geleneksel, kitabi. Açılış kitabına bağlı.' },
  Umay:        { icon: '🌸', desc: 'Savunmacı. Karşı atak uzmanı.' },
};

// ─── Ana Başlatma ─────────────────────────────────────────────────────────────

async function init() {
  // ApexBridge global olarak yüklenmiş olmalı (ApexBridge.js script tag)
  if (typeof ApexBridge === 'undefined') {
    console.error('[main] ApexBridge tanımlı değil. HTML\'ye script ekleyin.');
    return;
  }

  const bridge = new ApexBridge({
    enginePath:  '/engine/apex_timur.js',
    workerPath:  '/engine/ApexWorker.js',
    playerColor: 'w',
    difficulty:  'hard',
  });

  // Motor yüklenirken spinner göster
  const loadingEl = document.getElementById('loading-indicator');
  if (loadingEl) loadingEl.hidden = false;

  try {
    await bridge.init();
  } catch (e) {
    console.error('[main] Motor yüklenemedi:', e);
    if (loadingEl) loadingEl.textContent = 'Motor yüklenemedi: ' + e.message;
    return;
  }

  if (loadingEl) loadingEl.hidden = true;

  // BoardManager başlat
  const boardContainer = document.getElementById('board-container');
  if (!boardContainer) { console.error('[main] #board-container bulunamadı'); return; }

  const boardManager = new BoardManager(boardContainer, bridge, { mode: '2d' });
  window._boardManager = boardManager; // debug

  // ─── Persona Seçicisini Doldur ───────────────────────────────────────────────

  const personaSelect = document.getElementById('select-persona');
  if (personaSelect) {
    personaSelect.innerHTML = '';
    for (const [name, info] of Object.entries(PERSONA_INFO)) {
      const opt = document.createElement('option');
      opt.value       = name;
      opt.textContent = info.icon + ' ' + name + ' — ' + info.desc;
      personaSelect.appendChild(opt);
    }
    personaSelect.value = 'None';

    personaSelect.addEventListener('change', () => {
      bridge.bus.emit('engine:setPersona', {
        name:   personaSelect.value,
        psyche: parseInt(document.getElementById('input-psyche')?.value || '0', 10),
      });
    });
  }

  // ─── Bridge Olaylarını UI'a Bağla ────────────────────────────────────────────

  bridge.bus.on('engine:thinking', ({ thinking }) => {
    const el = document.getElementById('thinking-indicator');
    if (el) el.hidden = !thinking;
  });

  bridge.bus.on('engine:info', ({ depth, score, pv, nps, nodes }) => {
    const setText = (id, val) => { const el = document.getElementById(id); if (el) el.textContent = val; };
    setText('analysis-depth', depth ?? '—');
    setText('analysis-score', score != null ? scoreToDisplay(score) : '—');
    setText('analysis-pv',    pv || '—');
    setText('analysis-nps',   nps != null ? (nps / 1000).toFixed(0) + 'k' : '—');

    // Değerlendirme çubuğu (−10..+10 arası göster)
    const bar = document.getElementById('eval-bar-fill');
    if (bar && score != null) {
      const clamped = Math.max(-1000, Math.min(1000, score));
      const pct = (clamped + 1000) / 2000 * 100;
      bar.style.height = pct + '%';
    }
  });

  bridge.bus.on('game:over', ({ reason, winner }) => {
    const modal    = document.getElementById('game-over-modal');
    const msgEl    = document.getElementById('game-over-message');
    if (!modal || !msgEl) return;

    const msgs = {
      checkmate: winner === 'w' ? 'Beyaz Kazandı — Mat!' : 'Siyah Kazandı — Mat!',
      stalemate: 'Pat — Beraberlik',
      citadel:   'Citadel Beraberliği',
    };
    msgEl.textContent = msgs[reason] || reason;
    modal.hidden = false;
  });

  bridge.bus.on('error', ({ message }) => {
    console.error('[Apex]', message);
  });

  // ─── UI Buton Bağlamaları ─────────────────────────────────────────────────────

  const bind = (id, fn) => {
    const el = document.getElementById(id);
    if (el) el.addEventListener('click', fn);
  };

  bind('btn-start', () => {
    const persona    = document.getElementById('select-persona')?.value    || 'None';
    const psyche     = parseInt(document.getElementById('input-psyche')?.value || '0', 10);
    const difficulty = document.getElementById('select-difficulty')?.value || 'hard';
    const color      = document.getElementById('select-color')?.value      || 'w';
    bridge.bus.emit('game:start', { persona, psyche, difficulty, playerColor: color });
  });

  bind('btn-new',    () => bridge.bus.emit('game:new'));
  bind('btn-undo',   () => bridge.bus.emit('game:undo'));
  bind('btn-resign', () => bridge.bus.emit('game:resign'));
  bind('btn-flip',   () => boardManager.flip());

  bind('btn-2d',   () => boardManager.setMode('2d'));
  bind('btn-3d',   () => boardManager.setMode('3d'));

  bind('btn-game-over-new', () => {
    const modal = document.getElementById('game-over-modal');
    if (modal) modal.hidden = true;
    bridge.bus.emit('game:new');
  });

  // ─── İlk Oyunu Başlat ────────────────────────────────────────────────────────

  bridge.bus.emit('game:start', {
    persona:     'None',
    psyche:      0,
    difficulty:  'hard',
    playerColor: 'w',
  });
}

// DOM hazır olunca başlat
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}
