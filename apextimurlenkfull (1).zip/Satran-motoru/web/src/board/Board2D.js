'use strict';

/**
 * Board2D.js — Apex Timurlenk SVG Tahta (11×10 + 2 Citadel)
 *
 * Kullanım:
 *   const board = new Board2D(container, { flipped: false, onMove: (from, to, promo) => {} });
 *   board.update(pieces);              // pieces: [{sq, type, color}]
 *   board.setLegalMoves(legalMoves);   // ["e2e4", "swap:e1g3", ...]
 *   board.animateMove(from, to, isSwap);
 */

const FILES     = 11;  // a–k
const RANKS     = 10;  // 1–10
const SQ_SIZE   = 60;  // px
const BOARD_W   = FILES * SQ_SIZE;       // 660px
const BOARD_H   = RANKS * SQ_SIZE;       // 600px
const LABEL_W   = 24;
const LABEL_H   = 20;

// SVG taş sembol haritası (Unicode dingbat yerine metin kodları)
const PIECE_CHAR = {
  K: { w: '♔', b: '♚' },
  R: { w: '♖', b: '♜' },
  Z: { w: 'Z', b: 'z' },  // Zürafa — özel sembol
  T: { w: 'T', b: 't' },  // Talia
  N: { w: '♘', b: '♞' },
  C: { w: 'C', b: 'c' },  // Deve
  E: { w: 'E', b: 'e' },  // Fil (2-kare atlama)
  W: { w: 'W', b: 'w' },  // Savaş Makinesi
  F: { w: '♕', b: '♛' },  // Ferz
  V: { w: 'V', b: 'v' },  // Vali
  P: { w: '♙', b: '♟' },
};

// Terfi seçenekleri (Şah hariç)
const PROMO_PIECES = ['R', 'Z', 'N', 'V', 'C', 'E', 'W', 'F'];

// Renk paleti
const COLOR = {
  light:        '#f0d9b5',
  dark:         '#b58863',
  citadel:      '#7ec8e3',
  selected:     'rgba(20, 85, 30, 0.5)',
  legalDot:     'rgba(20, 85, 30, 0.3)',
  legalCapture: 'rgba(20, 85, 30, 0.4)',
  lastMove:     'rgba(155, 199, 0, 0.4)',
  check:        'rgba(220, 50, 50, 0.6)',
};

export class Board2D {
  /**
   * @param {HTMLElement} container
   * @param {object} opts
   * @param {boolean}  opts.flipped    - Tahtayı çevir (siyah alta)
   * @param {function} opts.onMove     - Hamle callback: (from, to, promo) => void
   */
  constructor(container, opts = {}) {
    this._container   = container;
    this._flipped     = opts.flipped || false;
    this._onMove      = opts.onMove  || null;
    this._pieces      = [];      // [{sq, type, color}]
    this._legalMoves  = [];      // ["e2e4", "swap:e1g3", ...]
    this._selected    = null;    // seçili kare string ("e2" veya null)
    this._legalDests  = [];      // seçili taşın gidebileceği kareler
    this._lastFrom    = null;
    this._lastTo      = null;
    this._inCheck     = null;    // şah altındaki tarafın şah karesi
    this._swapPhase   = false;   // swap için 2. seçim bekleniyor mu
    this._swapFrom    = null;    // swap:X hamlelerinde kaynak
    this._svg         = null;
    this._pieceGroup  = null;
    this._hlGroup     = null;
    this._promoModal  = null;
    this._pendingMove = null;    // terfi bekliyor: {from, to}

    this._init();
  }

  // ─── Başlatma ────────────────────────────────────────────────────────────────

  _init() {
    const ns  = 'http://www.w3.org/2000/svg';
    const svg = document.createElementNS(ns, 'svg');
    const totalW = BOARD_W + LABEL_W;
    const totalH = BOARD_H + LABEL_H;
    svg.setAttribute('viewBox', `0 0 ${totalW} ${totalH}`);
    svg.setAttribute('width',  totalW);
    svg.setAttribute('height', totalH);
    svg.style.userSelect = 'none';
    svg.style.cursor     = 'pointer';
    this._svg = svg;

    // Kare renk katmanı
    const sqGroup = document.createElementNS(ns, 'g');
    sqGroup.setAttribute('class', 'squares');
    svg.appendChild(sqGroup);
    this._sqGroup = sqGroup;

    // Vurgu katmanı (seçim, yasal hamleler, son hamle)
    const hlGroup = document.createElementNS(ns, 'g');
    svg.appendChild(hlGroup);
    this._hlGroup = hlGroup;

    // Taş katmanı
    const pieceGroup = document.createElementNS(ns, 'g');
    svg.appendChild(pieceGroup);
    this._pieceGroup = pieceGroup;

    // Koordinat etiketleri
    this._buildLabels(svg, ns);

    // Tıklama dinleyicisi
    svg.addEventListener('click', (e) => this._handleClick(e));

    this._container.innerHTML = '';
    this._container.appendChild(svg);

    this._buildSquares(sqGroup, ns);
    this._buildPromoModal();
  }

  _buildSquares(group, ns) {
    for (let rank = 0; rank < RANKS; rank++) {
      for (let file = 0; file < FILES; file++) {
        const rect = document.createElementNS(ns, 'rect');
        const { x, y } = this._sqXY(file, rank);
        rect.setAttribute('x', x);
        rect.setAttribute('y', y);
        rect.setAttribute('width',  SQ_SIZE);
        rect.setAttribute('height', SQ_SIZE);
        rect.setAttribute('fill',   this._sqColor(file, rank));
        rect.setAttribute('data-sq', this._fileRankToSq(file, rank));
        group.appendChild(rect);
      }
    }

    // Citadel kareleri
    ['ct0', 'ct1'].forEach((ct, i) => {
      const rect = document.createElementNS(ns, 'rect');
      const { x, y } = this._citadelXY(ct);
      rect.setAttribute('x', x);
      rect.setAttribute('y', y);
      rect.setAttribute('width',  SQ_SIZE);
      rect.setAttribute('height', SQ_SIZE);
      rect.setAttribute('fill',   COLOR.citadel);
      rect.setAttribute('stroke', '#0077a8');
      rect.setAttribute('stroke-width', '2');
      rect.setAttribute('data-sq', ct);
      rect.setAttribute('opacity', '0.7');
      group.appendChild(rect);

      const label = document.createElementNS(ns, 'text');
      label.setAttribute('x', x + SQ_SIZE / 2);
      label.setAttribute('y', y + SQ_SIZE / 2 + 5);
      label.setAttribute('text-anchor', 'middle');
      label.setAttribute('font-size', '10');
      label.setAttribute('fill', '#004d66');
      label.textContent = i === 0 ? 'ct0 (beyaz)' : 'ct1 (siyah)';
      group.appendChild(label);
    });
  }

  _buildLabels(svg, ns) {
    const fileLetters = 'abcdefghijk';
    for (let f = 0; f < FILES; f++) {
      const t = document.createElementNS(ns, 'text');
      const x = LABEL_W + f * SQ_SIZE + SQ_SIZE / 2;
      t.setAttribute('x', x);
      t.setAttribute('y', BOARD_H + LABEL_H + 4);
      t.setAttribute('text-anchor', 'middle');
      t.setAttribute('font-size', '12');
      t.setAttribute('fill', '#ccc');
      t.textContent = this._flipped ? fileLetters[FILES - 1 - f] : fileLetters[f];
      svg.appendChild(t);
    }
    for (let r = 0; r < RANKS; r++) {
      const t = document.createElementNS(ns, 'text');
      const y = r * SQ_SIZE + SQ_SIZE / 2 + 4;
      const rankNum = this._flipped ? r + 1 : RANKS - r;
      t.setAttribute('x', LABEL_W / 2);
      t.setAttribute('y', y);
      t.setAttribute('text-anchor', 'middle');
      t.setAttribute('font-size', '12');
      t.setAttribute('fill', '#ccc');
      t.textContent = rankNum;
      svg.appendChild(t);
    }
  }

  _buildPromoModal() {
    const modal = document.createElement('div');
    modal.style.cssText = `
      display: none; position: absolute; background: #2a2a3e; border: 2px solid #00d4ff;
      border-radius: 8px; padding: 10px; gap: 8px; flex-wrap: wrap;
      justify-content: center; z-index: 1000; box-shadow: 0 4px 20px rgba(0,0,0,.6);
    `;
    PROMO_PIECES.forEach(pt => {
      const btn = document.createElement('button');
      btn.style.cssText = `
        width: 48px; height: 48px; font-size: 24px; cursor: pointer;
        background: #1a1a2e; border: 1px solid #555; border-radius: 4px; color: #fff;
      `;
      btn.textContent = PIECE_CHAR[pt]?.w || pt;
      btn.title = pt;
      btn.addEventListener('click', () => this._promoSelect(pt));
      modal.appendChild(btn);
    });
    this._promoModal = modal;
    this._container.style.position = 'relative';
    this._container.appendChild(modal);
  }

  // ─── Güncelleme API ───────────────────────────────────────────────────────────

  /** Taş pozisyonlarını güncelle */
  update(pieces) {
    this._pieces = pieces || [];
    this._renderPieces();
  }

  /** Yasal hamleleri ayarla */
  setLegalMoves(legalMoves) {
    this._legalMoves = legalMoves || [];
  }

  /** Son hamleyi vurgula */
  setLastMove(from, to) {
    this._lastFrom = from;
    this._lastTo   = to;
    this._renderHighlights();
  }

  /** Şah altındaki kareyi işaretle (null = yok) */
  setInCheck(sq) {
    this._inCheck = sq;
    this._renderHighlights();
  }

  /** Tahtayı çevir */
  flip() {
    this._flipped = !this._flipped;
    this._render();
  }

  // ─── Klik Yönetimi ────────────────────────────────────────────────────────────

  _handleClick(e) {
    const sq = e.target.getAttribute('data-sq') ||
               e.target.closest('[data-sq]')?.getAttribute('data-sq');
    if (!sq) return;
    this._onSquareClick(sq);
  }

  _onSquareClick(sq) {
    // Swap hamlesi 2. aşaması
    if (this._swapPhase) {
      const from = this._swapFrom;
      this._swapPhase = false;
      this._swapFrom  = null;
      this._clearSelection();
      if (this._onMove) this._onMove('swap:' + from, sq, null);
      return;
    }

    // Zaten seçili bir taş var
    if (this._selected) {
      // Swap başlatma (swap: hamleler için)
      const swapKey = 'swap:' + this._selected + sq;
      const swapMatch = this._legalDests.find(d => d === 'swap:' + sq);
      if (swapMatch) {
        // swap:e1g3 formatına bak — seçili kare zaten from
        const fullSwap = 'swap:' + this._selected + sq;
        const isValidSwap = this._legalMoves.some(m => m === fullSwap || m === 'swap:' + this._selected);
        if (isValidSwap) {
          this._clearSelection();
          if (this._onMove) this._onMove('swap:' + this._selected, sq, null);
          return;
        }
      }

      // Normal hamle hedefi
      if (this._legalDests.includes(sq)) {
        const from = this._selected;
        this._clearSelection();
        if (this._needsPromo(from, sq)) {
          this._pendingMove = { from, to: sq };
          this._showPromoModal(sq);
        } else {
          if (this._onMove) this._onMove(from, sq, null);
        }
        return;
      }

      // Kendi taşını yeniden seç
      this._clearSelection();
    }

    // Yeni taş seç
    const piece = this._pieces.find(p => p.sq === sq);
    if (!piece) return;

    this._selected   = sq;
    this._legalDests = this._getLegalDestsFor(sq);
    this._renderHighlights();
  }

  _getLegalDestsFor(sq) {
    const dests = [];
    for (const m of this._legalMoves) {
      if (m.startsWith('swap:')) {
        // swap:e1g3 → e1 seçiliyse g3 hedef
        const rest = m.slice(5);
        const from = rest.slice(0, 2);
        const to   = rest.slice(2, 4);
        if (from === sq) dests.push('swap:' + to);
      } else {
        const from = m.slice(0, 2);
        const to   = m.slice(2, 4);
        if (from === sq) dests.push(to);
      }
    }
    return dests;
  }

  _needsPromo(from, to) {
    const piece = this._pieces.find(p => p.sq === from);
    if (!piece || piece.type !== 'P') return false;
    const rank = this._sqRank(to);
    return (piece.color === 'w' && rank === 10) || (piece.color === 'b' && rank === 1);
  }

  _clearSelection() {
    this._selected   = null;
    this._legalDests = [];
    this._renderHighlights();
  }

  // ─── Terfi Modal ─────────────────────────────────────────────────────────────

  _showPromoModal(toSq) {
    const { x, y } = this._sqXYBySq(toSq);
    const rect = this._container.getBoundingClientRect();
    const svgRect = this._svg.getBoundingClientRect();
    const scaleX = svgRect.width  / (BOARD_W + LABEL_W);
    const scaleY = svgRect.height / (BOARD_H + LABEL_H);
    this._promoModal.style.left    = ((LABEL_W + x) * scaleX) + 'px';
    this._promoModal.style.top     = (y * scaleY) + 'px';
    this._promoModal.style.display = 'flex';
  }

  _promoSelect(pt) {
    this._promoModal.style.display = 'none';
    if (this._pendingMove && this._onMove) {
      this._onMove(this._pendingMove.from, this._pendingMove.to, pt);
    }
    this._pendingMove = null;
  }

  // ─── Animasyon ────────────────────────────────────────────────────────────────

  /** Hamle animasyonu */
  animateMove(from, to, isSwap = false) {
    this._lastFrom = from;
    this._lastTo   = to;
    this._renderHighlights();
    if (isSwap) {
      this._animateSwap(from, to);
    } else {
      this._animatePiece(from, to);
    }
  }

  _animatePiece(from, to) {
    const el = this._svg.querySelector(`[data-piece-sq="${from}"]`);
    if (!el) return;
    const { x: x0, y: y0 } = this._sqXYBySq(from);
    const { x: x1, y: y1 } = this._sqXYBySq(to);
    const dx = x1 - x0, dy = y1 - y0;
    const dur = 200;
    let start = null;
    const step = (ts) => {
      if (!start) start = ts;
      const t = Math.min((ts - start) / dur, 1);
      const ease = t * (2 - t); // ease-out
      el.setAttribute('transform', `translate(${dx * ease},${dy * ease})`);
      if (t < 1) requestAnimationFrame(step);
      else el.removeAttribute('transform');
    };
    requestAnimationFrame(step);
  }

  _animateSwap(from, to) {
    // İki taşı birbirine doğru hareket ettir
    this._animatePiece(from, to);
    this._animatePiece(to, from);
  }

  // ─── Render ───────────────────────────────────────────────────────────────────

  _render() {
    this._renderHighlights();
    this._renderPieces();
  }

  _renderHighlights() {
    const ns = 'http://www.w3.org/2000/svg';
    this._hlGroup.innerHTML = '';

    // Son hamle
    [this._lastFrom, this._lastTo].forEach(sq => {
      if (!sq) return;
      const { x, y } = this._sqXYBySq(sq);
      const r = document.createElementNS(ns, 'rect');
      r.setAttribute('x', x); r.setAttribute('y', y);
      r.setAttribute('width', SQ_SIZE); r.setAttribute('height', SQ_SIZE);
      r.setAttribute('fill', COLOR.lastMove);
      r.setAttribute('pointer-events', 'none');
      this._hlGroup.appendChild(r);
    });

    // Şah altı
    if (this._inCheck) {
      const { x, y } = this._sqXYBySq(this._inCheck);
      const r = document.createElementNS(ns, 'rect');
      r.setAttribute('x', x); r.setAttribute('y', y);
      r.setAttribute('width', SQ_SIZE); r.setAttribute('height', SQ_SIZE);
      r.setAttribute('fill', COLOR.check);
      r.setAttribute('pointer-events', 'none');
      this._hlGroup.appendChild(r);
    }

    // Seçili kare
    if (this._selected) {
      const { x, y } = this._sqXYBySq(this._selected);
      const r = document.createElementNS(ns, 'rect');
      r.setAttribute('x', x); r.setAttribute('y', y);
      r.setAttribute('width', SQ_SIZE); r.setAttribute('height', SQ_SIZE);
      r.setAttribute('fill', COLOR.selected);
      r.setAttribute('pointer-events', 'none');
      this._hlGroup.appendChild(r);
    }

    // Yasal hamle noktaları / kareleri
    for (const dest of this._legalDests) {
      const actualSq = dest.startsWith('swap:') ? dest.slice(5) : dest;
      const { x, y } = this._sqXYBySq(actualSq);
      const isCapture = this._pieces.some(p => p.sq === actualSq);
      if (isCapture) {
        const r = document.createElementNS(ns, 'rect');
        r.setAttribute('x', x); r.setAttribute('y', y);
        r.setAttribute('width', SQ_SIZE); r.setAttribute('height', SQ_SIZE);
        r.setAttribute('fill', COLOR.legalCapture);
        r.setAttribute('stroke', 'rgba(20,85,30,.8)');
        r.setAttribute('stroke-width', '3');
        r.setAttribute('pointer-events', 'none');
        this._hlGroup.appendChild(r);
      } else {
        const cx = x + SQ_SIZE / 2, cy = y + SQ_SIZE / 2;
        const circle = document.createElementNS(ns, 'circle');
        circle.setAttribute('cx', cx); circle.setAttribute('cy', cy);
        circle.setAttribute('r', SQ_SIZE / 5);
        circle.setAttribute('fill', COLOR.legalDot);
        circle.setAttribute('pointer-events', 'none');
        this._hlGroup.appendChild(circle);
      }
    }
  }

  _renderPieces() {
    const ns = 'http://www.w3.org/2000/svg';
    this._pieceGroup.innerHTML = '';

    for (const p of this._pieces) {
      const { x, y } = this._sqXYBySq(p.sq);
      if (x < 0) continue; // geçersiz kare

      const g = document.createElementNS(ns, 'g');
      g.setAttribute('data-piece-sq', p.sq);
      g.setAttribute('data-sq', p.sq); // tıklama için

      const char = PIECE_CHAR[p.type]?.[p.color] || p.type;
      const isUnicode = char.charCodeAt(0) > 127;

      const t = document.createElementNS(ns, 'text');
      t.setAttribute('x', x + SQ_SIZE / 2);
      t.setAttribute('y', y + SQ_SIZE / 2 + (isUnicode ? 8 : 6));
      t.setAttribute('text-anchor', 'middle');
      t.setAttribute('font-size', isUnicode ? '36' : '22');
      t.setAttribute('font-weight', isUnicode ? 'normal' : 'bold');
      t.setAttribute('fill', p.color === 'w' ? '#fff' : '#111');
      t.setAttribute('stroke', p.color === 'w' ? '#333' : '#ccc');
      t.setAttribute('stroke-width', '0.8');
      t.setAttribute('pointer-events', 'none');
      t.textContent = char;

      g.appendChild(t);
      g.setAttribute('style', 'cursor: pointer');
      this._pieceGroup.appendChild(g);
    }
  }

  // ─── Koordinat Yardımcıları ───────────────────────────────────────────────────

  _sqXY(file, rank) {
    const displayFile  = this._flipped ? (FILES - 1 - file) : file;
    const displayRank  = this._flipped ? rank : (RANKS - 1 - rank);
    return {
      x: LABEL_W + displayFile * SQ_SIZE,
      y: displayRank * SQ_SIZE,
    };
  }

  _sqXYBySq(sq) {
    if (sq === 'ct0') return this._citadelXY('ct0');
    if (sq === 'ct1') return this._citadelXY('ct1');
    const file = sq.charCodeAt(0) - 'a'.charCodeAt(0);
    const rank = parseInt(sq.slice(1)) - 1;
    if (isNaN(file) || isNaN(rank) || file < 0 || file >= FILES || rank < 0 || rank >= RANKS)
      return { x: -999, y: -999 };
    return this._sqXY(file, rank);
  }

  _citadelXY(ct) {
    // ct0: beyaz citadel (k2 sağı) → board dışı sağ-alt bölge
    // ct1: siyah citadel (a9 solu) → board dışı sol-üst bölge
    // Görsel olarak board'un köşelerine yerleştir
    if (ct === 'ct0') return { x: LABEL_W + (FILES) * SQ_SIZE + 4, y: BOARD_H - 2 * SQ_SIZE };
    return { x: LABEL_W - SQ_SIZE - 4, y: 0 };
  }

  _sqColor(file, rank) {
    return (file + rank) % 2 === 0 ? COLOR.light : COLOR.dark;
  }

  _fileRankToSq(file, rank) {
    return String.fromCharCode('a'.charCodeAt(0) + file) + (rank + 1);
  }

  _sqRank(sq) {
    if (sq.startsWith('ct')) return null;
    return parseInt(sq.slice(1));
  }
}
