'use strict';

/**
 * BoardManager.js — 2D ↔ 3D Tahta Geçiş Yöneticisi
 *
 * Kullanım:
 *   const bm = new BoardManager(container, bridge);
 *   bm.setMode('2d');   // veya '3d'
 *   bm.update(data);    // board:update payload
 */

import { Board2D } from './Board2D.js';

export class BoardManager {
  /**
   * @param {HTMLElement} container
   * @param {object}      bridge      - ApexBridge instance
   * @param {object}      opts
   * @param {string}      opts.mode   - '2d' | '3d' (varsayılan: '2d')
   */
  constructor(container, bridge, opts = {}) {
    this._container = container;
    this._bridge    = bridge;
    this._mode      = opts.mode || '2d';
    this._board2d   = null;
    this._board3d   = null;

    this._initBoard2D();
    this._bindBridgeEvents();
  }

  // ─── Tahta Başlatma ───────────────────────────────────────────────────────────

  _initBoard2D() {
    this._board2d = new Board2D(this._container, {
      flipped: false,
      onMove: (from, to, promo) => {
        this._bridge.bus.emit('game:move', { from, to, promo: promo || null });
      },
    });
  }

  async _initBoard3D() {
    // Board3D lazy import — sadece '3d' moduna geçilince yükle
    try {
      const { Board3D } = await import('./Board3D.js');
      this._board3d = new Board3D(this._container, {
        onMove: (from, to) => {
          this._bridge.bus.emit('game:move', { from, to, promo: null });
        },
      });
    } catch (e) {
      console.warn('[BoardManager] Board3D yüklenemedi, 2D modunda kalınıyor:', e.message);
      this._mode = '2d';
    }
  }

  // ─── Mod Geçişi ──────────────────────────────────────────────────────────────

  async setMode(mode) {
    if (mode === this._mode) return;

    if (mode === '3d') {
      if (!this._board3d) await this._initBoard3D();
      if (!this._board3d) return; // yükleme başarısız
      this._board2d && this._board2d._svg?.remove();
    } else {
      this._board3d && this._board3d.destroy();
      if (!this._container.contains(this._board2d?._svg)) {
        this._container.innerHTML = '';
        this._initBoard2D();
      }
    }

    this._mode = mode;
    // Mevcut pozisyonu yeni tahtaya aktar
    this._bridge.engine.getBoardJson().then(data => {
      this.update({ pieces: data.pieces });
    }).catch(() => {});
  }

  flip() {
    if (this._mode === '2d') this._board2d?.flip();
    else                     this._board3d?.flip();
  }

  // ─── Güncelleme ───────────────────────────────────────────────────────────────

  /** board:update payload ile tahtayı güncelle */
  update({ pieces, legalMoves, inCheck, turn }) {
    if (this._mode === '2d') {
      this._board2d?.update(pieces || []);
      this._board2d?.setLegalMoves(legalMoves || []);

      // Şah altı kontrolü
      if (inCheck) {
        const checkSide = turn === 'w' ? 'w' : 'b';
        const kingSq = pieces?.find(p => p.type === 'K' && p.color === checkSide)?.sq;
        this._board2d?.setInCheck(kingSq || null);
      } else {
        this._board2d?.setInCheck(null);
      }
    } else {
      this._board3d?.update(pieces || []);
    }
  }

  /** engine:move sonrası son hamleyi işaretle */
  markLastMove(from, to, isSwap = false) {
    if (this._mode === '2d') {
      this._board2d?.setLastMove(from, to);
      this._board2d?.animateMove(from, to, isSwap);
    } else {
      this._board3d?.animateMove(from, to);
    }
  }

  // ─── Bridge Bağlantısı ────────────────────────────────────────────────────────

  _bindBridgeEvents() {
    const bus = this._bridge.bus;

    bus.on('board:update', (data) => {
      this.update(data);
    });

    bus.on('engine:move', ({ from, to, isSwap }) => {
      this.markLastMove(from, to, isSwap);
    });
  }
}
