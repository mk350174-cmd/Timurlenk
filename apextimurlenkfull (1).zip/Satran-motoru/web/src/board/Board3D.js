'use strict';

/**
 * Board3D.js — Apex Timurlenk Three.js 3D Tahta (11×10 + 2 Citadel)
 *
 * Board2D ile aynı public API:
 *   const board = new Board3D(container, { flipped, onMove });
 *   board.update(pieces)
 *   board.setLegalMoves(legalMoves)
 *   board.setLastMove(from, to)
 *   board.setInCheck(sq)
 *   board.flip()
 *   board.animateMove(from, to, isSwap)
 *   board.destroy()
 *
 * Three.js r128 CDN üzerinden global THREE objesi gerektirir.
 */

const FILES   = 11;
const RANKS   = 10;
const SQ      = 1.0;     // kare büyüklüğü (Three.js birimi)
const GAP     = 0.02;    // kareler arası boşluk
const H_BOARD = 0.12;    // tahta yüksekliği
const H_PIECE = 0.22;    // taş yüksekliği
const PIECE_R = 0.32;    // taş yarıçapı

// Renk paleti
const C = {
  light:       0xf0d9b5,
  dark:        0xb58863,
  citadel:     0x3a9fd1,
  selected:    0x14551e,
  legal:       0x1a6b2a,
  lastMove:    0x9bc700,
  check:       0xdc3232,
  boardBase:   0x2c1810,
  white:       0xf5f5f0,
  black:       0x1a1a20,
  whiteRim:    0xd4af6a,
  blackRim:    0x333355,
  label:       0x888080,
  fog:         0x0f0f14,
};

// Taş tipi → metin (canvas texture için)
const PIECE_LABEL = {
  K:'K', R:'R', Z:'Z', T:'T', N:'N', C:'C', E:'E', W:'W', F:'F', V:'V', P:'P'
};

// Terfi seçenekleri
const PROMO_PIECES = ['R', 'Z', 'N', 'V', 'C', 'E', 'W', 'F'];

function sqName(sq) {
  if (sq === 110) return 'wc';
  if (sq === 111) return 'bc';
  const file = sq % 11;
  const rank = Math.floor(sq / 11);
  return 'abcdefghijk'[file] + (rank + 1);
}

function nameToSq(name) {
  if (name === 'wc') return 110;
  if (name === 'bc') return 111;
  const file = 'abcdefghijk'.indexOf(name[0]);
  const rank = parseInt(name.slice(1)) - 1;
  return rank * 11 + file;
}

export class Board3D {
  constructor(container, opts = {}) {
    this._container  = container;
    this._flipped    = opts.flipped || false;
    this._onMove     = opts.onMove  || null;
    this._pieces     = [];
    this._legalMoves = [];
    this._selected   = null;
    this._legalDests = [];
    this._lastFrom   = null;
    this._lastTo     = null;
    this._inCheck    = null;
    this._swapPhase  = false;
    this._swapFrom   = null;
    this._pendingMove = null;

    // S3 GLB asset entegrasyonu
    // opts.glbBase   → S3 taş GLB kök URL'i (örn. "https://bucket.s3.eu.amazonaws.com/pieces/3d")
    // opts.boardGlb  → Tahta GLB dosyası URL'i (örn. "https://bucket.s3.eu.amazonaws.com/boards/oak.glb")
    this._glbBase  = opts.glbBase  || '';
    this._boardGlb = opts.boardGlb || '';
    // GLB model önbelleği: "K-w" → THREE.Group (klonlanır)
    this._glbCache  = new Map();
    this._glbLoader = null;  // THREE.GLTFLoader, _init()'de oluşturulur

    // Three.js nesneleri
    this._scene    = null;
    this._camera   = null;
    this._renderer = null;
    this._raf      = null;

    // Kare mesh haritası: sqIdx → mesh
    this._sqMeshes   = new Map();
    // Taş mesh haritası: sqIdx → mesh
    this._pieceMeshes = new Map();
    // Seçim göstergesi overlay
    this._selOverlay  = new Map();

    // Texture önbelleği
    this._textureCache = new Map();

    this._promoModal  = null;

    if (typeof THREE === 'undefined') {
      console.error('[Board3D] THREE global bulunamadı. CDN yüklendiğinden emin olun.');
      this._fallbackMessage(container);
      return;
    }

    this._init();
  }

  // ─── Başlatma ──────────────────────────────────────────────────────────────

  _init() {
    const w = this._container.clientWidth  || 660;
    const h = this._container.clientHeight || 600;

    // GLTFLoader — THREE.GLTFLoader global veya addons altında olabilir
    if (typeof THREE.GLTFLoader !== 'undefined') {
      this._glbLoader = new THREE.GLTFLoader();
    } else if (typeof GLTFLoader !== 'undefined') {
      this._glbLoader = new GLTFLoader();
    } else {
      console.warn('[Board3D] GLTFLoader bulunamadı — GLB modeller yüklenmez, prosedürel geometri kullanılır.');
    }

    // Sahne
    this._scene = new THREE.Scene();
    this._scene.background = new THREE.Color(C.fog);
    this._scene.fog = new THREE.Fog(C.fog, 20, 50);

    // Kamera — perspektif, hafif yukarıdan
    this._camera = new THREE.PerspectiveCamera(45, w / h, 0.1, 100);
    this._resetCamera();

    // Renderer
    this._renderer = new THREE.WebGLRenderer({ antialias: true });
    this._renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this._renderer.setSize(w, h);
    this._renderer.shadowMap.enabled = true;
    this._renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this._container.appendChild(this._renderer.domElement);

    // Işıklar
    const ambient = new THREE.AmbientLight(0xffffff, 0.55);
    this._scene.add(ambient);

    const dirLight = new THREE.DirectionalLight(0xfff5e0, 0.9);
    dirLight.position.set(5, 12, 8);
    dirLight.castShadow = true;
    dirLight.shadow.mapSize.width  = 1024;
    dirLight.shadow.mapSize.height = 1024;
    this._scene.add(dirLight);

    const rimLight = new THREE.DirectionalLight(0x4060a0, 0.25);
    rimLight.position.set(-8, 6, -5);
    this._scene.add(rimLight);

    // Tahta tabanı
    this._buildBoard();

    // Orbit kontrolleri (Three.js OrbitControls yoksa basit fareyle döndürme)
    this._initOrbit();

    // Tıklama
    this._renderer.domElement.addEventListener('click', (e) => this._onClick(e));

    // Terfi modal (HTML)
    this._promoModal = this._buildPromoModal();
    this._container.style.position = 'relative';
    this._container.appendChild(this._promoModal);

    // Resize
    this._resizeObs = new ResizeObserver(() => this._onResize());
    this._resizeObs.observe(this._container);

    // Render döngüsü
    this._animate();
  }

  _resetCamera() {
    const cx = (FILES * (SQ + GAP)) / 2 - SQ / 2;
    const cy = (RANKS * (SQ + GAP)) / 2 - SQ / 2;
    this._camera.position.set(cx, 12, cy + 9);
    this._camera.lookAt(cx, 0, cy);
  }

  // ─── Tahta İnşası ──────────────────────────────────────────────────────────

  _buildBoard() {
    const bw = FILES * (SQ + GAP) + 0.3;
    const bd = RANKS * (SQ + GAP) + 0.3;

    // GLB tahta modeli varsa yükle — yoksa prosedürel geometri kullan
    if (this._boardGlb && this._glbLoader) {
      this._glbLoader.load(
        this._boardGlb,
        (gltf) => {
          const boardModel = gltf.scene;
          // 11×10 alanı kaplayacak şekilde ölçeklendir
          const box = new THREE.Box3().setFromObject(boardModel);
          const size = new THREE.Vector3();
          box.getSize(size);
          const scale = Math.min(bw / size.x, bd / size.z);
          boardModel.scale.setScalar(scale);
          boardModel.position.set(bw / 2 - 0.65, -H_BOARD * 0.5, bd / 2 - 0.65);
          boardModel.traverse(m => { if (m.isMesh) m.receiveShadow = true; });
          this._scene.add(boardModel);
        },
        undefined,
        (err) => {
          console.warn('[Board3D] Tahta GLB yüklenemedi, prosedürel geometri kullanılıyor:', err);
          this._buildBoardProcedural(bw, bd);
        }
      );
    } else {
      this._buildBoardProcedural(bw, bd);
    }

    // Kareler, citadel ve etiketler her zaman prosedürel (raycast için gerekli)
    this._buildSquares();
    this._addLabels();
  }

  _buildBoardProcedural(bw, bd) {
    // Zemin plaka
    const baseGeo = new THREE.BoxGeometry(bw, H_BOARD * 0.5, bd);
    const baseMat = new THREE.MeshLambertMaterial({ color: C.boardBase });
    const base    = new THREE.Mesh(baseGeo, baseMat);
    base.position.set(bw / 2 - 0.65, -H_BOARD * 0.5, bd / 2 - 0.65);
    base.receiveShadow = true;
    this._scene.add(base);
  }

  _buildSquares() {

    // Kareler (110 normal + 2 citadel)
    for (let r = 0; r < RANKS; r++) {
      for (let f = 0; f < FILES; f++) {
        const sqIdx = r * FILES + f;
        const isLight = (r + f) % 2 === 0;
        const geo  = new THREE.BoxGeometry(SQ - GAP, H_BOARD, SQ - GAP);
        const mat  = new THREE.MeshLambertMaterial({
          color: isLight ? C.light : C.dark,
        });
        const mesh = new THREE.Mesh(geo, mat);
        mesh.position.set(f * (SQ + GAP), 0, r * (SQ + GAP));
        mesh.receiveShadow = true;
        mesh.userData = { sqIdx };
        this._scene.add(mesh);
        this._sqMeshes.set(sqIdx, mesh);
      }
    }

    // Citadel kareler (wc=110, bc=111) — tahta dışı özel konumlar
    const citadelPositions = [
      { sqIdx: 110, x: FILES * (SQ + GAP) + 0.1, z: 1 * (SQ + GAP) },   // beyaz citadel (k2 yanı)
      { sqIdx: 111, x: -SQ - 0.1,                 z: 8 * (SQ + GAP) },   // siyah citadel (a9 yanı)
    ];
    for (const { sqIdx, x, z } of citadelPositions) {
      const geo  = new THREE.BoxGeometry(SQ - GAP, H_BOARD, SQ - GAP);
      const mat  = new THREE.MeshLambertMaterial({ color: C.citadel });
      const mesh = new THREE.Mesh(geo, mat);
      mesh.position.set(x, 0, z);
      mesh.receiveShadow = true;
      mesh.userData = { sqIdx };
      this._scene.add(mesh);
      this._sqMeshes.set(sqIdx, mesh);
    }

  }

  _addLabels() {
    const files = 'abcdefghijk';
    const makeLabel = (text) => {
      const canvas = document.createElement('canvas');
      canvas.width = 64; canvas.height = 64;
      const ctx = canvas.getContext('2d');
      ctx.fillStyle = 'transparent';
      ctx.clearRect(0, 0, 64, 64);
      ctx.fillStyle = '#9a9090';
      ctx.font = 'bold 36px monospace';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(text, 32, 32);
      return new THREE.CanvasTexture(canvas);
    };

    for (let f = 0; f < FILES; f++) {
      const tex = makeLabel(files[f]);
      const mat = new THREE.SpriteMaterial({ map: tex, transparent: true, opacity: 0.7 });
      const sp  = new THREE.Sprite(mat);
      sp.scale.set(0.5, 0.5, 1);
      sp.position.set(f * (SQ + GAP), 0, -0.7);
      this._scene.add(sp);
    }
    for (let r = 0; r < RANKS; r++) {
      const tex = makeLabel(String(r + 1));
      const mat = new THREE.SpriteMaterial({ map: tex, transparent: true, opacity: 0.7 });
      const sp  = new THREE.Sprite(mat);
      sp.scale.set(0.5, 0.5, 1);
      sp.position.set(-0.7, 0, r * (SQ + GAP));
      this._scene.add(sp);
    }
  }

  // ─── Taş Mesh Üretici ─────────────────────────────────────────────────────

  _makePieceMesh(type, color) {
    const isWhite = color === 'w' || color === 'white' || color === 0;
    const cKey = `${type}-${isWhite ? 'w' : 'b'}`;

    // Silindirden oluşan soyut taş
    const bodyGeo  = new THREE.CylinderGeometry(PIECE_R, PIECE_R * 1.1, H_PIECE, 20);
    const topGeo   = new THREE.SphereGeometry(PIECE_R * 0.7, 16, 8);
    const rimGeo   = new THREE.CylinderGeometry(PIECE_R * 1.2, PIECE_R * 1.3, H_PIECE * 0.08, 20);

    const pieceMat = new THREE.MeshLambertMaterial({
      color: isWhite ? C.white : C.black,
    });
    const rimMat = new THREE.MeshLambertMaterial({
      color: isWhite ? C.whiteRim : C.blackRim,
    });

    const group = new THREE.Group();

    const body = new THREE.Mesh(bodyGeo, pieceMat);
    body.castShadow = true;
    group.add(body);

    const top = new THREE.Mesh(topGeo, pieceMat);
    top.position.y = H_PIECE / 2 + PIECE_R * 0.5;
    top.castShadow = true;
    group.add(top);

    const rim = new THREE.Mesh(rimGeo, rimMat);
    rim.position.y = -H_PIECE / 2 + H_PIECE * 0.04;
    group.add(rim);

    // Canvas texture ile taş harfi
    const labelTex = this._getPieceTex(type, isWhite);
    const labelMat = new THREE.SpriteMaterial({ map: labelTex, transparent: true, opacity: 0.95 });
    const label    = new THREE.Sprite(labelMat);
    label.scale.set(0.5, 0.5, 1);
    label.position.set(0, H_PIECE / 2 + PIECE_R * 1.1 + 0.1, 0);
    group.add(label);

    group.position.y = H_BOARD / 2 + H_PIECE / 2;
    return group;
  }

  // ─── GLB Model Yükleme ───────────────────────────────────────────────────

  /**
   * S3'ten GLB taş modelini yükler ve önbelleğe alır.
   * URL formatı: {glbBase}/{type}/{color}.glb
   *   Örn: https://bucket.s3.eu.amazonaws.com/pieces/3d/K/white.glb
   *
   * GLB dosyaları yoksa veya yükleme başarısız olursa prosedürel geometri
   * (_makePieceMesh) otomatik olarak devreye girer.
   */
  async _loadGLBPiece(type, isWhite) {
    const colorDir = isWhite ? 'white' : 'black';
    const cacheKey = `${type}-${colorDir}`;

    if (this._glbCache.has(cacheKey)) {
      return this._glbCache.get(cacheKey).clone();
    }

    if (!this._glbLoader || !this._glbBase) return null;

    const url = `${this._glbBase}/${type}/${colorDir}.glb`;

    return new Promise((resolve) => {
      this._glbLoader.load(
        url,
        (gltf) => {
          const model = gltf.scene;
          model.traverse(m => {
            if (m.isMesh) {
              m.castShadow = true;
              // Beyaz/siyah renk tonu uygula (modelin orijinal malzeme rengi korunur,
              // sadece hafif bir tint eklenir)
              if (m.material) {
                m.material = m.material.clone();
                const tint = isWhite ? 0xf5f5f0 : 0x1a1a20;
                m.material.color.lerp(new THREE.Color(tint), 0.15);
              }
            }
          });
          // Kare büyüklüğüne sığacak şekilde ölçekle
          const box = new THREE.Box3().setFromObject(model);
          const size = new THREE.Vector3();
          box.getSize(size);
          const maxDim = Math.max(size.x, size.z);
          if (maxDim > 0) model.scale.multiplyScalar((PIECE_R * 1.8) / maxDim);
          model.position.y = H_BOARD / 2;
          this._glbCache.set(cacheKey, model);
          resolve(model.clone());
        },
        undefined,
        () => {
          // Yükleme hatası — prosedürel fallback
          resolve(null);
        }
      );
    });
  }

  /**
   * Taş mesh oluşturur: GLB varsa GLB, yoksa prosedürel geometri.
   * GLB yüklemesi async olduğu için, önce prosedürel mesh yerleştirilir
   * ve GLB yüklenince swap edilir.
   */
  _placePieceWithGLB(type, color, sqIdx) {
    const isWhite = color === 'w' || color === 'white' || color === 0;
    const pos = this._sqPos(sqIdx);

    // Hemen prosedürel mesh yerleştir (GLB gelene kadar görünür)
    const placeholder = this._makePieceMesh(type, color);
    placeholder.position.copy(pos);
    placeholder.userData = { sqIdx, type, color };
    this._scene.add(placeholder);
    this._pieceMeshes.set(sqIdx, placeholder);

    if (this._glbBase && this._glbLoader) {
      this._loadGLBPiece(type, isWhite).then(glbModel => {
        if (!glbModel) return; // Yükleme başarısız — prosedürel mesh kalır
        // Hâlâ aynı karedeyse swap et
        if (this._pieceMeshes.get(sqIdx) === placeholder) {
          this._scene.remove(placeholder);
          glbModel.position.copy(pos);
          glbModel.userData = { sqIdx, type, color };
          this._scene.add(glbModel);
          this._pieceMeshes.set(sqIdx, glbModel);
        }
      });
    }
  }

  _getPieceTex(type, isWhite) {
    const key = type + (isWhite ? 'w' : 'b');
    if (this._textureCache.has(key)) return this._textureCache.get(key);

    const canvas = document.createElement('canvas');
    canvas.width = 128; canvas.height = 128;
    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, 128, 128);
    ctx.fillStyle = isWhite ? '#111' : '#eee';
    ctx.font = 'bold 72px monospace';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(PIECE_LABEL[type] || '?', 64, 64);

    const tex = new THREE.CanvasTexture(canvas);
    this._textureCache.set(key, tex);
    return tex;
  }

  // ─── Kare Konumlandırma ───────────────────────────────────────────────────

  _sqPos(sqIdx) {
    const mesh = this._sqMeshes.get(sqIdx);
    if (!mesh) return new THREE.Vector3(0, H_BOARD / 2, 0);
    return new THREE.Vector3(mesh.position.x, H_BOARD / 2, mesh.position.z);
  }

  // ─── Public API ──────────────────────────────────────────────────────────

  update(pieces) {
    this._pieces = pieces || [];
    this._rebuildPieces();
  }

  setLegalMoves(legalMoves) {
    this._legalMoves = legalMoves || [];
    this._updateHighlights();
  }

  setLastMove(from, to) {
    this._lastFrom = from;
    this._lastTo   = to;
    this._updateSqColors();
  }

  setInCheck(sq) {
    this._inCheck = sq;
    this._updateSqColors();
  }

  flip() {
    this._flipped = !this._flipped;
    // Kamera karşı tarafa döner
    const cx = (FILES * (SQ + GAP)) / 2 - SQ / 2;
    const cy = (RANKS * (SQ + GAP)) / 2 - SQ / 2;
    if (this._flipped) {
      this._camera.position.set(cx, 12, cy - 9);
      this._camera.lookAt(cx, 0, cy);
    } else {
      this._resetCamera();
    }
  }

  animateMove(from, to, isSwap = false) {
    const fromSq = nameToSq(from);
    const toSq   = nameToSq(to);
    const mesh   = this._pieceMeshes.get(fromSq);
    if (!mesh) return;

    const targetPos = this._sqPos(toSq);
    const startPos  = mesh.position.clone();
    const peakY     = startPos.y + 1.5;
    let t = 0;

    const step = () => {
      t += 0.05;
      if (t >= 1) {
        mesh.position.set(targetPos.x, targetPos.y, targetPos.z);
        return;
      }
      // Arc motion
      const eased = t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t;
      mesh.position.x = startPos.x + (targetPos.x - startPos.x) * eased;
      mesh.position.z = startPos.z + (targetPos.z - startPos.z) * eased;
      mesh.position.y = startPos.y + Math.sin(t * Math.PI) * 1.5;
      requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  }

  destroy() {
    if (this._raf) cancelAnimationFrame(this._raf);
    if (this._resizeObs) this._resizeObs.disconnect();
    if (this._renderer) {
      this._renderer.dispose();
      this._renderer.domElement.remove();
    }
    if (this._promoModal) this._promoModal.remove();
    this._textureCache.forEach(t => t.dispose());
    this._textureCache.clear();
  }

  // ─── İç Render ───────────────────────────────────────────────────────────

  _rebuildPieces() {
    // Eski taş meshlerini kaldır
    this._pieceMeshes.forEach(mesh => this._scene.remove(mesh));
    this._pieceMeshes.clear();

    for (const piece of this._pieces) {
      if (this._glbBase && this._glbLoader) {
        // GLB modu: async yükleme + prosedürel placeholder
        this._placePieceWithGLB(piece.type, piece.color, piece.sq);
      } else {
        // Prosedürel mod
        const mesh = this._makePieceMesh(piece.type, piece.color);
        const pos  = this._sqPos(piece.sq);
        mesh.position.set(pos.x, pos.y, pos.z);
        mesh.userData = { sqIdx: piece.sq, type: piece.type, color: piece.color };
        this._scene.add(mesh);
        this._pieceMeshes.set(piece.sq, mesh);
      }
    }

    this._updateSqColors();
    this._updateHighlights();
  }

  _updateSqColors() {
    this._sqMeshes.forEach((mesh, sqIdx) => {
      const name = sqName(sqIdx);
      if (sqIdx === 110 || sqIdx === 111) {
        mesh.material.color.setHex(C.citadel);
        return;
      }
      const f = sqIdx % FILES;
      const r = Math.floor(sqIdx / FILES);
      let baseColor = (r + f) % 2 === 0 ? C.light : C.dark;

      if (name === this._lastFrom || name === this._lastTo) baseColor = C.lastMove;
      if (this._inCheck && name === this._inCheck) baseColor = C.check;
      if (this._selected === name) baseColor = C.selected;

      mesh.material.color.setHex(baseColor);
    });
  }

  _updateHighlights() {
    // Seçim varsa yasal hedefleri işaretle
    this._sqMeshes.forEach((mesh, sqIdx) => {
      if (sqIdx === 110 || sqIdx === 111) return;
      const f = sqIdx % FILES;
      const r = Math.floor(sqIdx / FILES);
      const base = (r + f) % 2 === 0 ? C.light : C.dark;
      const name = sqName(sqIdx);
      if (this._legalDests.includes(name)) {
        mesh.material.color.setHex(C.legal);
      }
    });
  }

  // ─── Tıklama ─────────────────────────────────────────────────────────────

  _onClick(event) {
    if (!this._renderer) return;

    const rect     = this._renderer.domElement.getBoundingClientRect();
    const ndcX     = ((event.clientX - rect.left)  / rect.width)  * 2 - 1;
    const ndcY     = -((event.clientY - rect.top) / rect.height) * 2 + 1;

    const raycaster = new THREE.Raycaster();
    raycaster.setFromCamera({ x: ndcX, y: ndcY }, this._camera);

    const targets = [...this._sqMeshes.values()];
    const hits    = raycaster.intersectObjects(targets, false);
    if (hits.length === 0) return;

    const sqIdx = hits[0].object.userData.sqIdx;
    const name  = sqName(sqIdx);

    this._handleSquareClick(name);
  }

  _handleSquareClick(name) {
    // Swap ikinci seçim
    if (this._swapPhase) {
      if (name !== this._swapFrom) {
        this._doMove(`swap:${this._swapFrom}${name}`);
      }
      this._swapPhase = false;
      this._swapFrom  = null;
      this._selected  = null;
      this._legalDests = [];
      this._updateSqColors();
      return;
    }

    // Hedef seçimi
    if (this._selected) {
      if (this._legalDests.includes(name)) {
        const from = this._selected;
        // Terfi kontrolü
        const needsPromo = this._legalMoves.some(m => m.startsWith(from + name + '='));
        if (needsPromo) {
          this._pendingMove = { from, to: name };
          this._showPromoModal(from, to);
          return;
        }
        this._doMove(from + name);
        this._selected   = null;
        this._legalDests = [];
        this._updateSqColors();
        return;
      }
    }

    // Kaynak seçimi
    const piece = this._pieces.find(p => sqName(p.sq) === name);
    if (piece) {
      this._selected   = name;
      this._legalDests = this._getLegalDestsFor(name);

      // Swap var mı?
      const swapMoves = this._legalMoves.filter(m => m.startsWith('swap:' + name));
      if (swapMoves.length > 0) {
        this._swapPhase = true;
        this._swapFrom  = name;
      }
    } else {
      this._selected   = null;
      this._legalDests = [];
    }

    this._updateSqColors();
    this._updateHighlights();
  }

  _getLegalDestsFor(from) {
    const dests = new Set();
    for (const m of this._legalMoves) {
      if (m.startsWith('swap:')) continue;
      if (m.startsWith(from) && m.length >= from.length + 2) {
        const rest = m.slice(from.length);
        const to   = rest.slice(0, rest.includes('=') ? rest.indexOf('=') : rest.length);
        if (to.length >= 2) dests.add(to);
      }
    }
    return [...dests];
  }

  _doMove(move) {
    if (this._onMove) {
      const parts = move.startsWith('swap:') ? [move.slice(5, 7), move.slice(7, 9)] : [move.slice(0, 2), move.slice(2, 4)];
      this._onMove(parts[0], parts[1], null, move);
    }
  }

  // ─── Terfi Modal ──────────────────────────────────────────────────────────

  _buildPromoModal() {
    const div = document.createElement('div');
    div.style.cssText = `
      display:none; position:absolute; top:50%; left:50%; transform:translate(-50%,-50%);
      background:#1a1a24; border:1px solid #2e2e42; border-radius:8px; padding:16px;
      z-index:50; text-align:center;
    `;
    div.innerHTML = `
      <div style="font-size:0.75rem;color:#8a8090;margin-bottom:8px;">Terfi — Taş Seç</div>
      <div id="b3d-promo-opts" style="display:flex;gap:8px;flex-wrap:wrap;justify-content:center"></div>
    `;
    return div;
  }

  _showPromoModal(from, to) {
    const optsEl = this._promoModal.querySelector('#b3d-promo-opts');
    optsEl.innerHTML = '';
    for (const pt of PROMO_PIECES) {
      const btn = document.createElement('button');
      btn.textContent = pt;
      btn.style.cssText = `
        background:#2e2e42; border:none; color:#e8e0d0; border-radius:4px;
        padding:8px 14px; font-size:1rem; cursor:pointer; font-weight:700;
      `;
      btn.addEventListener('click', () => {
        this._promoModal.style.display = 'none';
        if (this._pendingMove) {
          const { from: f, to: t } = this._pendingMove;
          this._pendingMove = null;
          this._doMove(f + t + '=' + pt);
        }
      });
      optsEl.appendChild(btn);
    }
    this._promoModal.style.display = 'block';
  }

  // ─── Orbit Kontrolü (basit fareyle döndürme) ─────────────────────────────

  _initOrbit() {
    // OrbitControls global varsa kullan, yoksa basit versiyon
    if (typeof THREE.OrbitControls !== 'undefined') {
      this._controls = new THREE.OrbitControls(this._camera, this._renderer.domElement);
      this._controls.enableDamping = true;
      this._controls.dampingFactor = 0.1;
      this._controls.maxPolarAngle = Math.PI / 2.2;
      return;
    }

    // Basit fare sürükleme
    let dragging = false, lastX = 0, lastY = 0;
    const el = this._renderer.domElement;

    el.addEventListener('mousedown', (e) => { dragging = true; lastX = e.clientX; lastY = e.clientY; });
    el.addEventListener('mouseup',   () => { dragging = false; });
    el.addEventListener('mousemove', (e) => {
      if (!dragging) return;
      const dx = (e.clientX - lastX) * 0.01;
      const dy = (e.clientY - lastY) * 0.005;
      lastX = e.clientX; lastY = e.clientY;

      // Kamerayı yatay eksen etrafında döndür
      const cx = (FILES * (SQ + GAP)) / 2 - SQ / 2;
      const cz = (RANKS * (SQ + GAP)) / 2 - SQ / 2;
      const offset = this._camera.position.clone().sub(new THREE.Vector3(cx, 0, cz));
      const spherical = new THREE.Spherical().setFromVector3(offset);
      spherical.theta -= dx;
      spherical.phi   = Math.max(0.3, Math.min(1.4, spherical.phi + dy));
      offset.setFromSpherical(spherical);
      this._camera.position.copy(offset.add(new THREE.Vector3(cx, 0, cz)));
      this._camera.lookAt(cx, 0, cz);
    });

    // Zoom (wheel)
    el.addEventListener('wheel', (e) => {
      const cx = (FILES * (SQ + GAP)) / 2 - SQ / 2;
      const cz = (RANKS * (SQ + GAP)) / 2 - SQ / 2;
      const dir = this._camera.position.clone().sub(new THREE.Vector3(cx, 0, cz)).normalize();
      const delta = e.deltaY > 0 ? 1 : -1;
      this._camera.position.addScaledVector(dir, delta * 0.8);
    }, { passive: true });
  }

  // ─── Render Döngüsü ───────────────────────────────────────────────────────

  _animate() {
    this._raf = requestAnimationFrame(() => this._animate());
    if (this._controls?.update) this._controls.update();

    // Taş hafif döndürme (animasyon)
    const t = performance.now() * 0.001;
    this._pieceMeshes.forEach((mesh, sqIdx) => {
      mesh.rotation.y = Math.sin(t + sqIdx * 0.1) * 0.03;
    });

    this._renderer.render(this._scene, this._camera);
  }

  _onResize() {
    const w = this._container.clientWidth  || 660;
    const h = this._container.clientHeight || 600;
    this._camera.aspect = w / h;
    this._camera.updateProjectionMatrix();
    this._renderer.setSize(w, h);
  }

  // ─── Fallback ────────────────────────────────────────────────────────────

  _fallbackMessage(container) {
    container.innerHTML = `
      <div style="display:flex;align-items:center;justify-content:center;
                  height:300px;color:#8a8090;font-size:0.9rem;flex-direction:column;gap:8px">
        <div>3D mod için Three.js gerekli.</div>
        <div style="font-size:0.75rem">CDN'den yükleyin veya 2D moda geçin.</div>
      </div>`;
  }
}
