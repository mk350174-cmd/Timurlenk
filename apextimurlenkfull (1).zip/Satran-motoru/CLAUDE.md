# Apex Timurlenk — Proje Bağlamı

## Proje

**Apex Timurlenk**, Timurlenk (Türk satranç varyantı) oyunu için C++20 ile yazılmış bir satranç motorudur. Standart satranç yerine 11×10 tahtada oynanır ve özgün taşlar ile kurallara sahiptir. UCI protokolünü destekler; Arena, Cute Chess gibi GUI'larla çalışır.

## Derleme

```bash
cmake -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j$(nproc)
```

Çıktı: `build/apex_timur`

## Hızlı Test

```bash
# UCI protokol testi
printf "uci\nisready\nd\neval\nquit\n" | ./build/apex_timur

# Hamle üreteci doğrulama (perft) — regresyon referans değerleri
printf "position startpos\nperft 1\nperft 2\nperft 3\nquit\n" | ./build/apex_timur
# Beklenen: perft(1)=53  perft(2)=2809  perft(3)=112479  perft(4)=4498340

# Arama testi
printf "position startpos\ngo depth 5\nquit\n" | ./build/apex_timur
```

## Dizin Yapısı

```
Satran-motoru/
├── CMakeLists.txt        # Derleme yapılandırması (C++20, -O3)
├── include/              # Başlık dosyaları
│   ├── types.h           # Temel tipler: Square, Piece, Move, MoveExt
│   ├── board.h           # Board sınıfı (mailbox + parça listesi)
│   ├── movegen.h         # MoveGenerator, MoveOrderer, MoveList
│   ├── search.h          # Searcher, TimeManager, SearchLimits, PVLine
│   ├── evaluate.h        # Evaluator, PST, KING_SAFETY_TABLE
│   ├── tt.h              # TranspositionTable, ZobristTable, PawnTable
│   └── uci.h             # UCI sınıfı, EngineOptions
└── src/                  # Kaynak dosyalar
    ├── main.cpp
    ├── board.cpp
    ├── movegen.cpp
    ├── search.cpp
    ├── evaluate.cpp
    ├── tt.cpp
    └── uci.cpp
```

## Tahta Düzeni

- **Normal kareler:** 112 kare dizisi (11 sütun × 10 satır = 110 + 2 citadel)
- **Sütunlar (file):** a–k (0–10)
- **Satırlar (rank):** 1–10 (iç temsil: 0–9)
- **Kare indeksi:** `sq = rank * 11 + file`
- **WHITE_CITADEL:** indeks 110 (k2'nin sağı)
- **BLACK_CITADEL:** indeks 111 (a9'un solu)

## Taş Tipleri (Timurlenk'e özgü)

| Sembol | Türkçe | Hareket |
|--------|--------|---------|
| K | Şah (SAH) | 8 yönde 1 kare + swap hakkı |
| R | Kale (KALE) | Yatay/dikey sınırsız |
| Z | Zürafa (ZURAFA) | Çapraz 1 + düz min 3 (gryphon) |
| T | Talia (TALIA) | Yatay/dikey tam 2 sıçrama |
| N | At (AT) | L şekli 2+1 |
| C | Deve (DEVE) | 3+1 atlama |
| E | Fil (FIL) | Çapraz tam 2 sıçrama |
| W | Savaş Makinesi (SAVAS) | Yatay/dikey tam 2 sıçrama |
| F | Ferz (FERZ) | Çapraz 1 kare |
| V | Vali (VALI) | Yatay/dikey 1 kare |
| P | Piyon (PIYON) | İleri 1 (çift adım yok) |

## Timurlenk'e Özgü Kurallar

- **Swap:** Her oyuncu oyun boyunca 1 kez, şahını herhangi kendi taşıyla yer değiştirebilir
- **Citadel:** Şah rakibin kalesine girerse oyun beraberlikle biter
- **Piyon terfisi:** Son sıraya ulaşınca şah hariç herhangi taşa terfi
- **Çift adım yok:** Piyonlar başlangıçta 2 adım atamazlar

## Arama Algoritması

- Iterative deepening + aspiration windows
- Alpha-beta negamax (fail-soft)
- Transposition table (64MB varsayılan)
- Null move pruning (NMP), LMR, Singular extensions
- Futility pruning, Razoring, Probcut
- Quiescence search (yemeler + terfi)

## UCI Komutları (özel)

```
d       → Tahtayı görsel göster
eval    → Statik değerlendirmeyi göster
moves   → Yasal hamleleri listele
perft N → Derinlik N'e kadar hamle sayısını doğrula
```

## Geliştirme Notları

- **Geometric NNUE (networks/apex_geometric_v1.bin):** version=2 formatında — C++ loader v0.5.0'da güncellendi (src/nnue.cpp:47).
- **NPS:** depth 4-7 arası ~65k (QSearch SEE pruning sonrası, v1.3.0). NNUE aktifken ~42k. Profil: `bash tools/profile_nps.sh`.
- **WebSocket köprüsü:** `bridge/engine_server.py` (Python 3.11+, `pip install websockets`). Max 4 bağlantı (EnginePool).
- **Açılış kitabı:** `OwnBook true` + `networks/timurlenk_openings.bin` gerekli. Üretmek için: `python3 tools/gen_opening_book.py --games 50`.
- **Öz-değerlendirme:** `bash scripts/self-eval.sh` — 10 kontrol, %90 hedef.

## Versiyon Geçmişi

| Versiyon | Tarih | Ana Değişiklik |
|----------|-------|----------------|
| v0.1.0 | - | Temel motor, Alpha-Beta, UCI |
| v0.2.0-persona | - | PersonaLayer L1.5 (Machiavelli/Nietzsche) |
| v0.3.0-search | 2026-05-16 | Hamle sıralama, FEN bağlantısı, Lazy SMP |
| v0.4.0-ws-bridge | 2026-05-20 | WebSocket köprüsü: bridge/ (Python asyncio + JS EngineClient) |
| v0.5.0-sprint1-3 | 2026-05-20 | NNUE v2 loader, zorluk routing, persona seçici, info HUD, swap UI, citadel draw, saat, MultiPV |
| v0.6.0-cpp-complete | 2026-05-20 | Persona weights (evaluate.cpp), citadel+Zobrist doğrulama, UCI wiring |
| v0.7.0-ui-complete | 2026-05-20 | Yakalanan taşlar, hamle replay, PV okları, ses efektleri, kaydet/yükle |
| v0.8.0-bridge-complete | 2026-05-20 | Analyze modu, sağlık izleyicisi, EnginePool, loadPosition, standalone EventBus |
| v1.0.0-platform | 2026-05-20 | Satrancı Rumi GDD + prototipi, açılış kitabı altyapısı, NPS profil, self-eval pipeline |
| v1.1.0-gm-sprint11-13 | 2026-05-27 | Shell injection fix, IIR+SEE futility, kral kalkan+fil çifti+kale açık dosya+geri piyon eval, move stability, GitHub Actions CI |
| v1.2.0-gm-sprint14 | 2026-05-27 | NNUE artımlı akümülatör (StateInfo cache+do_move delta), yakalama üretimi optimizasyonu, at/fil ileri karakol bonusu, NPS 47k→59k |
| v1.3.0-gm-sprint15-17 | 2026-05-27 | Capture history, CMH, açılış kitabı 200→300+ oyun, QSearch SEE pruning (NPS 59k→65k), NNUE fine-tune (loss 0.668→0.624), akümülatör root fix |

## Branch

Geliştirme branch: `claude/setup-system-from-zip-8fEhx`
