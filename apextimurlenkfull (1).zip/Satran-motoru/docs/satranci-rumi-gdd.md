# Satrancı Rumi — Oyun Tasarım Belgesi (GDD)

**Proje:** Apex Timurlenk Motor Eklentisi
**Versiyon:** v0.1.0
**Tarih:** 2026-05-20
**Durum:** Araştırma + Tasarım Aşaması

---

## 1. Tarihi Bağlam ve Kaynaklar

### 1.1 Belgelenmiş Tarihi

Satrancı Rumi, Anadolu'ya özgü bir satranç varyantıdır. "Rumi" terimi burada "Anadolu'ya ait" anlamını taşır — Mevlana Celaleddin Rumi ile doğrudan bir bağlantısı yoktur; Osmanlı döneminde Anadolu coğrafyasına "Rum" (Roma/Bizans toprakları) denirdi ve bu varyantın adı da o coğrafyadan gelir.

En önemli birincil kaynak **Firdevsî-i Rûmî'nin 1503 tarihli "Şatranç-nâme-i Kebîr"** (Büyük Satranç Kitabı) adlı eseridir. Uzun Firdevsî olarak da bilinen Şerefeddîn Mûsâ (1453–1517 sonrası) bu eseri Balıkesir'de kaleme almış ve Sultan II. Beyazıt'a sunmuştur.

Eser sekiz bölümden (Bâb) oluşur; Osmanlı Türkçesiyle yazılmış nazım-nesir karışımı bir yapıdadır. 83 satranç pozisyonu içerir: 6'sı Orta Doğu'da oynanan tarihi dizilişler (ta'biye), 77'si bilinen satranç bulmacalarının varyasyonlarıdır (Dilaram problemi dahil). Kaynak olarak 10. yüzyıl Arap satranç risalelerini (As-Suli'nin Kitāb al-Shiṭranj'ı, Al-Adli'nin çalışmaları) kullanmıştır.

El yazması nüshaları: Nuruosmaniye Kütüphanesi (İstanbul), Berlin Kütüphanesi, Münih Kütüphanesi.

Max Planck Bilim Tarihi Enstitüsü (MPIWG), bu eseri "Stratejik Zihinler, Zamansız Hamleler" başlıklı çalışmasıyla incelemiştir.

### 1.2 Osmanlı Sarayında Satranç

- **Fatih Sultan Mehmet:** Seferihisarlı İsmail Şaban'a "Şatranç-nâme-i Kebîr" yazdırdı.
- **II. Beyazıt:** Firdevsî-i Rûmî'nin eserini himaye etti.
- **Osmanlı — Timurlu bağı:** Osmanlı entelektüel çevreleri Timurlenk satrancını biliyordu; Satrancı Rumi bu iki geleneğin kesişim noktasında doğdu.

### 1.3 Kültürel Bağlam [Rekonstrüksiyon]

Satrancı Rumi, Şatrancı'nın (klasik İslam satrancı, 8×8) Anadolu yorumudur. Standart Şatrancı ile Timurlenk varyantı arasında bir köprü işlevi görür: Timurlenk'in büyük tahtasını değil, 8×8'i korur; ancak bazı Timurlenk taşlarını ve kurallarını özümser. "İstanbul Satrancı" olarak da anılır.

### 1.4 Kaynak Güvenilirlik Notu

| Kaynak | Güvenilirlik | Durum |
|--------|-------------|-------|
| Firdevsî-i Rûmî, Şatranç-nâme-i Kebîr (1503) | Yüksek — birincil kaynak | Belgelenmiş |
| birdemlik.com — Satranc-ı Rumi & İstanbul Satrancı | Orta — popüler kaynak | Kısmi |
| MPIWG akademik etkinlik kaydı | Yüksek — kurumsal | Belgelenmiş |
| Timurlenk satrancı — chessvariants.com, Wikipedia | Yüksek | Belgelenmiş |
| Taş hareketi detayları (bu GDD) | Düşük — çıkarımsal | [Rekonstrüksiyon] |

---

## 2. Tahta Boyutu ve Başlangıç Dizilişi

### 2.1 Tahta

**8×8, 64 kare.** Satrancı Rumi, Timurlenk'in 11×10 (112 kare) tahtasını kullanmaz. Standart Şatrancı tahtasını benimser.

- Sütunlar: a–h (0–7)
- Satırlar: 1–8 (iç temsil: 0–7)
- Kare indeksi: `sq = rank * 8 + file`
- **Citadel yok** (Timurlenk'e özgü; Rumi'de bulunmaz)

### 2.2 Başlangıç Dizilişi

Birincil kaynaklara göre Satrancı Rumi dizilişi [Rekonstrüksiyon]:

```
  a    b    c    d    e    f    g    h
8 [J] [S]  [A]  [V]  [Ş]  [A]  [S]  [J]   ← Siyah arka sıra
7 [P] [P]  [P]  [P]  [P]  [P]  [P]  [P]   ← Siyah piyonlar
6  .   .    .    .    .    .    .    .
5  .   .    .    .    .    .    .    .
4  .   .    .    .    .    .    .    .
3  .   .    .    .    .    .    .    .
2 [P] [P]  [P]  [P]  [P]  [P]  [P]  [P]   ← Beyaz piyonlar
1 [J] [S]  [A]  [V]  [Ş]  [A]  [S]  [J]   ← Beyaz arka sıra
```

**Taş kodları:**
- Ş = Şah (Shah / King) — d1/d8 veya e1/e8 [Rekonstrüksiyon]
- V = Vezir (Vizier) — Şah'ın yanı
- A = Âlim (Scholar / fil karşılığı, çapraz hareketi farklı)
- S = Sipahi (Knight / At)
- J = Ruh (Spirit / Kale karşılığı, "huruc" özel hamlesiyle)
- P = Piyon

**Not:** Firdevsî-i Rûmî metnine göre arka sıra: "Şah ve Vezir ortada, her iki yanda Âlim, Sipahi ve Ruh, köşelerde ise Casus." Bu tanımdan yukarıdaki diziliş çıkarılmıştır [Rekonstrüksiyon].

---

## 3. Taş Hareketleri

### 3.1 Taş Hareketi Tablosu

| Rumi Adı | Osmanlıca | Motor Sembolü | Hareket Tanımı | Timurlenk Karşılığı |
|----------|-----------|---------------|----------------|---------------------|
| Şah | شاه | K (SAH) | 8 yönde 1 kare | SAH (aynı) |
| Vezir | وزیر | Q (FERZ+) | Tüm yönlerde serbest | FERZ (Timurlenk'te zayıf; Rumi'de güçlü) [Rekonstrüksiyon] |
| Ruh | روح | R (KALE) | Yatay/dikey sınırsız | KALE (aynı) |
| Sipahi | سپاهی | N (AT) | L şekli 2+1 atlama | AT (aynı) |
| Âlim | عالم | B (FIL+) | Çapraz serbest | FIL (Timurlenk'te 2 kare sıçrama; Rumi'de serbest çapraz) [Rekonstrüksiyon] |
| Piyon | پیاده | P (PIYON) | İleri 1 (+2 ilk hamle), çapraz yeme | PIYON (farklı: ilk hamle 2 kare Rumi'de var) |

### 3.2 Hareket Notları

**Vezir (Q):** Firdevsî-i Rûmî "tüm yönlerde serbestçe hareket eder" der. Bu, modern satranç veziriyle örtüşür — Timurlenk'in FERZ'inden (yalnız çapraz 1 kare) daha güçlüdür. [Rekonstrüksiyon]

**Âlim (B):** Belgede "Alim/Bishop çapraz hareket eder" yazılıdır. Timurlenk'in FIL'i tam 2 kare sıçramak zorundayken, Rumi Âlim'i modern fil gibi serbest çapraz gidebilir. [Rekonstrüksiyon]

**Ruh (J → R):** "Huruc" (çıkış) hamlesiyle şahla yer değiştirir — rokaya karşılık gelir. Kale gibi hareket eder.

**Timurlenk'e özgü taşlar (ZURAFA, TALIA, DEVE, SAVAS, VALI) Rumi'de yoktur.** 8×8 tahta bu taşları barındırmaz.

---

## 4. Timurlenk'ten Farklı / Aynı Kurallar

### 4.1 Karşılaştırma Tablosu

| Kural | Timurlenk (11×10) | Satrancı Rumi (8×8) | Açıklama |
|-------|-------------------|---------------------|----------|
| Tahta | 11×10 + 2 citadel = 112 kare | 8×8 = 64 kare | Rumi standart tahtada |
| Şah swap | Var (1 kez, herhangi taşla) | Yok [Rekonstrüksiyon] | Küçük tahta gerektirmez |
| Citadel (kale girişi) | Var (beraberlik) | Yok | Citadel karesi olmadığından |
| Piyon ilk hamle | Yok (tek adım zorunlu) | Var (2 kare mümkün) | Birincil kaynak destekli |
| Piyon terfisi | Son sıraya ulaşınca (Şah hariç her taş) | Son sıraya ulaşınca Vezir olur | Kaynak: "Vezire dönüşür" |
| Rok (castling) | Yok | Var — "Huruc" adıyla | Ruh (Kale) + Şah yer değişimi |
| En passant | Yok | Belirsiz [Rekonstrüksiyon] | İlk hamle 2 kare varsa mantıklı |
| Stalematede | Kazanma (Timurlenk'te) | Beraberlik [Rekonstrüksiyon] | Modern kurala uyum için |
| Vezir gücü | Zayıf (yalnız çapraz 1 kare) | Güçlü (tüm yönler serbest) | Rumi modernleşmiş yapı |

### 4.2 Timurlenk'te Olup Rumi'de Olmayan Taşlar

| Taş | Sembol | Timurlenk Hareketi | Rumi'de Durum |
|-----|--------|--------------------|---------------|
| Zürafa | Z | Çapraz 1 + düz min 3 | Yok |
| Talia | T | Yatay/dikey tam 2 sıçrama | Yok |
| Deve | C | 3+1 atlama | Yok |
| Savaş Makinesi | W | Yatay/dikey tam 2 sıçrama | Yok |
| Ferz | F | Çapraz 1 kare | Rumi Veziri'ne evrilmiş (güçlü) |
| Vali | V | Yatay/dikey 1 kare | Yok |

---

## 5. Motor Implementasyon Notları

### 5.1 GameVariant Enum Değişikliği

```cpp
// include/types.h — mevcut yapıya ekleme
enum class GameVariant {
    TIMURLENK,   // Mevcut: 11×10, 112 kare
    RUMI         // Yeni: 8×8, 64 kare
};
```

### 5.2 Board Sınıfı Değişiklikleri

```cpp
// board.h — Board sınıfına variant parametresi
class Board {
    GameVariant variant;
    // Rumi: 8×8 = 64 kare dizisi
    // Timurlenk: 11×10+2 = 112 kare dizisi (mevcut)
};
```

**Kare indeksleme:**
- Timurlenk: `sq = rank * 11 + file` (file: 0–10, rank: 0–9)
- Rumi: `sq = rank * 8 + file` (file: 0–7, rank: 0–7)

### 5.3 Hamle Üreteci Değişiklikleri

Rumi varyantında devre dışı bırakılacak hamleler:
- `generateSwap()` — swap hamlesi yok
- `generateCitadel()` — citadel karesi yok
- `generateZurafa()`, `generateTalia()`, `generateDeve()`, `generateSavas()`, `generateFerz()`, `generateVali()` — bu taşlar yok

Eklenecek hamleler:
- `generateCastling()` — Huruc (rok) hamlesi
- `generateEnPassant()` — en passant (2 kare piyon varsa) [Rekonstrüksiyon]

### 5.4 Değiştirilecek Taş Hareketleri

```cpp
// Rumi'de FIL (fil) → serbest çapraz (modern bishop)
// Timurlenk'te: tam 2 kare çapraz sıçrama (atlamalı)
// Rumi'de: sınırsız çapraz (engel geçemez)

// Rumi'de FERZ → güçlü Vezir (modern queen)
// Timurlenk'te: yalnız çapraz 1 kare
// Rumi'de: tüm yönler serbest (kale + fil birleşimi)
```

### 5.5 Değerlendirme Fonksiyonu Ayarları

```cpp
// evaluate.h — Rumi için ayrı PST (Piece-Square Table)
// 8×8 board: farklı merkez ağırlığı
// Vezir Rumi'de çok güçlü → erken çıkış cezası artırılmalı
// Âlim (Bishop) çifti avantajı: standart çağdaş değer (0.5 puan)
```

### 5.6 UCI Protokol Genişletmesi

```
// Yeni UCI seçenek önerisi:
option name Variant type combo default Timurlenk var Timurlenk var Rumi
```

FEN formatı için Rumi başlangıç pozisyonu [Rekonstrüksiyon]:
```
j s a v s a s j / p p p p p p p p / 8 / 8 / 8 / 8 / P P P P P P P P / J S A V S A S J w - - 0 1
```
Not: Standart FEN harfleriyle çakışmamak için Rumi'ye özel taş sembolleri gerekli.

### 5.7 Perft Doğrulama Hedefleri

Timurlenk: perft(1)=53, perft(2)=2809 (mevcut doğrulanmış değerler)

Rumi için hedef perft değerleri [hesaplanmalı]:
- perft(1): yaklaşık 20 (8×8, 8 piyon × 1-2 hamle + diğer taşlar)
- perft(2): hesaplanacak
- Standart satranç perft(1)=20 referans alınabilir; Rumi farklı Vezir gücü nedeniyle sapabilir.

---

## 6. Timurlenk vs Rumi Karşılaştırma Tablosu

| Özellik | Timurlenk | Satrancı Rumi |
|---------|-----------|---------------|
| **Tahta** | 11×10 + 2 citadel | 8×8 |
| **Kare sayısı** | 112 | 64 |
| **Taş çeşidi** | 11 (K,R,Z,T,N,C,E,W,F,V,P) | 6 (K,Q,R,B,N,P) |
| **Piyon çeşidi** | 1 (tek adım) | 1 (ilk hamlede 2 kare) |
| **Vezir gücü** | Zayıf (Ferz, çapraz 1) | Güçlü (tüm yönler) |
| **Fil hareketi** | Tam 2 çapraz sıçrama | Serbest çapraz |
| **Swap** | Var | Yok |
| **Citadel** | Var | Yok |
| **Rok** | Yok | Var ("Huruc") |
| **Piyon terfisi** | Şah hariç her taş | Yalnız Vezir |
| **Stalematede** | Kazanma | Beraberlik |
| **Tarihsel dönem** | 14.-15. yy. Orta Asya | 15.-16. yy. Anadolu |
| **Birincil kaynak** | Timurlu el yazmaları | Firdevsî-i Rûmî (1503) |
| **Oyun süresi** | Uzun (derin strateji) | Orta (modern satranç benzeri) |
| **Motor zorluğu** | Yüksek (fazladan taşlar) | Orta (standart satranç + küçük farklar) |

---

## 7. Açık Sorular ve Belirsizlikler

Aşağıdaki maddeler [Rekonstrüksiyon] işaretlidir — kesin tarihi kaynak mevcut değildir:

1. **Diziliş:** Şah e1 mi d1 mi? Kaynak "ortada" der ama tam kare belirsiz.
2. **Âlim hareketi:** Tam olarak modern fil mi, yoksa sınırlı çapraz mı?
3. **En passant:** Piyon 2 kare yapabiliyorsa en passant mantıksal; tarihi onay yok.
4. **Stalematede sonuç:** Timurlenk kazanımdır, Rumi beraberlik varsayıldı (modern uyum).
5. **Swap:** Rumi'de olmadığı varsayılıyor — küçük tahta nedeniyle gereksiz; onay yok.
6. **Piyon terfisi genişliği:** Yalnız Vezir mü, yoksa tüm taşlar mı? Kaynak "Vezir olur" der.

---

## 8. Sonraki Adımlar

### Faz 1 — Kural Kesinleştirme (Sprint 9)
- [ ] Firdevsî-i Rûmî el yazması (Nuruosmaniye Kütüphanesi) dijital taramasına erişim araştır
- [ ] MPIWG akademik makalesini incele
- [ ] Açık soruların yanıtları için akademik danışma

### Faz 2 — Motor Entegrasyonu (Sprint 10-11)
- [ ] `GameVariant::RUMI` enum değeri ekle
- [ ] 8×8 Board yapısını implemente et
- [ ] Hamle üretecini Rumi varyantına uyarla (swap kaldır, rok ekle)
- [ ] Değerlendirme fonksiyonunu Rumi PST ile güncelle
- [ ] Perft testlerini yaz ve doğrula

### Faz 3 — Test ve Dengeleme (Sprint 12)
- [ ] Standart Şatrancı motorlarıyla (Fairy-Stockfish) test oyunları
- [ ] AI denge analizi: Vezir aşırı güçlü mü?
- [ ] UCI protokol entegrasyonu

---

## 9. Referanslar

1. Firdevsî-i Rûmî. *Şatranç-nâme-i Kebîr* (1503). Nuruosmaniye Kütüphanesi, İstanbul. — Birincil kaynak.
2. MPIWG. "Strategic Minds, Timeless Moves: Exploring Şatranç-nâme-i Kebîr." https://www.mpiwg-berlin.mpg.de/event/strategic-minds-timeless-moves-exploring-satranc-name-i-kebir-great-book-chess-1503-firdevsi
3. Wikipedia. "Tamerlane chess." https://en.wikipedia.org/wiki/Tamerlane_chess
4. The Chess Variant Pages. "Tamerlane Chess." https://www.chessvariants.com/historic.dir/tamerlane.html
5. Wikipedia. "Great chess (shatranj al-kabir)." https://en.wikipedia.org/wiki/Great_chess
6. Wikipedia. "Shatranj." https://en.wikipedia.org/wiki/Shatranj
7. Bir Demlik Vaktimiz Var. "Satranc-ı Rumi & İstanbul Satrancı." http://www.birdemlik.com/istanbul-satranci/
8. Atli Okculuk. "Osmanlı ve Selçuklu'da Satranç." http://www.atli-okculuk.com/2014/11/osmanl-ve-selcukluda-satranc.html

---

*Belgede [Rekonstrüksiyon] işareti: o bilgi kesin tarihi kaynaktan değil, dönem mantığı ve karşılaştırmalı analizden çıkarılmıştır.*
