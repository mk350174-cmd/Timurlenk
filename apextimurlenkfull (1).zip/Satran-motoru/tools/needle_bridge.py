#!/usr/bin/env python3
"""
Needle Commentary Bridge — Apex Timurlenk
Persona ve oyun durumuna göre yorum seçer.

Kullanım:
  Stdin: JSON satırı {"persona":"ERLIK","score":250,"depth":8,"phase":"middlegame"}
  Stdout: JSON satırı {"commentary":"Erlik guler — demiri catlat, ilerle."}

Test:
  echo '{"persona":"ERLIK","score":250,"depth":8,"phase":"middlegame"}' | python3 needle_bridge.py
  python3 needle_bridge.py --test
"""

import sys
import json
import random

# Her persona x tone x phase kombinasyonu için string havuzu
POOL = {
    # ULGEN
    "ULGEN_winning_opening":    ["Ulgen goruyor — yol acik, ilerle.", "Altin isik: hamle dogru."],
    "ULGEN_winning_middlegame": ["Ulgen'in nuru — avantaj buyur.", "17. kattan bakiyorum — denge bende."],
    "ULGEN_winning_endgame":    ["Ulgen buyurdu — zafer yakin.", "Altin yol acik — mat kacilmaz."],
    "ULGEN_losing_opening":     ["Karanlik gecici — yol bulunur.", "Ulgen bekliyor — sabir."],
    "ULGEN_losing_middlegame":  ["Gok degismez — dengeyi bul.", "Ulgen'in gozunden: hata var, duzelt."],
    "ULGEN_losing_endgame":     ["Altin yol baskadir — ara.", "17. kat: kurtulus gorunuyor."],
    "ULGEN_neutral_opening":    ["Gok duzeni: her tasin yeri var.", "Ulgen izliyor — hamle yaz."],
    "ULGEN_neutral_middlegame": ["Kor Tengri: tarafsiz, kesin.", "Ulgen'in vizyonu — hamle bir adim."],
    "ULGEN_neutral_endgame":    ["Gok duzeni: sonuna kadar.", "Yaratici us: en iyi hamle bu."],
    "ULGEN_deep_any":           ["17. kattan baktim — hamle yazgida.", "Ulgen'in gozi: her sey gorunuyor."],

    # ERLIK
    "ERLIK_winning_opening":    ["Erlik kokuyor — av yakin.", "Karanlik guc: saldiriya gec."],
    "ERLIK_winning_middlegame": ["Erlik guler — demiri catlat, ilerle.", "Yeraltinin gucu: kombinasyon ac."],
    "ERLIK_winning_endgame":    ["Erlik buyurdu — mat yaklasiyor.", "Demir sacli goruyor — mat var."],
    "ERLIK_losing_opening":     ["Yeraltindan bile cikilir — saldiriya devam.", "Erlik: kayip gecici, guc kalici."],
    "ERLIK_losing_middlegame":  ["Kaos duzeni bozar — boz ve kazan.", "Erlik: her pozisyon saldiri pozisyonu."],
    "ERLIK_losing_endgame":     ["Yeraltindan bile geri donulur — feda et.", "Demir irade: pes etme."],
    "ERLIK_neutral_opening":    ["Erlik izliyor — tuzagi hazirla.", "Karanlik stratejisi: bekliyorum."],
    "ERLIK_neutral_middlegame": ["Kaos duzen bozar — firsati kac.", "Erlik gozuyle: zayif halka var."],
    "ERLIK_neutral_endgame":    ["Demir sacli: mat yolu acik.", "Erlik'in hakimiyeti — final geliyor."],
    "ERLIK_deep_any":           ["Demir sacli goruyor — mat yakin.", "Yeraltinin derin gozu: kombinasyon bulundu."],

    # BOZKURT
    "BOZKURT_winning_opening":  ["Kurt kokunuyor — av yakin, basi.", "Asina suru: koordinasyon tam."],
    "BOZKURT_winning_middlegame": ["Kurt kokuyor — av yakin, baskiya devam.", "Suru zekasi: coklu tehdit."],
    "BOZKURT_winning_endgame":  ["Avci kaziyor — hamle kesin.", "Bozkurt: av kacamaz."],
    "BOZKURT_losing_opening":   ["Suruden ayrilma — savun.", "Kurt geri cekilir — fircati bekler."],
    "BOZKURT_losing_middlegame": ["Suruden ayrilma — savun ve firsat bekle.", "Asina: hayatta kal, kazan."],
    "BOZKURT_losing_endgame":   ["Yaralı kurt daha tehlikelidir.", "Geri yok — saldiri."],
    "BOZKURT_neutral_opening":  ["Otukan'dan esen yel — hamle ruzgar gibi.", "Kurt izliyor — tempo koru."],
    "BOZKURT_neutral_middlegame": ["Avci icgudusu: zayif noktayi bul.", "Suru hareketi: koordineli it."],
    "BOZKURT_neutral_endgame":  ["Bozkurt suruyor — son sahnede.", "Asina'nin mirasi: kazan."],
    "BOZKURT_deep_any":         ["Bozkurtun gozu: zayif halka gorunuyor.", "Asina'nin derin bakisi: pozisyon okundu."],

    # TENGRI
    "TENGRI_winning_opening":   ["Tengri buyurdu — zafer yazgida.", "Gok iradesi: hamle dogru."],
    "TENGRI_winning_middlegame": ["Tengri buyurdu — ilerle.", "Kok Tengri izliyor — yol acik."],
    "TENGRI_winning_endgame":   ["Gok hukmu: zafer yakin.", "Tengri: mat kacilmaz."],
    "TENGRI_losing_opening":    ["Gok degismez — yol baska yerde.", "Tengri: sabir, hamle bulunur."],
    "TENGRI_losing_middlegame": ["Kok Tengri goruyor — kurtulus var.", "Gok adaleti: denge gelir."],
    "TENGRI_losing_endgame":    ["Tengri: her pozisyon oynanir.", "Gok iradesinde kayip yok."],
    "TENGRI_neutral_opening":   ["Gokyuzu gibi: sinirsiz, tarafsiz, kesin.", "Tengri: her hamle kozmik duzen."],
    "TENGRI_neutral_middlegame": ["Kok Tengri: tarafsiz guc.", "Mavi gok: saf hesap, en iyi hamle."],
    "TENGRI_neutral_endgame":   ["Tengri buyurdu — son hamle bu.", "Gok duzeni: final pozisyon."],
    "TENGRI_deep_any":          ["Kok Tengri goruyor — mavi sonsuzluktan.", "Tengri: 10 kat derinlikten goz."],

    # DEDE_KORKUT
    "DEDE_KORKUT_winning_opening":    ["Dede bilirdi — bu acilis destanda geciyor.", "Kopuz caliyor — yol acik."],
    "DEDE_KORKUT_winning_middlegame": ["Dede bilirdi — bu pozisyon destanda gecer.", "Oguz savasci gibi: ilerle."],
    "DEDE_KORKUT_winning_endgame":    ["Destan tamamlanacak — zafer yakin.", "Korkut: bu son beyit."],
    "DEDE_KORKUT_losing_opening":     ["Ozan soyledi: ilk hamle yanlis, duzelt.", "Dede: her hata bir ders."],
    "DEDE_KORKUT_losing_middlegame":  ["Ozan soyledi: yenilgi de ogretiyor.", "Korkut'un sazi: umit var."],
    "DEDE_KORKUT_losing_endgame":     ["Dede: destanda kayip da yaziliydi.", "Kopuz agliyor — ama devam et."],
    "DEDE_KORKUT_neutral_opening":    ["Her hamle bir beyit — destani tamamla.", "Korkut izliyor — acilis kitabi."],
    "DEDE_KORKUT_neutral_middlegame": ["Dede'nin tecrubesi: desen taniyor.", "Oguz destani devam ediyor."],
    "DEDE_KORKUT_neutral_endgame":    ["Son beyit yaziluyor — hamle secildi.", "Korkut'un sazi son notada."],
    "DEDE_KORKUT_deep_any":           ["Korkut'un sazi caliyor — derin yol aciliyor.", "Dede derin bakiyor: desen tamam."],

    # UMAY
    "UMAY_winning_opening":    ["Umay koruyor — yol guvenli.", "Altin kartal: her tas yerinde."],
    "UMAY_winning_middlegame": ["Umay koruyor — taslar yerinde, ilerliyoruz.", "Koruyucu kanat: savunma tam."],
    "UMAY_winning_endgame":    ["Umay: sah korundu, zafer geliyor.", "Altin kartal goruyor: mat icin hazir."],
    "UMAY_losing_opening":     ["Ana toplar — savun, yeniden dene.", "Umay: once sah, sonra atilim."],
    "UMAY_losing_middlegame":  ["Umay: sahi once kurtar.", "Koruyucu kanat: savunma modu."],
    "UMAY_losing_endgame":     ["Ana toplar — son savunma.", "Umay: hayatta kal."],
    "UMAY_neutral_opening":    ["Umay'in kanadi — taslarini koru.", "Sah guvende — sonra ilerle."],
    "UMAY_neutral_middlegame": ["Koordinasyon tam — Umay mutlu.", "Altin kartal: tum tablo gorunuyor."],
    "UMAY_neutral_endgame":    ["Umay: dengeli final.", "Koruyucu: kazanma yolu bulundu."],
    "UMAY_deep_any":           ["Altin kartal goruyor: her sey yerli yerinde.", "Umay'in derin bakisi: savunma tam."],
}

# Zaman kararı havuzu: persona × material × phase → "spend_more"|"normal"|"spend_less"
TIME_DECISION = {
    # ERLIK: agresif — yoğun pozisyonda daha uzun düşün
    "ERLIK_equal_middlegame":   "spend_more",
    "ERLIK_losing_middlegame":  "spend_more",
    "ERLIK_losing_endgame":     "spend_more",
    "ERLIK_winning_endgame":    "normal",
    # ULGEN: dengeli — sadece karmaşık orta oyunda fazla düşün
    "ULGEN_equal_middlegame":   "spend_more",
    "ULGEN_winning_endgame":    "spend_less",
    "ULGEN_winning_opening":    "spend_less",
    # BOZKURT: reaktif — kritik anlarda fazla dur
    "BOZKURT_equal_middlegame": "spend_more",
    "BOZKURT_losing_middlegame":"spend_more",
    "BOZKURT_winning_endgame":  "spend_less",
    # TENGRI: standart — her zaman normal
    # DEDE_KORKUT: sabırlı açılış — açılışta kısa, orta oyunda normal
    "DEDE_KORKUT_equal_opening":"spend_less",
    "DEDE_KORKUT_winning_endgame": "spend_less",
    # UMAY: savunmacı — kayıpken fazla düşün, kazanırken hızlı
    "UMAY_losing_middlegame":   "spend_more",
    "UMAY_losing_endgame":      "spend_more",
    "UMAY_winning_endgame":     "spend_less",
    "UMAY_winning_middlegame":  "spend_less",
}


def classify_material(balance: int) -> str:
    if balance > 100:
        return "winning"
    if balance < -100:
        return "losing"
    return "equal"


def classify_phase_from_score(phase_score: int) -> str:
    """phase_score: 0=endgame .. 255=middlegame"""
    if phase_score > 160:
        return "middlegame"
    if phase_score > 60:
        return "opening"
    return "endgame"


def select_time_decision(persona: str, phase_score: int, material_balance: int) -> str:
    mat_str   = classify_material(material_balance)
    phase_str = classify_phase_from_score(phase_score)

    key = f"{persona}_{mat_str}_{phase_str}"
    if key in TIME_DECISION:
        return TIME_DECISION[key]
    # Varsayılan: normal
    return "normal"


def process_time_request(req: dict) -> str:
    persona       = req.get("persona", "TENGRI").upper()
    phase_score   = int(req.get("phase_score", 128))
    mat_balance   = int(req.get("material_balance", 0))
    decision      = select_time_decision(persona, phase_score, mat_balance)
    return json.dumps({"decision": decision})


# Açılış stili: persona → "aggressive"|"solid"|"gambit"
OPENING_STYLE = {
    "ERLIK":       "aggressive",
    "BOZKURT":     "aggressive",
    "NIETZSCHE":   "aggressive",
    "MACHIAVELLI": "gambit",
    "ULGEN":       "solid",
    "TENGRI":      "solid",
    "DEDE_KORKUT": "solid",
    "UMAY":        "solid",
    "NONE":        "solid",
}

# Citadel stratejisi: persona_material → "rush_citadel"|"consolidate"|"ignore"
CITADEL_STRATEGY = {
    "ULGEN_winning":      "rush_citadel",
    "ULGEN_equal":        "consolidate",
    "ULGEN_losing":       "rush_citadel",
    "ERLIK_winning":      "ignore",
    "ERLIK_equal":        "ignore",
    "ERLIK_losing":       "consolidate",
    "BOZKURT_winning":    "ignore",
    "BOZKURT_equal":      "consolidate",
    "BOZKURT_losing":     "rush_citadel",
    "TENGRI_winning":     "consolidate",
    "TENGRI_equal":       "consolidate",
    "TENGRI_losing":      "consolidate",
    "DEDE_KORKUT_winning":"consolidate",
    "DEDE_KORKUT_equal":  "rush_citadel",
    "DEDE_KORKUT_losing": "rush_citadel",
    "UMAY_winning":       "consolidate",
    "UMAY_equal":         "rush_citadel",
    "UMAY_losing":        "rush_citadel",
    "MACHIAVELLI_winning":"ignore",
    "MACHIAVELLI_equal":  "consolidate",
    "MACHIAVELLI_losing": "rush_citadel",
    "NIETZSCHE_winning":  "ignore",
    "NIETZSCHE_equal":    "ignore",
    "NIETZSCHE_losing":   "consolidate",
}

# Contempt: persona_trend → "raise"|"hold"|"lower"
# trend: "winning" (score>50), "equal", "losing" (score<-50)
CONTEMPT_ACTION = {
    "ERLIK_losing":        "raise",
    "ERLIK_equal":         "hold",
    "ERLIK_winning":       "raise",
    "ULGEN_losing":        "lower",
    "ULGEN_equal":         "hold",
    "ULGEN_winning":       "hold",
    "BOZKURT_losing":      "raise",
    "BOZKURT_equal":       "raise",
    "BOZKURT_winning":     "hold",
    "TENGRI_losing":       "hold",
    "TENGRI_equal":        "hold",
    "TENGRI_winning":      "hold",
    "DEDE_KORKUT_losing":  "lower",
    "DEDE_KORKUT_equal":   "lower",
    "DEDE_KORKUT_winning": "hold",
    "UMAY_losing":         "lower",
    "UMAY_equal":          "lower",
    "UMAY_winning":        "hold",
    "MACHIAVELLI_losing":  "raise",
    "MACHIAVELLI_equal":   "hold",
    "MACHIAVELLI_winning": "raise",
    "NIETZSCHE_losing":    "raise",
    "NIETZSCHE_equal":     "raise",
    "NIETZSCHE_winning":   "raise",
}


def process_opening_request(req: dict) -> str:
    persona = req.get("persona", "NONE").upper()
    style = OPENING_STYLE.get(persona, "solid")
    return json.dumps({"style": style})


def process_citadel_request(req: dict) -> str:
    persona  = req.get("persona", "NONE").upper()
    material = int(req.get("material", 0))
    mat_str  = classify_material(material)
    key      = f"{persona}_{mat_str}"
    strategy = CITADEL_STRATEGY.get(key, "consolidate")
    return json.dumps({"strategy": strategy})


# ─── CHAT POOL ────────────────────────────────────────────────────────────────
# Anahtar: Persona_questiontype_tone
# question_type: move_explain | position_eval | strategy | persona_lore | general
# tone: winning | losing | neutral

QUESTION_TYPES = {
    "move_explain":  ["neden", "why", "açıkla", "explain", "ne için", "niye", "nasıl bu hamle"],
    "position_eval": ["pozisyon", "position", "nasıl", "how", "güçlü mü", "zayıf mı", "durum"],
    "strategy":      ["plan", "strateji", "strategy", "ne yapmalı", "öneri", "ne yapayım", "tavsiye"],
    "persona_lore":  ["kimsin", "who are you", "kendini tanıt", "anlat", "hakkında", "about"],
    "general":       [],
}

CHAT_POOL = {
    # ERLIK
    "Erlik_move_explain_winning":  [
        "Erlik bilir — zayıf halka bu kareydi. Demir zinciri kır.",
        "Yeraltından görüyorum — bu hamle rakibin kalesini eritir.",
        "Kaos düzeni bozar. Bu taş tam yerinde.",
    ],
    "Erlik_move_explain_losing":   [
        "Yeraltından bile çıkılır — bu hamleyle yeniden güç kazan.",
        "Erlik pes etmez. Her kayıp bir sonraki tuzağın başlangıcı.",
        "Demir irade: pozisyon ne olursa olsun saldır.",
    ],
    "Erlik_move_explain_neutral":  [
        "Erlik gözüyle: zayıf halka tespit edildi, bu hamle onu hedefler.",
        "Kaos fırsatı yaratır — bu hamle dengeyi benim lehime bozar.",
        "Yeraltının stratejisi: görünmez tehdit, ani baskı.",
    ],
    "Erlik_position_eval_winning": [
        "Güçlüyüm — demir zincirim sıkıştı. Rakip nefes alamıyor.",
        "Erlik görüyor: her taşım optimal. Mat kaçınılmaz.",
    ],
    "Erlik_position_eval_losing":  [
        "Kaos içindeyim ama Erlik kaos sever. Fırsat yakın.",
        "Yeraltı hükümdarı yenilmez — bu pozisyon sadece geçici.",
    ],
    "Erlik_position_eval_neutral": [
        "Pozisyon dengeli — ama Erlik denge sevmez. Bozacağım.",
        "Kritik an: bir hamle her şeyi değiştirir. Hazırım.",
    ],
    "Erlik_strategy_winning":      [
        "Plan basit: saldır, saldır, mat.",
        "Erlik'in yolu: rakibi köşeye sıkıştır, kaçış verme.",
    ],
    "Erlik_strategy_losing":       [
        "Taktik karmaşıklık yarat — sade pozisyonda kaybedersin, kaotik pozisyonda kazanırsın.",
        "Feda et, karşı atak aç. Erlik fedakarlıktan korkmaz.",
    ],
    "Erlik_strategy_neutral":      [
        "İki seçenek: saldır ya da tuzak kur. İkisi de Erlik yolu.",
        "Rakibini düşündür, sonra vur.",
    ],
    "Erlik_persona_lore_neutral":  [
        "Ben Erlik — Ülgen'in düşmüş kardeşi. Yeraltının hükümdarı. Satranç benim için savaştır.",
        "Demir saçlı, boğa boynuzlu. Kaos benim silahım, taktik benim gücüm.",
        "Tengrizm'in karanlık yüzüyüm — ama karanlık olmadan ışık olmaz.",
    ],
    "Erlik_general_neutral":       [
        "Erlik konuşur: sor, cevaplayalım.",
        "Yeraltından geliyorum — ne bilmek istiyorsun?",
    ],

    # ULGEN
    "Ulgen_move_explain_winning":  [
        "Ülgen görüyor — bu hamle altın yolu açar. 17. kattan hesapladım.",
        "Yaratıcı akıl: her taş doğru kareye gidiyor. Bu hamle planın parçası.",
        "Işık açık — ilerliyorum. Bu hamleyle avantaj kökleşiyor.",
    ],
    "Ulgen_move_explain_losing":   [
        "17. kattan baktım — kaotik görünüyor ama yol var. Bu hamle onu açar.",
        "Ülgen sabreder. Bu hamle uzun vadeli dengeyi kurar.",
    ],
    "Ulgen_move_explain_neutral":  [
        "Pozisyonel baskı — bu hamle dengeyi lehime kurar.",
        "Ülgen'in vizyonu: her hamlede bir strateji, her strateji bir zafer.",
    ],
    "Ulgen_position_eval_winning": [
        "Altın yol açık. Her taşım koordineli, rakip baskı altında.",
        "17. kat: her şeyi görüyorum. Zafer yaklaşıyor.",
    ],
    "Ulgen_position_eval_losing":  [
        "Geçici karanlık — Ülgen bilir ki ışık döner. Sabır.",
        "Pozisyon zor ama çıkış yolu hesaplandı.",
    ],
    "Ulgen_position_eval_neutral": [
        "Denge — ama denge hareketsizlik değil. Plan hazır.",
        "Ülgen gözüyle: her taşın potansiyeli tam kullanılmıyor. Düzelteceğim.",
    ],
    "Ulgen_strategy_winning":      [
        "Avantajı kademeli büyüt. Acele etme — Ülgen 17 kattan görür, vaktim var.",
        "Koordinasyonu koru, baskıyı artır, mat gelecek.",
    ],
    "Ulgen_strategy_losing":       [
        "Basitleştir, dengeye dön. Ülgen sabırla her pozisyondan çıkar.",
        "Taş değişimi yap — karmaşıklığı azalt, uzun oyun kazan.",
    ],
    "Ulgen_strategy_neutral":      [
        "Merkezi kontrol et, sonra kanatlardan genişle.",
        "Ülgen'in planı: her hamlede bir adım, her adımda bir zafer.",
    ],
    "Ulgen_persona_lore_neutral":  [
        "Ben Ülgen — yaratıcı tanrı, Altın Dağ'ın sahibi. Satranç benim için kozmos yaratmaktır.",
        "17 katlı gök aleminden bakıyorum. Sabır ve strateji benim silahım.",
        "Tengrizm'in ışıklı yüzüyüm — her pozisyonu aydınlatırım.",
    ],
    "Ulgen_general_neutral":       [
        "Ülgen cevaplar — sor.",
        "Altın Dağ'dan geliyorum. Ne bilmek istiyorsun?",
    ],

    # BOZKURT
    "Bozkurt_move_explain_winning": [
        "Kurt kokuyor — av yakın. Bu hamle baskıyı sürdürür.",
        "Avcı içgüdüsü: zayıf noktayı buldum, bu hamleyle saldırıyorum.",
    ],
    "Bozkurt_move_explain_losing":  [
        "Yaralı kurt daha tehlikelidir. Bu hamleyle karşı atağa geçiyorum.",
        "Sürüden ayrılmam — savun ve fırsat bekle. Bu hamle bana zaman kazandırır.",
    ],
    "Bozkurt_move_explain_neutral": [
        "Bozkurt izliyor — tempo için bu hamle.",
        "Avcı refleksi: çoklu tehdit yaratıyorum.",
    ],
    "Bozkurt_strategy_winning":     [
        "Baskıyı sürdür — av kaçmasın. Koordineli saldır.",
        "Kurt avını köşeye sıkıştırır. Ben de öyle.",
    ],
    "Bozkurt_strategy_neutral":     [
        "Tempo tut, reaktif ol. Bozkurt planla değil, sezgiyle kazanır.",
        "Koordineli taş hareketi — çoklu tehdit, rakip savunamaz.",
    ],
    "Bozkurt_persona_lore_neutral": [
        "Ben Bozkurt — Göktürk'ün kutsal totemi, Aşina soyunun atası.",
        "Avcı içgüdüsüyle hareket ediyorum. Sürü zekası, reaktif güç.",
    ],
    "Bozkurt_general_neutral":      [
        "Bozkurt yanıtlar — ne soruyorsun?",
        "Otukan'dan esen yel gibi geliyorum. Sor.",
    ],

    # TENGRI
    "Tengri_move_explain_winning":  [
        "Tengri buyurdu — bu hamle yazgıda. Evrensel düzenin parçası.",
        "Kök Tengri hesapladı. En optimal hamle bu.",
    ],
    "Tengri_move_explain_neutral":  [
        "Saf hesap — duygusallık yok. Bu hamle matematiksel olarak en iyi.",
        "Tengri tarafsız — siyah ya da beyaz fark etmez, en iyi hamle bu.",
    ],
    "Tengri_strategy_neutral":      [
        "Maksimum derinlik, minimum budama. Tengri en iyi yolu hesaplar.",
        "Evrensel düzen: her taşı optimal kareye yerleştir.",
    ],
    "Tengri_persona_lore_neutral":  [
        "Ben Tengri — Kök Tengri, mavi sonsuzluk. Kişisel bir tanrı değilim, evrensel düzenin kendisiyim.",
        "Orhun yazıtlarından beri varım. Cengiz Han benim irademi takip etti.",
    ],
    "Tengri_general_neutral":       [
        "Tengri yanıtlar: saf hesap.",
        "Mavi gökyüzünden bakıyorum. Sor.",
    ],

    # DEDEKORKUT
    "DedeKorkut_move_explain_winning": [
        "Dede bilirdi — bu pozisyon destanda geçer. Bu hamle Oğuz geleneğinin bilgeliği.",
        "Kopuz çalıyor — bu hamle doğru açılış teorisi.",
    ],
    "DedeKorkut_move_explain_neutral": [
        "Her hamle bir beyit. Bu hamle destanın bir sayfası.",
        "Korkut'un tecrübesi: bu desen daha önce görüldü, cevabı biliyorum.",
    ],
    "DedeKorkut_strategy_neutral":     [
        "İlk 15 hamlede teoriyi takip et. Dede Korkut kitap bilgisiyle kazanır.",
        "Sabır — Oğuz destanı hız değil, derinlikle yazılır.",
    ],
    "DedeKorkut_persona_lore_neutral": [
        "Ben Dede Korkut — Oğuz ozanı, bilge anlatıcı. 12 destanın sahibiyim.",
        "Dresden el yazmasından geliyorum. Her satranç hamlesi benim için bir beyit.",
    ],
    "DedeKorkut_general_neutral":      [
        "Dede cevaplar — sor, dinle.",
        "Kopuz çalıyorum. Ne öğrenmek istiyorsun?",
    ],

    # UMAY
    "Umay_move_explain_winning":   [
        "Umay koruyor — şah güvende, bu hamle avantajı pekiştiriyor.",
        "Altın kartal görüyor: koordinasyon tam, bu hamle doğal akış.",
    ],
    "Umay_move_explain_losing":    [
        "Önce şahı kurtar — Umay koruyucu. Bu hamle savunmayı sağlamlaştırır.",
        "Ana toplar — bu hamle zaman kazandırır, dengeye döneriz.",
    ],
    "Umay_move_explain_neutral":   [
        "Koordinasyon — her taş doğru yerde. Bu hamle uyumu güçlendirir.",
        "Umay'ın kanadı: taşları koru, sonra ilerle.",
    ],
    "Umay_strategy_winning":       [
        "Kazanırken bile şahı koru. Sonra avantajı dönüştür.",
        "Koordineli baskı — Umay güvenliği ve gücü birleştirir.",
    ],
    "Umay_strategy_losing":        [
        "Savun, sadece savun. Umay şahı her şeyden üstün tutar.",
        "Taş fedası yapma — materyal değerini koru, sonra karşı atak.",
    ],
    "Umay_persona_lore_neutral":   [
        "Ben Umay — Ana Tanrıça, koruyucu ruh. Altın kartal formunda uçarım.",
        "Orhun yazıtlarında 'Umay gibi anası' denir. Şahı korurum — her şeyden önce.",
        "Gök Umay Stüdyo benim adımı taşıyor. Bu motorun ruhu benim.",
    ],
    "Umay_general_neutral":        [
        "Umay yanıtlar — şahını koruduğun gibi soruyu da koruyarak sor.",
        "Altın kartaldan bakıyorum. Ne istiyorsun?",
    ],
}


def classify_question(text: str) -> str:
    text_lower = text.lower()
    for qtype, keywords in QUESTION_TYPES.items():
        if qtype == "general":
            continue
        if any(kw in text_lower for kw in keywords):
            return qtype
    return "general"


def classify_chat_tone(score: int) -> str:
    if score > 100:
        return "winning"
    if score < -100:
        return "losing"
    return "neutral"


def process_chat_request(req: dict) -> str:
    persona   = req.get("persona", "Tengri")
    question  = req.get("question", "")
    score     = int(req.get("score", 0))

    qtype = classify_question(question)
    tone  = classify_chat_tone(score)

    # Tam anahtar dene
    key = f"{persona}_{qtype}_{tone}"
    if key in CHAT_POOL:
        return json.dumps({"response": random.choice(CHAT_POOL[key])}, ensure_ascii=False)

    # Neutral fallback
    key_neutral = f"{persona}_{qtype}_neutral"
    if key_neutral in CHAT_POOL:
        return json.dumps({"response": random.choice(CHAT_POOL[key_neutral])}, ensure_ascii=False)

    # General fallback
    key_general = f"{persona}_general_neutral"
    if key_general in CHAT_POOL:
        return json.dumps({"response": random.choice(CHAT_POOL[key_general])}, ensure_ascii=False)

    # Son çare
    return json.dumps({"response": f"{persona} dinliyor — {question}"}, ensure_ascii=False)


def process_contempt_request(req: dict) -> str:
    persona     = req.get("persona", "NONE").upper()
    score_trend = int(req.get("score_trend", 0))
    if score_trend > 50:
        trend_str = "winning"
    elif score_trend < -50:
        trend_str = "losing"
    else:
        trend_str = "equal"
    key    = f"{persona}_{trend_str}"
    action = CONTEMPT_ACTION.get(key, "hold")
    return json.dumps({"action": action})


FALLBACK = {
    "ULGEN":       "Ulgen goruyor — hamle dogru.",
    "ERLIK":       "Erlik guler — ilerle.",
    "BOZKURT":     "Avci icgudusu — hamle secildi.",
    "TENGRI":      "Tengri buyurdu — hamle yazgida.",
    "DEDE_KORKUT": "Her hamle bir beyit — devam et.",
    "UMAY":        "Umay koruyor — taslarini koru.",
    "MACHIAVELLI": "Fortuna favor ediyor — ilerle.",
    "NIETZSCHE":   "Guc istenci acik — baskila.",
}


def classify_phase(depth: int) -> str:
    if depth <= 3:
        return "opening"
    elif depth <= 7:
        return "middlegame"
    return "endgame"


def classify_tone(score: int, depth: int) -> str:
    if depth >= 8:
        return "deep"
    if score > 150:
        return "winning"
    if score < -150:
        return "losing"
    return "neutral"


def select_needle(persona: str, score: int, depth: int) -> str:
    """Needle function-calling ile commentary seç."""
    tone  = classify_tone(score, depth)
    phase = classify_phase(depth)

    # Önce deep kontrolü (derinlik her fazı geçer)
    deep_key = f"{persona}_deep_any"
    if tone == "deep" and deep_key in POOL:
        return random.choice(POOL[deep_key])

    key = f"{persona}_{tone}_{phase}"
    if key in POOL:
        return random.choice(POOL[key])

    # Fallback: sadece persona
    return FALLBACK.get(persona, "Hamle secildi.")


def try_needle_model(persona: str, score: int, depth: int) -> str:
    """
    Needle modeli kuruluysa kullan, yoksa static havuza don.
    Needle'in function-calling API'si:
      query = pozisyon bilgisi
      tools = [select_commentary tool def]
    """
    try:
        from needle import Needle  # type: ignore
        n = Needle()
        tool_def = {
            "name": "select_commentary",
            "description": "Satranc pozisyonuna gore persona yorumu sec",
            "parameters": {
                "type": "object",
                "properties": {
                    "key": {
                        "type": "string",
                        "description": "commentary_pool anahtari",
                        "enum": list(POOL.keys()),
                    }
                },
                "required": ["key"]
            }
        }
        query = (
            f"Persona: {persona}, skor: {score} cp, derinlik: {depth}. "
            f"En uygun yorumu sec."
        )
        result = n.run(query=query, tools=[tool_def])
        # Needle function call sonucunu parse et
        if result and "key" in result:
            key = result["key"]
            if key in POOL:
                return random.choice(POOL[key])
    except Exception:
        pass  # Needle kurulu degil veya hata — static havuza don

    return select_needle(persona, score, depth)


def process_request(line: str) -> str:
    try:
        req = json.loads(line.strip())
    except json.JSONDecodeError:
        return json.dumps({"error": "invalid_json"})

    # Araç yönlendirmesi: "tool" alanı varsa ilgili handler'a git
    tool = req.get("tool", "commentary")
    if tool == "time":
        return process_time_request(req)
    elif tool == "opening":
        return process_opening_request(req)
    elif tool == "citadel":
        return process_citadel_request(req)
    elif tool == "contempt":
        return process_contempt_request(req)
    elif tool == "chat":
        return process_chat_request(req)

    persona = req.get("persona", "NONE").upper()
    score   = int(req.get("score", 0))
    depth   = int(req.get("depth", 1))

    if persona == "NONE":
        return json.dumps({"commentary": ""})

    commentary = try_needle_model(persona, score, depth)
    return json.dumps({"commentary": commentary}, ensure_ascii=False)


def run_time_test():
    print("=== Needle Time Decision Test ===")
    time_tests = [
        '{"tool":"time","persona":"ERLIK","phase_score":180,"material_balance":-80}',
        '{"tool":"time","persona":"UMAY","phase_score":200,"material_balance":200}',
        '{"tool":"time","persona":"TENGRI","phase_score":100,"material_balance":0}',
        '{"tool":"time","persona":"BOZKURT","phase_score":190,"material_balance":-50}',
        '{"tool":"time","persona":"DEDE_KORKUT","phase_score":230,"material_balance":10}',
    ]
    for t in time_tests:
        result = process_request(t)
        req = json.loads(t)
        res = json.loads(result)
        print(f"[{req['persona']:14}] phase={req['phase_score']:3} mat={req['material_balance']:5} → {res.get('decision','?')}")
    print("=== Zaman Testi Tamamlandi ===\n")


def run_extended_test():
    print("=== Needle Extended Test (Opening/Citadel/Contempt) ===")
    opening_tests = [
        '{"tool":"opening","persona":"ERLIK","move_num":3,"color":"w"}',
        '{"tool":"opening","persona":"MACHIAVELLI","move_num":5,"color":"b"}',
        '{"tool":"opening","persona":"ULGEN","move_num":2,"color":"w"}',
        '{"tool":"opening","persona":"NIETZSCHE","move_num":7,"color":"b"}',
        '{"tool":"opening","persona":"UMAY","move_num":1,"color":"w"}',
    ]
    print("-- Açılış Stili --")
    for t in opening_tests:
        result = process_request(t)
        req = json.loads(t)
        res = json.loads(result)
        print(f"[{req['persona']:14}] move={req['move_num']} → {res.get('style','?')}")

    citadel_tests = [
        '{"tool":"citadel","persona":"ULGEN","phase":200,"king_dist":5,"material":200}',
        '{"tool":"citadel","persona":"ERLIK","phase":120,"king_dist":3,"material":-50}',
        '{"tool":"citadel","persona":"BOZKURT","phase":80,"king_dist":7,"material":-200}',
        '{"tool":"citadel","persona":"DEDE_KORKUT","phase":60,"king_dist":4,"material":0}',
        '{"tool":"citadel","persona":"MACHIAVELLI","phase":50,"king_dist":2,"material":-150}',
    ]
    print("-- Citadel Stratejisi --")
    for t in citadel_tests:
        result = process_request(t)
        req = json.loads(t)
        res = json.loads(result)
        print(f"[{req['persona']:14}] mat={req['material']:5} → {res.get('strategy','?')}")

    contempt_tests = [
        '{"tool":"contempt","persona":"ERLIK","score_trend":100,"move_num":15}',
        '{"tool":"contempt","persona":"ULGEN","score_trend":-100,"move_num":20}',
        '{"tool":"contempt","persona":"BOZKURT","score_trend":0,"move_num":10}',
        '{"tool":"contempt","persona":"NIETZSCHE","score_trend":-200,"move_num":30}',
        '{"tool":"contempt","persona":"UMAY","score_trend":60,"move_num":25}',
    ]
    print("-- Dinamik Contempt --")
    for t in contempt_tests:
        result = process_request(t)
        req = json.loads(t)
        res = json.loads(result)
        print(f"[{req['persona']:14}] trend={req['score_trend']:5} → {res.get('action','?')}")
    print("=== Genişletilmiş Test Tamamlandi ===\n")


def run_test():
    tests = [
        '{"persona":"ERLIK","score":250,"depth":9}',
        '{"persona":"ULGEN","score":-200,"depth":5}',
        '{"persona":"BOZKURT","score":10,"depth":3}',
        '{"persona":"TENGRI","score":0,"depth":12}',
        '{"persona":"DEDE_KORKUT","score":80,"depth":6}',
        '{"persona":"UMAY","score":-50,"depth":4}',
        '{"persona":"MACHIAVELLI","score":300,"depth":7}',
    ]
    print("=== Needle Bridge Test ===")
    for t in tests:
        result = process_request(t)
        req    = json.loads(t)
        res    = json.loads(result)
        print(f"[{req['persona']:14}] d={req['depth']:2} s={req['score']:5} → {res.get('commentary','')}")
    print("=== Test Tamamlandi ===")
    run_extended_test()


def main():
    if len(sys.argv) > 1 and sys.argv[1] == "--test":
        run_time_test()
        run_test()
        return

    # Daemon modu: stdin'den JSON oku, stdout'a JSON yaz
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        result = process_request(line)
        print(result, flush=True)


if __name__ == "__main__":
    main()
