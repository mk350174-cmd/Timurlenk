#!/usr/bin/env bash
# build_wasm.sh — Apex Timurlenk WebAssembly Derleme Scripti
#
# Gereksinim: Emscripten kurulu (source emsdk_env.sh)
#
# Kullanım:
#   bash tools/build_wasm.sh            # Release build
#   bash tools/build_wasm.sh --debug    # Debug build
#   bash tools/build_wasm.sh --test     # Native test (emscripten olmadan)

set -euo pipefail
cd "$(dirname "$0")/.."

OUTDIR="wasm"
mkdir -p "$OUTDIR"

# Kaynak dosyalar (main.cpp ve uci.cpp HARİÇ — WASM API ayrı)
SOURCES=(
    src/board.cpp
    src/movegen.cpp
    src/search.cpp
    src/evaluate.cpp
    src/tt.cpp
    src/nnue.cpp
    src/book.cpp
    src/persona.cpp
    src/commentary.cpp
    src/wasm_api.cpp
)

DEBUG="${1:-}"

if [[ "$DEBUG" == "--test" ]]; then
    # Native derleyici ile test (emscripten gerektirmez)
    echo "→ Native test build (debug semboller + WASM API)..."
    g++ -std=c++20 -O0 -g \
        -DWASM_API_TEST \
        -I include \
        "${SOURCES[@]}" \
        -o build/apex_wasm_test
    echo "✅ build/apex_wasm_test hazır"
    exit 0
fi

# Emscripten kontrolü
if ! command -v emcc &>/dev/null; then
    echo "❌ emcc bulunamadı. Emscripten'i kurun:"
    echo "   git clone https://github.com/emscripten-core/emsdk.git"
    echo "   cd emsdk && ./emsdk install latest && ./emsdk activate latest"
    echo "   source ./emsdk_env.sh"
    exit 1
fi

if [[ "$DEBUG" == "--debug" ]]; then
    OPT="-O1 -g"
    SUFFIX="_debug"
else
    OPT="-O3"
    SUFFIX=""
fi

EXPORTS='[\
"_engine_init",\
"_engine_new_game",\
"_engine_set_position",\
"_engine_do_moves",\
"_engine_best_move",\
"_engine_search_async",\
"_engine_get_last_info",\
"_engine_get_eval",\
"_engine_get_legal_moves",\
"_engine_get_fen",\
"_engine_get_board_json",\
"_engine_is_game_over",\
"_engine_get_side_to_move",\
"_engine_set_persona",\
"_engine_undo",\
"_engine_clear_tt"\
]'

OUTDIR_DIST="dist/engine"
mkdir -p "$OUTDIR_DIST"

echo "→ Emscripten WASM build ($OPT)..."
emcc $OPT -std=c++20 \
    -I include \
    "${SOURCES[@]}" \
    -o "${OUTDIR_DIST}/apex_timur${SUFFIX}.js" \
    -sEXPORTED_FUNCTIONS="$EXPORTS" \
    -sEXPORTED_RUNTIME_METHODS='["ccall","cwrap"]' \
    -sALLOW_MEMORY_GROWTH=1 \
    -sINITIAL_MEMORY=67108864 \
    -sMAXIMUM_MEMORY=536870912 \
    -sNO_EXIT_RUNTIME=1 \
    -sMODULARIZE=1 \
    -sEXPORT_NAME='ApexTimur' \
    -sENVIRONMENT='worker' \
    -sFILESYSTEM=0 \
    --no-entry

# Worker ve Bridge dosyalarını dist'e kopyala
cp wasm/ApexWorker.js  "${OUTDIR_DIST}/ApexWorker.js"
cp bridge/ApexBridge.js "${OUTDIR_DIST}/ApexBridge.js"

echo "✅ Çıktı:"
echo "   ${OUTDIR_DIST}/apex_timur${SUFFIX}.js   (JS yükleyici)"
echo "   ${OUTDIR_DIST}/apex_timur${SUFFIX}.wasm (binary)"
echo "   ${OUTDIR_DIST}/ApexWorker.js"
echo "   ${OUTDIR_DIST}/ApexBridge.js"
echo ""
echo "Kullanım:"
echo "  const engine = new ApexEngineWorker('/engine/apex_timur.js', '/engine/ApexWorker.js');"
echo "  await engine.init();"
echo "  const { move } = await engine.bestMove(8, 2000);"
