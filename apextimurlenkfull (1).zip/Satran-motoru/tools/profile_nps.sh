#!/bin/bash
# NPS profil testi — depth 1-7 için NPS ölç
# Kullanım: bash tools/profile_nps.sh [engine_yolu]
ENGINE=${1:-./build/apex_timur}

if [ ! -f "$ENGINE" ]; then
    echo "HATA: Motor bulunamadı: $ENGINE"
    echo "Derlemek için: cmake --build build -j\$(nproc)"
    exit 1
fi

echo "=== Apex Timurlenk NPS Profil Testi ==="
echo "Motor: $ENGINE"
echo "Tarih: $(date '+%Y-%m-%d %H:%M')"
echo ""
printf "%-10s | %-12s | %-10s | %-8s\n" "Derinlik" "NPS" "Düğümler" "Zaman"
echo "-----------|--------------|------------|----------"

for d in 1 2 3 4 5 6 7; do
    result=$(printf "position startpos\ngo depth %d\nquit\n" "$d" | "$ENGINE" 2>/dev/null | grep "^info depth ${d} " | tail -1)
    nps=$(echo "$result"   | grep -oP 'nps \K\d+')
    nodes=$(echo "$result" | grep -oP 'nodes \K\d+')
    time_ms=$(echo "$result" | grep -oP 'time \K\d+')
    printf "  %-8d | %-12s | %-10s | %-8s\n" \
        "$d" \
        "${nps:-N/A}" \
        "${nodes:-N/A}" \
        "${time_ms:+${time_ms}ms}"
done

echo ""
echo "Not: NPS hedefi depth 4+ için >50k (masaüstü), >15k (mobil/düşük güç)"
