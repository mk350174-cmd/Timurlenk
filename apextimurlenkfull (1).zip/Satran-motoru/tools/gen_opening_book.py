#!/usr/bin/env python3
"""
Apex Timurlenk Açılış Kitabı Üreteci
=====================================
Motoru kendi kendine oynatır, ilk N hamleyi kaydeder ve
APEX binary format v3 kitap dosyası üretir.

Kullanım:
    python3 tools/gen_opening_book.py \
        --engine build/apex_timur \
        --games  50 \
        --depth  4 \
        --plies  12 \
        --out    networks/timurlenk_openings.bin

Format (v3):
    magic[4]   = "APEX"
    version[4] = 3  (uint32_t, little-endian)
    count[4]   = N  (uint32_t, little-endian)
    Her kayıt (13 byte):
        hash[8]     uint64_t  — pozisyon hash (ply indeksi + hamle geçmişi)
        from_sq[1]  uint8_t   — kaynak kare (0-111)
        to_sq[1]    uint8_t   — hedef kare  (0-111)
        promo[1]    uint8_t   — terfi taşı (0=yok)
        pad[1]      uint8_t   — dolgu (0)
        weight[1]   uint8_t   — ağırlık (görülme sayısı, max 255)
"""

import argparse
import re
import struct
import subprocess
import random
from collections import defaultdict, Counter
from pathlib import Path

FILE_LETTERS = 'abcdefghijk'


def send(proc, cmd: str):
    """Motora UCI komutu gönder."""
    proc.stdin.write(cmd + '\n')
    proc.stdin.flush()


def until(proc, token: str) -> str:
    """Belirli token içeren satırı bekle, dön."""
    while True:
        line = proc.stdout.readline()
        if token in line:
            return line
        if not line:
            return ''


def run_game(engine_path: str, depth: int, max_plies: int) -> list[str]:
    """
    Bir self-play oyunu çalıştır.
    İlk max_plies hamleyi UCI move string listesi olarak döndür.
    Her hamlede derinliği ±1 ile rastgele çeşitlendir.
    """
    proc = subprocess.Popen(
        [engine_path],
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.DEVNULL,
        text=True,
        bufsize=1,
    )
    try:
        send(proc, 'uci')
        until(proc, 'uciok')
        send(proc, 'isready')
        until(proc, 'readyok')
        send(proc, 'ucinewgame')

        moves: list[str] = []

        for _ in range(max_plies):
            pos_cmd = 'position startpos'
            if moves:
                pos_cmd += ' moves ' + ' '.join(moves)
            send(proc, pos_cmd)

            d = max(1, depth + random.randint(-1, 1))
            send(proc, f'go depth {d}')

            bm_line = until(proc, 'bestmove')
            parts = bm_line.split()
            if len(parts) < 2 or parts[1] in ('(none)', '0000', ''):
                break
            moves.append(parts[1])

        send(proc, 'quit')
        proc.wait(timeout=5)
    except Exception:
        proc.kill()
    finally:
        try:
            proc.wait(timeout=2)
        except Exception:
            proc.kill()

    return moves


def uci_to_squares(move_str: str):
    """
    UCI hamle string'ini (from_sq, to_sq, promo) tuple'ına dönüştür.
    Geçersizse None döner.
    Swap hamlelerini "swap:XY" → (from_sq, to_sq, 0) olarak işler.
    """
    if not move_str or move_str in ('0000', '(none)'):
        return None

    # Swap hamlesi: "swap:f2b2" → iki kareyi parse et
    if move_str.startswith('swap:'):
        inner = move_str[5:]
        pattern = re.match(r'^([a-k])(\d+)([a-k])(\d+)$', inner)
        if not pattern:
            return None
        ff = FILE_LETTERS.index(pattern.group(1))
        fr = int(pattern.group(2)) - 1
        tf = FILE_LETTERS.index(pattern.group(3))
        tr = int(pattern.group(4)) - 1
        if not (0 <= ff <= 10 and 0 <= fr <= 9 and 0 <= tf <= 10 and 0 <= tr <= 9):
            return None
        return fr * 11 + ff, tr * 11 + tf, 0

    # Terfi: "b9b10=K"
    promo = 0
    m = move_str
    eq = m.find('=')
    if eq != -1:
        m = m[:eq]
        # promo taşı (şimdilik 0 bırak — kitapta promo nadirdir)
        promo = 1

    # Citadel hamlesi: "a9bc" veya "k2wc"
    if m.endswith('wc') or m.endswith('bc'):
        return None  # Citadel hamlelerini kitaba alma

    # Normal: harf + sayı + harf + sayı (rank 10 için 3 char to-parçası)
    pattern = re.match(r'^([a-k])(\d+)([a-k])(\d+)$', m)
    if not pattern:
        return None

    ff = FILE_LETTERS.index(pattern.group(1))
    fr = int(pattern.group(2)) - 1
    tf = FILE_LETTERS.index(pattern.group(3))
    tr = int(pattern.group(4)) - 1

    if not (0 <= ff <= 10 and 0 <= fr <= 9 and 0 <= tf <= 10 and 0 <= tr <= 9):
        return None

    from_sq = fr * 11 + ff
    to_sq   = tr * 11 + tf
    return from_sq, to_sq, promo


def get_position_hash(engine_path: str, moves: list[str]) -> int | None:
    """
    Motoru çalıştır, belirtilen hamle dizisini ayarla, Zobrist hash'i oku.
    Başarısızlıkta None döner.
    """
    pos_cmd = 'position startpos'
    if moves:
        pos_cmd += ' moves ' + ' '.join(moves)
    cmd = f'{pos_cmd}\nhash\nquit\n'
    try:
        result = subprocess.run(
            [engine_path],
            input=cmd,
            capture_output=True,
            text=True,
            timeout=5,
        )
        for line in result.stdout.splitlines():
            if line.startswith('hash '):
                return int(line.split()[1])
    except Exception:
        pass
    return None


def build(engine_path: str, games: int, depth: int, plies: int, out_path: str,
          min_count: int = 2):
    """
    Self-play oyunları yürüt, açılış istatistiklerini topla, kitap üret.

    Her ply için ayrı istatistik tutulur:
        stats[ply_index][(from_sq, to_sq, promo, hash)] = görülme_sayısı

    Zobrist hash UCI 'hash' komutuyla motordan alınır.
    """
    # stats[ply][(from_sq, to_sq, promo)] = (count, pos_hash)
    # pos_hash: tüm oyunlarda bu ply'daki hamle öncesi Zobrist hash
    # (aynı ply'da farklı hash'ler olabilir — en çok görüleni kullan)
    # Basitleştirme: ply + hamle tuple'ı başına hash kaydet, çoğunluğu al
    # stats[ply][(from_sq, to_sq, promo)] = Counter({hash: count})
    stats: dict[int, dict[tuple, Counter]] = defaultdict(lambda: defaultdict(Counter))

    # Tüm oyunlardaki pozisyon hash'lerini topla
    # Verimlilik: her oyun zaten motor çağrısı yapıyor.
    # Hash'leri ayrı bir geçişte toplamak yerine run_game'i genişletebiliriz,
    # ancak arayüzü değiştirmemek için ayrı bir geçiş yapıyoruz.
    all_games: list[list[str]] = []

    for i in range(games):
        print(f'\rOyun {i + 1}/{games}...', end='', flush=True)
        game_moves = run_game(engine_path, depth, plies)
        all_games.append(game_moves)

    print()

    # Hash'leri toplu hesapla
    print('Pozisyon hash\'leri hesaplanıyor...')
    hash_cache: dict[tuple, int] = {}  # (moves_tuple) → hash

    for game_moves in all_games:
        for ply, mv in enumerate(game_moves):
            sq = uci_to_squares(mv)
            if sq is None:
                continue
            prefix = tuple(game_moves[:ply])
            if prefix not in hash_cache:
                h = get_position_hash(engine_path, list(prefix))
                if h is None:
                    continue
                hash_cache[prefix] = h
            pos_hash = hash_cache[prefix]
            stats[ply][sq][pos_hash] += 1

    entries: list[bytes] = []

    for ply, move_counts in stats.items():
        for (from_sq, to_sq, promo), hash_counter in move_counts.items():
            total = sum(hash_counter.values())
            if total < min_count:
                continue
            weight = min(255, total)
            # En sık görülen hash'i kullan (majority vote)
            pos_hash = hash_counter.most_common(1)[0][0]
            entry = struct.pack('<QBBBxB',
                                pos_hash,
                                from_sq,
                                to_sq,
                                promo,
                                weight)
            entries.append(entry)

    Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    with open(out_path, 'wb') as f:
        f.write(b'APEX')
        f.write(struct.pack('<II', 3, len(entries)))
        for e in entries:
            f.write(e)

    print(f'{len(entries)} pozisyon kaydedildi → {out_path}')
    if len(entries) == 0:
        print('Uyarı: Kitap boş. --games veya --depth artırın, '
              'ya da --min-count 1 deneyin.')


if __name__ == '__main__':
    ap = argparse.ArgumentParser(
        description='Apex Timurlenk açılış kitabı üreteci'
    )
    ap.add_argument('--engine',    default='build/apex_timur',
                    help='Motor yolu')
    ap.add_argument('--games',     type=int, default=20,
                    help='Self-play oyun sayısı (varsayılan: 20)')
    ap.add_argument('--depth',     type=int, default=4,
                    help='Arama derinliği (varsayılan: 4)')
    ap.add_argument('--plies',     type=int, default=10,
                    help='Kaydedilecek açılış hamle sayısı (varsayılan: 10)')
    ap.add_argument('--out',       default='networks/timurlenk_openings.bin',
                    help='Çıktı dosyası')
    ap.add_argument('--min-count', type=int, default=2,
                    help='Minimum görülme sayısı (varsayılan: 2)')
    a = ap.parse_args()

    build(a.engine, a.games, a.depth, a.plies, a.out, a.min_count)
