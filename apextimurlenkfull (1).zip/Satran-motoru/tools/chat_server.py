#!/usr/bin/env python3
"""
chat_server.py — Apex Timurlenk Persona Chat Sunucusu
stdlib HTTP sunucusu, sıfır dış bağımlılık.

POST /chat    → Persona chat yanıtı
GET  /persona → Persona matrisi (persona_data.json)
GET  /health  → {"status":"ok","version":"0.6.0"}

Başlatma: python3 tools/chat_server.py [port]
Varsayılan port: 8765
"""

import sys
import json
import os
from http.server import BaseHTTPRequestHandler, HTTPServer

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import needle_bridge  # type: ignore

_PERSONA_DATA_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "persona_data.json")


def _load_persona_data() -> dict:
    try:
        with open(_PERSONA_DATA_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        pass  # sessiz

    def _send(self, status: int, body: dict | str, content_type: str = "application/json"):
        if isinstance(body, dict):
            data = json.dumps(body, ensure_ascii=False).encode("utf-8")
        else:
            data = body.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", content_type + "; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(data)

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    def do_GET(self):
        if self.path == "/health":
            self._send(200, {"status": "ok", "version": "0.6.0"})
        elif self.path == "/persona":
            data = _load_persona_data()
            self._send(200, data)
        else:
            self._send(404, {"error": "not_found"})

    def do_POST(self):
        if self.path != "/chat":
            self._send(404, {"error": "not_found"})
            return

        length = int(self.headers.get("Content-Length", 0))
        if length == 0:
            self._send(400, {"error": "empty_body"})
            return

        raw = self.rfile.read(length)
        try:
            req = json.loads(raw.decode("utf-8"))
        except json.JSONDecodeError:
            self._send(400, {"error": "invalid_json"})
            return

        req["tool"] = "chat"
        result_str = needle_bridge.process_request(json.dumps(req))
        try:
            result = json.loads(result_str)
        except Exception:
            result = {"response": result_str}

        self._send(200, result)


def run(port: int = 8765):
    server = HTTPServer(("", port), Handler)
    print(f"[chat_server] Port {port} — http://localhost:{port}/health", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    server.server_close()


if __name__ == "__main__":
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8765
    run(port)
