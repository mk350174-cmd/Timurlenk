#!/usr/bin/env python3
"""
gauntlet.py — NNUE vs HCE gauntlet testi

Apex Timurlenk'te NNUE açık (Engine A) vs HCE kapalı (Engine B) karşılaştırması.
Her pozisyon iki kez oynanır (renk değişimi) — taraflılığı ortadan kaldırır.

Kullanım:
  python3 tools/gauntlet.py --engine build/apex_timur \
      --nnue-model networks/apex_v2.bin \
      --games 20 --depth 4
"""

import argparse
import subprocess
import random
import sys
import time

OPENING_POOL = [
    ["c1d4"], ["i1h4"], ["j1i3"],
    ["a2a4"], ["b2b4"], ["k2k4"],
    ["d2d4"], ["e2e4"], ["g2g4"],
    ["c1d4", "c10d7"], ["i1h4", "i10h7"],
    ["a2a4", "a9a6"], ["d2d4", "d9d6"],
    ["j1i3", "j10i8"], ["k2k4", "a9a6"],
]


def parse_args():
    ap = argparse.ArgumentParser()
    ap.add_argument("--engine", default="build/apex_timur")
    ap.add_argument("--nnue-model", default="networks/apex_v2.bin")
    ap.add_argument("--games", type=int, default=20)
    ap.add_argument("--depth", type=int, default=4)
    ap.add_argument("--max-moves", type=int, default=80)
    return ap.parse_args()


class Engine:
    def __init__(self, path: str, use_nnue: bool, nnue_path: str = ""):
        self.name = "NNUE" if use_nnue else "HCE"
        self.proc = subprocess.Popen(
            [path],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
            bufsize=1,
        )
        self._send("uci")
        self._wait("uciok")
        if use_nnue and nnue_path:
            self._send("setoption name UseNNUE value true")
            self._send(f"setoption name NNUEPath value {nnue_path}")
        else:
            self._send("setoption name UseNNUE value false")
        self._send("isready")
        self._wait("readyok")

    def _send(self, cmd: str):
        self.proc.stdin.write(cmd + "\n")
        self.proc.stdin.flush()

    def _wait(self, token: str, timeout: float = 5.0) -> list:
        lines = []
        deadline = time.time() + timeout
        while time.time() < deadline:
            line = self.proc.stdout.readline().strip()
            if line:
                lines.append(line)
            if token in line:
                return lines
        return lines

    def get_move(self, moves: list, depth: int) -> tuple:
        """Hamle ve skor döndür. (bestmove, score_cp)"""
        pos = "startpos" + (f" moves {' '.join(moves)}" if moves else "")
        self._send(f"position {pos}")
        self._send(f"go depth {depth}")
        best = None
        score = None
        while True:
            line = self.proc.stdout.readline().strip()
            if line.startswith("info depth"):
                parts = line.split()
                try:
                    sc_idx = parts.index("score")
                    if parts[sc_idx + 1] == "cp":
                        score = int(parts[sc_idx + 2])
                except (ValueError, IndexError):
                    pass
            elif line.startswith("bestmove"):
                parts = line.split()
                best = parts[1] if len(parts) > 1 else None
                break
        return best, score

    def quit(self):
        try:
            self._send("quit")
            self.proc.wait(timeout=2)
        except Exception:
            self.proc.kill()


def play_game(eng_white: Engine, eng_black: Engine, opening: list, depth: int, max_moves: int):
    """
    Bir oyun oyna.
    Dönüş: 1 (beyaz kazandı), -1 (siyah kazandı), 0 (beraberlik)
    """
    ADJ_THRESHOLD = 400
    ADJ_CONSEC = 3
    moves = list(opening)
    consec = 0
    adj_sign = 0

    for move_num in range(max_moves):
        is_white_turn = (move_num % 2 == 0)
        eng = eng_white if is_white_turn else eng_black
        best, score = eng.get_move(moves, depth)

        if best is None or best == "0000":
            # Mat veya tıkanma
            if is_white_turn:
                return -1  # Beyaz tıkandı → siyah kazandı
            else:
                return 1   # Siyah tıkandı → beyaz kazandı

        moves.append(best)

        if score is not None:
            side_mul = 1 if is_white_turn else -1
            score_white = score * side_mul
            if abs(score_white) >= ADJ_THRESHOLD:
                sign = 1 if score_white > 0 else -1
                if sign == adj_sign:
                    consec += 1
                else:
                    consec = 1
                    adj_sign = sign
                if consec >= ADJ_CONSEC:
                    return adj_sign
            else:
                consec = 0
                adj_sign = 0

    # Zaman doldu → son skora göre karar
    if score is not None:
        if score_white > 200:
            return 1
        elif score_white < -200:
            return -1
    return 0


def main():
    args = parse_args()

    print("════════════════════════════════════════════════")
    print("Apex Timurlenk — Gauntlet: NNUE vs HCE")
    print(f"Model: {args.nnue_model}")
    print(f"Derinlik: {args.depth}  |  Oyun: {args.games}×2 (renk değişimi)")
    print("════════════════════════════════════════════════")

    # Sonuçlar
    nnue_score = 0.0  # NNUE kazancı
    hce_score = 0.0   # HCE kazancı
    results = []      # Her oyun sonucu

    game_num = 0
    openings = random.sample(OPENING_POOL * 4, min(args.games, len(OPENING_POOL) * 4))

    for i in range(0, args.games * 2, 2):
        game_num += 1
        opening = openings[i % len(openings)]

        # Oyun 1: NNUE=Beyaz, HCE=Siyah
        eng_nnue = Engine(args.engine, True, args.nnue_model)
        eng_hce  = Engine(args.engine, False)
        result1 = play_game(eng_nnue, eng_hce, opening, args.depth, args.max_moves)
        eng_nnue.quit()
        eng_hce.quit()

        # Oyun 2: HCE=Beyaz, NNUE=Siyah
        eng_hce2  = Engine(args.engine, False)
        eng_nnue2 = Engine(args.engine, True, args.nnue_model)
        result2_raw = play_game(eng_hce2, eng_nnue2, opening, args.depth, args.max_moves)
        eng_hce2.quit()
        eng_nnue2.quit()
        # result2_raw: 1=HCE kazandı, -1=NNUE kazandı, 0=beraberlik
        # NNUE perspektifinden çevir:
        result2 = -result2_raw  # Siyah NNUE → 1 = NNUE kazandı

        # Puan hesapla
        for res in [result1, result2]:
            if res == 1:    # NNUE kazandı
                nnue_score += 1.0
            elif res == -1: # HCE kazandı
                hce_score += 1.0
            else:           # Beraberlik
                nnue_score += 0.5
                hce_score += 0.5

        results.append((result1, result2))
        total_games = game_num * 2
        print(f"  Çift {game_num:2d}: "
              f"{'NNUE ✓' if result1==1 else 'HCE ✓' if result1==-1 else '='} / "
              f"{'NNUE ✓' if result2==1 else 'HCE ✓' if result2==-1 else '='}  │  "
              f"NNUE {nnue_score:.1f}/{total_games} ({nnue_score/total_games*100:.0f}%)")
        sys.stdout.flush()

    total = args.games * 2
    print()
    print("════════════════════════════════════════════════")
    print(f"SONUÇ ({total} oyun):")
    print(f"  NNUE: {nnue_score:.1f}  ({nnue_score/total*100:.1f}%)")
    print(f"  HCE:  {hce_score:.1f}  ({hce_score/total*100:.1f}%)")
    if nnue_score > hce_score:
        print("  → NNUE daha güçlü ✓")
    elif hce_score > nnue_score:
        print("  → HCE daha güçlü (NNUE kalibrasyonu gerekli)")
    else:
        print("  → Eşit (daha fazla oyun gerekli)")
    print("════════════════════════════════════════════════")


if __name__ == "__main__":
    main()
