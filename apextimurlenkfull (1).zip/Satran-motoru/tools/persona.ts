/**
 * persona.ts — Apex Timurlenk Persona Sistemi (TypeScript)
 * C++ PersonaLayer enum'unun TypeScript yansıması.
 * persona_data.json tek kaynak gerçektir.
 */

import personaData from './persona_data.json'

export type PersonaName =
  | 'Erlik'
  | 'Ulgen'
  | 'Bozkurt'
  | 'Tengri'
  | 'DedeKorkut'
  | 'Umay'

export interface PersonaConfig {
  contempt: number
  aspiration_delta: number
  psyche_default: number
  opening_style: 'aggressive' | 'solid' | 'gambit'
  archetype: string
  traits: string[]
  colors: [string, string]
  chat_voice: string
}

export const PERSONA_MATRIX: Record<PersonaName, PersonaConfig> =
  personaData.personas as Record<PersonaName, PersonaConfig>

export const PERSONA_NAMES: PersonaName[] = Object.keys(
  PERSONA_MATRIX
) as PersonaName[]

export interface GameState {
  score: number
  depth: number
  phase: 'opening' | 'middlegame' | 'endgame'
  moveNum?: number
}

export interface ChatRequest {
  tool: 'chat'
  persona: PersonaName
  question: string
  score: number
  depth?: number
}

export interface ChatResponse {
  response: string
}

export interface PersonaEndpointResponse {
  version: string
  personas: Record<PersonaName, PersonaConfig>
}

export function buildChatRequest(
  persona: PersonaName,
  question: string,
  state?: GameState
): ChatRequest {
  return {
    tool: 'chat',
    persona,
    question,
    score: state?.score ?? 0,
    depth: state?.depth,
  }
}

export function getPersonaColors(persona: PersonaName): [string, string] {
  return PERSONA_MATRIX[persona]?.colors ?? ['#1a1a2e', '#c8960c']
}

export function getPersonaTraits(persona: PersonaName): string[] {
  return PERSONA_MATRIX[persona]?.traits ?? []
}
