#!/usr/bin/env python3
"""
generate_selfplay.py — Apex Timurlenk self-play veri üretici

Motor iki taraf için de oynatır, her pozisyonu FEN + statik eval ile kaydeder.
Çıktı: data/selfplay_YYYYMMDD_HHMMSS.jsonl

Kullanım:
  python3 tools/generate_selfplay.py --engine build/apex_timur --games 100 --depth 6
"""

import argparse
import subprocess
import json
import random
import sys
import time
from datetime import datetime
from pathlib import Path

# Timurlenk başlangıç açılış hamleleri — çeşitlilik için rastgele seçilir
OPENING_POOL = [
    ["c1d4"],          # Deve açılışı
    ["c1d4", "c10d7"],
    ["c1b3"],
    ["i1h4"],          # At açılışı
    ["i1h4", "i10h7"],
    ["j1i3"],
    ["a2a4"],          # Piyon açılışları
    ["b2b4"],
    ["k2k4"],
    ["a2a4", "a9a6"],
    ["b2b4", "b9b6"],
    ["d2d4"],
    ["e2e4"],
    ["g2g4"],
    ["c1d4", "i10h7"],
    ["i1h4", "c10d7"],
    ["j1i3", "j10i8"],
    ["a2a4", "k9k6"],
    ["k2k4", "a9a6"],
    ["d2d4", "d9d6"],
]


def parse_args():
    ap = argparse.ArgumentParser()
    ap.add_argument("--engine", default="build/apex_timur")
    ap.add_argument("--games", type=int, default=50, help="Oyun sayısı")
    ap.add_argument("--depth", type=int, default=5, help="Arama derinliği")
    ap.add_argument("--output-dir", default="data", help="Çıktı dizini")
    ap.add_argument("--min-move", type=int, default=5, help="Kayıt başlangıç hamlesi")
    ap.add_argument("--max-move", type=int, default=80, help="Maksimum hamle sayısı")
    return ap.parse_args()


class EngineProcess:
    def __init__(self, engine_path: str):
        self.proc = subprocess.Popen(
            [engine_path],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
            bufsize=1,
        )
        self._send("uci")
        self._wait_for("uciok")
        self._send("isready")
        self._wait_for("readyok")

    def _send(self, cmd: str):
        self.proc.stdin.write(cmd + "\n")
        self.proc.stdin.flush()

    def _wait_for(self, token: str, timeout: float = 5.0) -> list[str]:
        lines = []
        deadline = time.time() + timeout
        while time.time() < deadline:
            line = self.proc.stdout.readline().strip()
            if line:
                lines.append(line)
            if token in line:
                return lines
        return lines

    def new_game(self):
        self._send("ucinewgame")
        self._send("isready")
        self._wait_for("readyok")

    def set_position(self, moves: list[str]):
        if moves:
            self._send("position startpos moves " + " ".join(moves))
        else:
            self._send("position startpos")

    def get_eval(self) -> int | None:
        """Statik eval al (eval komutu)."""
        self._send("eval")
        lines = self._wait_for("Değerlendirme", timeout=2.0)
        for line in lines:
            if "Değerlendirme:" in line:
                # "info string Değerlendirme: 42 cp ..."
                parts = line.split()
                for i, p in enumerate(parts):
                    if p == "Değerlendirme:" and i + 1 < len(parts):
                        try:
                            return int(parts[i + 1])
                        except ValueError:
                            return None
        return None

    def go_depth(self, depth: int) -> str | None:
        """En iyi hamleyi döndür."""
        self._send(f"go depth {depth}")
        lines = self._wait_for("bestmove", timeout=30.0)
        for line in lines:
            if line.startswith("bestmove"):
                parts = line.split()
                if len(parts) >= 2 and parts[1] != "0000":
                    return parts[1]
        return None

    def get_fen(self) -> str | None:
        """Mevcut pozisyonu FEN olarak al (d komutu)."""
        self._send("d")
        lines = self._wait_for("Şah kontrolü", timeout=2.0)
        for line in lines:
            if line.startswith("FEN:") or "FEN:" in line:
                return line.split("FEN:")[-1].strip()
        return None

    def get_in_check(self) -> bool:
        """Mevcut taraf şah altında mı? (d komutu çıktısından)."""
        self._send("d")
        lines = self._wait_for("Şah kontrolü", timeout=2.0)
        for line in lines:
            if "Şah kontrolü:" in line:
                return "Evet" in line or "true" in line.lower() or ": 1" in line
        return False

    def close(self):
        try:
            self._send("quit")
            self.proc.wait(timeout=2)
        except Exception:
            self.proc.kill()


def play_game(engine: EngineProcess, depth: int, min_move: int, max_move: int) -> list[dict]:
    """Tek oyun oynat, pozisyon verilerini ve oyun sonucunu topla.

    Adjudikasyon: |score_cp| > ADJ_THRESHOLD üst üste ADJ_CONSEC hamlede → kazanan.
    max_move dolduğunda son skora göre sonuç belirlenir.
    """
    # Adjudikasyon eşiği ve art arda gerekli hamle sayısı
    ADJ_THRESHOLD = 300  # decisively winning (düşürüldü: daha fazla kararlı oyun)
    ADJ_CONSEC    = 3

    engine.new_game()
    # Rastgele açılış seç — oyun çeşitliliği için
    opening = random.choice(OPENING_POOL)
    moves = list(opening)
    records = []
    # result: beyaz bakışından +1=beyaz kazandı, -1=siyah kazandı, 0=beraberlik
    result = 0
    consec_decisive = 0  # art arda aynı yönde büyük skor sayısı
    adj_sign = 0         # +1 veya -1

    for move_num in range(max_move):
        engine.set_position(moves)

        # Eval al
        score = engine.get_eval()

        # Hamle al
        best = engine.go_depth(depth)
        if best is None or best == "0000":
            # Hamle yok → şah-mat veya pat
            in_check = engine.get_in_check()
            if in_check:
                # Şah-mat: mevcut taraf kaybetti
                result = -1 if (move_num % 2 == 0) else 1
            else:
                result = 0  # pat
            break

        # Kayıt (ilk min_move hamleden sonra)
        if move_num >= min_move and score is not None:
            side_mul = 1 if (move_num % 2 == 0) else -1
            score_white = score * side_mul
            records.append({
                "moves": " ".join(moves),
                "move_num": move_num,
                "score_cp": score_white,
                "depth": depth,
            })

            # Adjudikasyon: art arda büyük skor → kazan/kaybet
            if abs(score_white) >= ADJ_THRESHOLD:
                sign = 1 if score_white > 0 else -1
                if sign == adj_sign:
                    consec_decisive += 1
                else:
                    consec_decisive = 1
                    adj_sign = sign
                if consec_decisive >= ADJ_CONSEC:
                    result = adj_sign
                    break
            else:
                consec_decisive = 0
                adj_sign = 0

        moves.append(best)
    else:
        # max_move tükendi — son skora göre sonuç tahmini
        if records:
            last_score = records[-1]["score_cp"]
            if last_score > 150:    # daha düşük eşik → daha az beraberlik tahmini
                result = 1
            elif last_score < -150:
                result = -1
            else:
                result = 0

    # Oyun sonucunu tüm kayıtlara ekle (beyaz bakışından)
    for rec in records:
        rec["result"] = result

    return records


def main():
    args = parse_args()

    engine_path = Path(args.engine)
    if not engine_path.exists():
        print(f"HATA: Motor bulunamadı: {engine_path}", file=sys.stderr)
        sys.exit(1)

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    import os
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    pid_suffix = os.getpid()
    out_file = output_dir / f"selfplay_{timestamp}_{pid_suffix}.jsonl"

    print(f"Motor: {engine_path}")
    print(f"Oyun sayısı: {args.games}, Derinlik: {args.depth}")
    print(f"Çıktı: {out_file}")
    print()

    engine = EngineProcess(str(engine_path))
    total_records = 0

    with open(out_file, "w", encoding="utf-8") as f:
        for game_idx in range(args.games):
            print(f"Oyun {game_idx + 1}/{args.games}...", end=" ", flush=True)
            try:
                records = play_game(engine, args.depth, args.min_move, args.max_move)
                for rec in records:
                    f.write(json.dumps(rec, ensure_ascii=False) + "\n")
                total_records += len(records)
                print(f"{len(records)} pozisyon")
            except Exception as e:
                print(f"HATA: {e}")
                # Motor sürecini yeniden başlat
                engine.close()
                engine = EngineProcess(str(engine_path.absolute()))

    engine.close()
    print(f"\nToplam {total_records} pozisyon kaydedildi → {out_file}")


if __name__ == "__main__":
    main()
