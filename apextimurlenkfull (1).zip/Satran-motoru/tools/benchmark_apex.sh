#!/bin/bash
# benchmark_apex.sh — NNUE açık vs kapalı karşılaştırması
#
# Kullanım: bash tools/benchmark_apex.sh

set -e

BINARY="./build/apex_timur"
NNUE_MODEL="${1:-networks/apex_v2.bin}"
DEPTHS=(4 5 6)

# Test pozisyonları
POSITIONS=(
    "startpos"
    "fen rktzfkvztnr/ppppppppppp/11/11/11/11/11/PPPPPPPPPPP/RKTZFKVZTNR/E.C.W.W.C.E w - 0 1"
)
POS_NAMES=("Başlangıç" "Başlangıç-FEN")

run_search() {
    local nnue_flag=$1
    local depth=$2
    local pos=$3
    printf "setoption name UseNNUE value %s\nsetoption name NNUEPath value %s\nposition %s\ngo depth %d\nquit\n" \
        "$nnue_flag" "$NNUE_MODEL" "$pos" "$depth" | "$BINARY" 2>/dev/null \
        | grep -E "^info depth $depth " | tail -1
}

echo "════════════════════════════════════════════════════════════"
echo "Apex Timurlenk — NNUE ON vs OFF Karşılaştırma"
echo "════════════════════════════════════════════════════════════"
echo ""

# Perft regresyon
echo "Perft(1) kontrolü:"
result=$(printf "position startpos\nperft 1\nquit\n" | "$BINARY" 2>/dev/null | grep "Perft")
echo "  $result"
if ! echo "$result" | grep -q "= 53"; then
    echo "  HATA: perft(1) != 53 — regresyon var!"
    exit 1
fi
echo ""

echo "════ NPS KARŞILAŞTIRMA ════"
echo ""
printf "%-6s %-8s %-12s %-12s %-10s %-10s\n" "Depth" "Pozisyon" "NNUE-NPS" "HCE-NPS" "NNUE-score" "HCE-score"
echo "----------------------------------------------------------------------"

for pi in "${!POSITIONS[@]}"; do
    pos="${POSITIONS[$pi]}"
    pname="${POS_NAMES[$pi]}"

    for depth in "${DEPTHS[@]}"; do
        line_nnue=$(run_search "true"  "$depth" "$pos")
        line_hce=$(run_search "false" "$depth" "$pos")

        nps_nnue=$(echo "$line_nnue" | grep -oP 'nps \K\d+' || echo "0")
        nps_hce=$(echo "$line_hce"  | grep -oP 'nps \K\d+' || echo "0")
        sc_nnue=$(echo "$line_nnue" | grep -oP 'score cp \K-?\d+' || echo "?")
        sc_hce=$(echo "$line_hce"  | grep -oP 'score cp \K-?\d+' || echo "?")

        printf "%-6s %-8s %-12s %-12s %-10s %-10s\n" \
            "$depth" "$pname" "${nps_nnue}" "${nps_hce}" "${sc_nnue}" "${sc_hce}"
    done
done

echo ""
echo "════ EVAL DETAYI (başlangıç pozisyonu) ════"
echo ""
echo "NNUE aktif ($NNUE_MODEL):"
printf "setoption name UseNNUE value true\nsetoption name NNUEPath value %s\nposition startpos\neval\nquit\n" \
    "$NNUE_MODEL" | "$BINARY" 2>/dev/null | grep -i "değerlendirme\|NNUE\|HCE\|score\|eval" | head -5 || true

echo ""
echo "NNUE kapalı (saf HCE):"
printf "setoption name UseNNUE value false\nposition startpos\neval\nquit\n" \
    | "$BINARY" 2>/dev/null | grep -i "değerlendirme\|NNUE\|HCE\|score\|eval" | head -5 || true

echo ""
echo "════════════════════════════════════════════════════════════"
echo "SONUÇ: Benchmark tamamlandı"
echo "Yorum: NPS farkı NNUE inference maliyetini gösterir."
echo "       Score farkı NNUE'nun eval katkısını gösterir."
echo "════════════════════════════════════════════════════════════"
