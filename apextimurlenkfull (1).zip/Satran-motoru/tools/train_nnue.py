#!/usr/bin/env python3
"""
train_nnue.py — Apex Timurlenk NNUE eğitim scripti

Self-play verilerinden NNUE ağırlıklarını eğitir ve networks/apex_v1.bin'e yazar.

Kurulum:
  pip install torch numpy

Kullanım:
  # Eğit
  python3 tools/train_nnue.py --data data/selfplay_*.jsonl --epochs 50

  # Çalıştır (mevcut modeli test et)
  python3 tools/train_nnue.py --test --model networks/apex_v1.bin
"""

import argparse
import json
import struct
import sys
from pathlib import Path

try:
    import torch
    import torch.nn as nn
    import numpy as np
except ImportError:
    print("HATA: PyTorch gerekli. Kur: pip install torch numpy")
    sys.exit(1)


# ─── NNUE Mimarisi (nnue.h ile senkronize) ───────────────────────────────────

PIECE_TYPES  = 11   # SAH..PIYON (0-tabanlı)
SQUARES      = 110  # 11×10 tahta
NNUE_INPUT   = PIECE_TYPES * SQUARES   # 1210 per side
NNUE_L1      = 256
NNUE_L2      = 32
NNUE_OUTPUT  = 1

Q_IN    = 127
Q_W1    = 64
Q_W2    = 64
SCALE   = 400       # centipawn çıkış ölçeği

# Taş sembolleri → indeks (nnue.cpp PieceType enum - 1, SAH=0..PIYON=10)
PIECE_IDX = {
    'K': 0,  # SAH
    'R': 1,  # KALE
    'Z': 2,  # ZURAFA
    'T': 3,  # TALIA
    'N': 4,  # AT
    'C': 5,  # DEVE
    'E': 6,  # FIL
    'W': 7,  # SAVAS
    'F': 8,  # FERZ
    'V': 9,  # VALI
    'P': 10, # PIYON
}


class NNUEModel(nn.Module):
    def __init__(self):
        super().__init__()
        # C++ ile birebir: W1 paylaşımlı, her yan ayrı uygulanır
        self.L1 = nn.Linear(NNUE_INPUT, NNUE_L1)   # 1210 → 256 (paylaşımlı)
        self.L2 = nn.Linear(NNUE_L1 * 2, NNUE_L2)  # 512 → 32
        self.L3 = nn.Linear(NNUE_L2, NNUE_OUTPUT)   # 32 → 1

    def forward(self, x_white: torch.Tensor, x_black: torch.Tensor) -> torch.Tensor:
        # L1: her perspektif ayrı, aynı ağırlık matrisi
        w = torch.clamp(self.L1(x_white), 0, 1)
        b = torch.clamp(self.L1(x_black), 0, 1)
        l1 = torch.cat([w, b], dim=-1)  # (batch, 512)

        # L2 ReLU
        l2 = torch.relu(self.L2(l1))

        # L3 lineer çıkış
        return self.L3(l2)


# ─── Tahta Simülatörü ─────────────────────────────────────────────────────────
# board: 110 elemanlı liste [(pt_idx, is_white) | None], indeks = rank*11 + file

def _start_board() -> list:
    b = [None] * 110

    # Rank 0: beyaz arka sıra (E.C.W.W.C.E)
    for f, ch in enumerate(['E',None,'C',None,'W',None,'W',None,'C',None,'E']):
        if ch:
            b[f] = (PIECE_IDX[ch], True)

    # Rank 1: beyaz ana sıra (RNTZFKVZTNR)
    for f, ch in enumerate(['R','N','T','Z','F','K','V','Z','T','N','R']):
        b[11 + f] = (PIECE_IDX[ch], True)

    # Rank 2: beyaz piyonlar
    for f in range(11):
        b[22 + f] = (PIECE_IDX['P'], True)

    # Rank 7: siyah piyonlar
    for f in range(11):
        b[77 + f] = (PIECE_IDX['P'], False)

    # Rank 8: siyah ana sıra (RNTZVKFZTNR — V/F yerleşimi beyazdan farklı)
    for f, ch in enumerate(['R','N','T','Z','V','K','F','Z','T','N','R']):
        b[88 + f] = (PIECE_IDX[ch], False)

    # Rank 9: siyah arka sıra (e.c.w.w.c.e)
    for f, ch in enumerate(['E',None,'C',None,'W',None,'W',None,'C',None,'E']):
        if ch:
            b[99 + f] = (PIECE_IDX[ch], False)

    return b


def _parse_sq(s: str) -> int:
    """'e4' → sq index (rank*11+file). Rank 1-tabanlı."""
    f = ord(s[0]) - ord('a')
    r = int(s[1:]) - 1
    return r * 11 + f


def _split_sq_pair(s: str) -> tuple[int, int] | None:
    """'f2b10' gibi UCI kare çiftini iki indekse ayrıştır."""
    try:
        i = 1
        while i < len(s) and s[i].isdigit():
            i += 1
        sq1 = (int(s[1:i]) - 1) * 11 + (ord(s[0]) - ord('a'))
        sq2 = (int(s[i + 1:]) - 1) * 11 + (ord(s[i]) - ord('a'))
        if 0 <= sq1 < 110 and 0 <= sq2 < 110:
            return sq1, sq2
    except (ValueError, IndexError):
        pass
    return None


def _apply_move(board: list, move_str: str) -> list:
    b = board[:]

    if move_str in ('0000', 'wc', 'bc', '(none)', ''):
        return b

    # Swap: "swap:f2b2"
    if move_str.startswith('swap:'):
        pair = _split_sq_pair(move_str[5:])
        if pair:
            sq1, sq2 = pair
            b[sq1], b[sq2] = b[sq2], b[sq1]
        return b

    # Terfi kontrolü: "e9f10=R"
    promo = None
    if '=' in move_str:
        move_str, promo_ch = move_str.split('=', 1)
        promo = PIECE_IDX.get(promo_ch.upper(), 1)

    pair = _split_sq_pair(move_str)
    if pair is None:
        return b
    src, dst = pair

    psrc = b[src]
    pdst = b[dst]

    b[dst] = psrc
    b[src] = None
    if promo is not None and psrc is not None:
        b[dst] = (promo, psrc[1])

    return b


def _board_to_features(board: list, stm_is_white: bool
                       ) -> tuple[torch.Tensor, torch.Tensor]:
    """Tahtayı (white_feat, black_feat) vektörlerine dönüştür.
    nnue.cpp feature_index() ile birebir aynı formül."""
    wf = torch.zeros(NNUE_INPUT)
    bf = torch.zeros(NNUE_INPUT)

    for sq in range(110):
        cell = board[sq]
        if cell is None:
            continue
        pt_idx, is_white = cell

        # Beyaz perspektif
        color_w = 0 if is_white else 1
        idx_w = color_w * PIECE_TYPES * SQUARES + pt_idx * SQUARES + sq
        if 0 <= idx_w < NNUE_INPUT:
            wf[idx_w] = 1.0

        # Siyah perspektif (tahta aynalı)
        sq_b = 109 - sq
        color_b = 0 if (not is_white) else 1
        idx_b = color_b * PIECE_TYPES * SQUARES + pt_idx * SQUARES + sq_b
        if 0 <= idx_b < NNUE_INPUT:
            bf[idx_b] = 1.0

    return wf, bf


# ─── Özellik Vektörü ──────────────────────────────────────────────────────────

def moves_to_features(moves_str: str, move_num: int
                      ) -> tuple[torch.Tensor, torch.Tensor]:
    """Hamleleri uygula, pozisyonun özellik vektörlerini döndür."""
    board = _start_board()
    if moves_str:
        for m in moves_str.split():
            board = _apply_move(board, m)
    stm_is_white = (move_num % 2 == 0)
    return _board_to_features(board, stm_is_white)


def load_dataset(paths: list[str]) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    """JSONL dosyalarından veri yükle."""
    white_feats, black_feats, labels = [], [], []

    # λ: score hedefinin ağırlığı; (1-λ): WDL hedefinin ağırlığı
    # v4: 0.65 — daha fazla WDL sinyali (v3'te 0.7 platoya girdi)
    LAMBDA = 0.65

    for path in paths:
        with open(path, encoding="utf-8") as f:
            for line in f:
                try:
                    rec = json.loads(line.strip())
                except json.JSONDecodeError:
                    continue

                score_white = rec.get("score_cp", 0)
                moves_str   = rec.get("moves", "")
                move_num    = rec.get("move_num", 0)
                result_white = rec.get("result", None)  # +1/0/-1, beyaz bakışından

                wf, bf = moves_to_features(moves_str, move_num)
                stm_is_white = (move_num % 2 == 0)

                # STM özellikleri her zaman önce — C++ inference ile aynı sıra
                if stm_is_white:
                    stm_feat, opp_feat = wf, bf
                    score_stm = score_white
                    result_stm = result_white
                else:
                    stm_feat, opp_feat = bf, wf
                    score_stm = -score_white  # siyah bakışından
                    result_stm = -result_white if result_white is not None else None

                white_feats.append(stm_feat)
                black_feats.append(opp_feat)

                # Score hedefi: sigmoid(score_cp) → [0,1]
                score_target = 1.0 / (1.0 + 10 ** (-score_stm / 400.0))

                # WDL hedefi: {-1→0, 0→0.5, +1→1.0} (STM perspektifinden)
                if result_stm is not None:
                    wdl_target = (result_stm + 1.0) / 2.0
                    target_val = LAMBDA * score_target + (1.0 - LAMBDA) * wdl_target
                else:
                    # Eski veri: WDL yok, sadece score kullan
                    target_val = score_target

                target = torch.tensor([target_val], dtype=torch.float32)
                labels.append(target)

    if not white_feats:
        return None, None, None

    return (torch.stack(white_feats),
            torch.stack(black_feats),
            torch.stack(labels))


# ─── Model → apex_v1.bin Dışa Aktarma ────────────────────────────────────────

def export_model(model: NNUEModel, path: str):
    """Eğitilmiş modeli C++ ağırlık formatına dönüştür."""
    state = model.state_dict()

    def to_int16(tensor: torch.Tensor, scale: float) -> bytes:
        arr = (tensor.detach().cpu().numpy() * scale).clip(-32768, 32767).astype("int16")
        return arr.tobytes()

    def to_int32(tensor: torch.Tensor, scale: float) -> bytes:
        arr = (tensor.detach().cpu().numpy() * scale).clip(-2**31, 2**31-1).astype("int32")
        return arr.tobytes()

    with open(path, "wb") as f:
        # Magic + version
        f.write(b"APEX")
        f.write(struct.pack("<i", 1))

        # W1: (NNUE_INPUT, NNUE_L1) → int16 * Q_W1
        w1 = state["L1.weight"]  # (256, 1210)
        f.write(to_int16(w1.T.contiguous(), Q_W1))  # (1210, 256)

        # b1: NNUE_L1 int32
        f.write(to_int32(state["L1.bias"], Q_W1 * Q_IN))

        # W2: (NNUE_L1*2, NNUE_L2) int16
        w2 = state["L2.weight"]  # (32, 512)
        f.write(to_int16(w2.T.contiguous(), Q_W2))  # (512, 32)

        # b2: NNUE_L2 int32
        f.write(to_int32(state["L2.bias"], Q_W1 * Q_W2 * Q_IN))

        # W3: NNUE_L2 int16
        w3 = state["L3.weight"].squeeze()  # (32,)
        f.write(to_int16(w3, SCALE))

        # b3: 1 int32
        f.write(to_int32(state["L3.bias"].unsqueeze(0), Q_W1 * Q_W2 * Q_IN * SCALE / SCALE))

    print(f"Model dışa aktarıldı: {path}")


# ─── Eğitim Döngüsü ──────────────────────────────────────────────────────────

def train(args):
    data_paths = []
    for pattern in args.data:
        data_paths.extend(Path(".").glob(pattern) if "*" in pattern else [Path(pattern)])

    if not data_paths:
        print("HATA: Veri dosyası bulunamadı.")
        sys.exit(1)

    print(f"Veri yükleniyor: {[str(p) for p in data_paths]}")
    X_w, X_b, Y = load_dataset([str(p) for p in data_paths])

    if X_w is None:
        print("HATA: Hiç geçerli satır yüklenemedi.")
        sys.exit(1)

    print(f"Pozisyon sayısı: {len(Y)}")

    model = NNUEModel()

    model_path = args.model or "networks/apex_v1.bin"
    checkpoint_path = model_path.replace(".bin", "_checkpoint.pt")

    # Checkpoint'ten fine-tune — .pt dosyasından yükle
    if Path(checkpoint_path).exists() and not args.fresh:
        print(f"Checkpoint yükleniyor (fine-tune): {checkpoint_path}")
        model.load_state_dict(torch.load(checkpoint_path, weights_only=True))
    elif Path(model_path).exists() and not args.fresh:
        print(f"Not: .bin mevcut ama .pt checkpoint bulunamadı — sıfırdan eğit")

    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.epochs)
    loss_fn = nn.BCEWithLogitsLoss()

    dataset = torch.utils.data.TensorDataset(X_w, X_b, Y)
    loader  = torch.utils.data.DataLoader(dataset, batch_size=args.batch_size, shuffle=True)

    best_loss = float("inf")
    patience_count = 0
    PATIENCE = 20  # iyileşme olmadan dur

    for epoch in range(1, args.epochs + 1):
        model.train()
        total_loss = 0.0
        n = 0

        for x_w, x_b, y in loader:
            optimizer.zero_grad()
            pred = model(x_w, x_b)
            loss = loss_fn(pred, y)
            loss.backward()
            optimizer.step()
            total_loss += loss.item() * len(y)
            n += len(y)

        scheduler.step()
        avg_loss = total_loss / max(n, 1)

        if epoch % 10 == 0 or epoch == 1:
            print(f"Epoch {epoch:4d}/{args.epochs} | Loss: {avg_loss:.6f} | LR: {scheduler.get_last_lr()[0]:.2e}")

        if avg_loss < best_loss - 1e-6:
            best_loss = avg_loss
            patience_count = 0
            torch.save(model.state_dict(), checkpoint_path)
        else:
            patience_count += 1
            if patience_count >= PATIENCE:
                print(f"  Erken durdurma: {PATIENCE} epoch iyileşme yok (epoch {epoch})")
                break

    # En iyi checkpoint yükle ve dışa aktar
    model.load_state_dict(torch.load(checkpoint_path, weights_only=True))
    export_model(model, model_path)
    print(f"Eğitim tamamlandı. En iyi loss: {best_loss:.6f}")


def test_model(args):
    model_path = args.model or "networks/apex_v1.bin"
    if not Path(model_path).exists():
        print(f"Model dosyası bulunamadı: {model_path}")
        sys.exit(1)

    print(f"Model boyutu: {Path(model_path).stat().st_size:,} bytes")

    with open(model_path, "rb") as f:
        magic = f.read(4)
        version = struct.unpack("<i", f.read(4))[0]
        print(f"Magic: {magic}, Versiyon: {version}")
        if magic == b"APEX" and version == 1:
            print("Geçerli apex_v1.bin formatı.")
        else:
            print("HATA: Geçersiz format!")


# ─── Ana Program ──────────────────────────────────────────────────────────────

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", nargs="+", default=[], help="JSONL veri dosyaları (glob desteklenir)")
    ap.add_argument("--model", default="networks/apex_v1.bin", help="Çıkış model yolu")
    ap.add_argument("--epochs", type=int, default=50)
    ap.add_argument("--batch-size", type=int, default=256)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--fresh", action="store_true", help="Sıfırdan eğit (fine-tune değil)")
    ap.add_argument("--test", action="store_true", help="Modeli test et (eğitme)")
    args = ap.parse_args()

    if args.test:
        test_model(args)
    elif args.data:
        train(args)
    else:
        ap.print_help()
        print("\nÖrnek kullanım:")
        print("  python3 tools/generate_selfplay.py --engine build/apex_timur --games 100")
        print("  python3 tools/train_nnue.py --data data/selfplay_*.jsonl --epochs 100")
        print("  python3 tools/train_nnue.py --test --model networks/apex_v1.bin")


if __name__ == "__main__":
    main()
