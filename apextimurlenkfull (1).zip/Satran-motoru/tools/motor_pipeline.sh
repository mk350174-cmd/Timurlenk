#!/bin/bash
# Motor pipeline — eğitim biter → gauntlet → bildirim
# Kullanım: bash tools/motor_pipeline.sh <model_adı> <data_dosyası>
# Ör:      bash tools/motor_pipeline.sh apex_v5 data/selfplay_wdl_v5.jsonl

set -u
MODEL="${1:-apex_v5}"
DATA="${2:-data/selfplay_wdl_v5.jsonl}"
TRAIN_LOG="/tmp/train_${MODEL}.log"
PIPE_LOG="/tmp/pipeline_${MODEL}.log"
STATUS_FILE="/tmp/motor_durumu_${MODEL}.txt"
BASELINE_PCT=45  # v3 baseline %

bildirim() {
  local baslik="$1"
  local mesaj="$2"
  termux-notification --title "$baslik" --content "$mesaj" --vibrate 500 2>/dev/null || true
  echo "[$(date +%H:%M:%S)] $baslik — $mesaj" | tee -a "$PIPE_LOG"
}

bildirim "🔄 Motor Pipeline" "$MODEL eğitimi izleniyor"

# 1. Eğitimin bitmesini bekle
while ! grep -q "Eğitim tamamlandı\|Hata\|Error" "$TRAIN_LOG" 2>/dev/null; do
  sleep 30
done

LOSS=$(grep "En iyi loss" "$TRAIN_LOG" | tail -1 | grep -oE "[0-9]+\.[0-9]+")
EPOCH=$(grep "Erken durdurma\|Epoch.*100" "$TRAIN_LOG" | tail -1)
bildirim "📊 Eğitim Bitti" "$MODEL loss=$LOSS"

# 2. Gauntlet çalıştır (20×2 = 40 oyun, sağlam istatistik)
bildirim "⚔️ Gauntlet" "$MODEL vs HCE — 20×2 oyun başladı"
python3 tools/gauntlet.py \
  --nnue-model "networks/${MODEL}.bin" \
  --games 20 --depth 4 \
  > "/tmp/gauntlet_${MODEL}.log" 2>&1

# 3. Sonucu çıkar
PCT=$(grep "NNUE:" "/tmp/gauntlet_${MODEL}.log" | tail -1 | grep -oE "[0-9]+\.[0-9]+%" | head -1 | tr -d '%')
PCT_INT=${PCT%.*}

# 4. Durum dosyası yaz
cat > "$STATUS_FILE" <<EOF
═══════════════════════════════════════════
MOTOR PIPELINE SONUÇ — $(date '+%Y-%m-%d %H:%M')
═══════════════════════════════════════════
Model:     $MODEL
Veri:      $DATA
Loss:      $LOSS
Gauntlet:  ${PCT}% (baseline v3: ${BASELINE_PCT}%)
EOF

if [ "${PCT_INT:-0}" -ge "$BASELINE_PCT" ]; then
  KARAR="🟢 BAŞARI — yayına hazır (≥%${BASELINE_PCT})"
  bildirim "✅ Motor BAŞARILI" "$MODEL: %${PCT} (baseline %${BASELINE_PCT} aşıldı)"
else
  KARAR="🔴 BAŞARISIZ — kalibrasyon gerekli (<%${BASELINE_PCT})"
  bildirim "⚠️ Motor Düşük" "$MODEL: %${PCT} — baseline altında"
fi

echo "Karar:     $KARAR" >> "$STATUS_FILE"
echo "Log:       /tmp/gauntlet_${MODEL}.log" >> "$STATUS_FILE"
echo "═══════════════════════════════════════════" >> "$STATUS_FILE"

cat "$STATUS_FILE"
bildirim "🏁 Pipeline Bitti" "Sonuç: $STATUS_FILE"
