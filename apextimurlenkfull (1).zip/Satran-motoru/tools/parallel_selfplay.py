#!/usr/bin/env python3
"""
parallel_selfplay.py — Paralel self-play veri üretici koordinatörü

N adet generate_selfplay.py worker'ı aynı anda çalıştırır.
Hepsi tamamlanınca çıktı dosyalarını birleştirir.

Kullanım:
  python3 tools/parallel_selfplay.py --engine build/apex_timur \
      --workers 4 --games 100 --depth 4 --output data/selfplay_wdl_v3.jsonl
"""

import argparse
import subprocess
import sys
import os
from pathlib import Path


def parse_args():
    ap = argparse.ArgumentParser()
    ap.add_argument("--engine", default="build/apex_timur")
    ap.add_argument("--workers", type=int, default=4)
    ap.add_argument("--games", type=int, default=100)
    ap.add_argument("--depth", type=int, default=4)
    ap.add_argument("--output", default="data/selfplay_wdl_v3.jsonl")
    ap.add_argument("--output-dir", default="data")
    return ap.parse_args()


def main():
    args = parse_args()

    script = Path(__file__).parent / "generate_selfplay.py"
    procs = []

    print(f"Başlatılıyor: {args.workers} worker × {args.games} oyun @ derinlik {args.depth}")
    print(f"Toplam hedef: ~{args.workers * args.games} oyun")
    print()

    for i in range(args.workers):
        cmd = [
            sys.executable, str(script),
            "--engine", args.engine,
            "--games", str(args.games),
            "--depth", str(args.depth),
            "--output-dir", args.output_dir,
        ]
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        procs.append((i + 1, proc))
        print(f"  Worker {i+1} başlatıldı (PID {proc.pid})")

    print()

    # Her worker'ın tamamlanmasını bekle
    output_files = []
    for worker_id, proc in procs:
        stdout, _ = proc.communicate()
        # Çıktı dosyasını bul
        for line in stdout.splitlines():
            if line.startswith("Çıktı:"):
                path = line.split("Çıktı:")[-1].strip()
                output_files.append(path)
                print(f"  Worker {worker_id} tamamlandı → {Path(path).name}")
                break
        else:
            print(f"  Worker {worker_id} tamamlandı (dosya adı bulunamadı)")
            # stdout'tan son satır
            for line in stdout.splitlines()[-3:]:
                if "pozisyon" in line:
                    print(f"    {line.strip()}")

    # Birleştir
    out_path = Path(args.output)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    total = 0
    with open(out_path, "w", encoding="utf-8") as fout:
        for fpath in output_files:
            p = Path(fpath)
            if p.exists() and p.stat().st_size > 0:
                with open(p, encoding="utf-8") as fin:
                    for line in fin:
                        if line.strip():
                            fout.write(line)
                            total += 1

    print()
    print(f"Birleştirildi: {len(output_files)} dosya → {out_path}")
    print(f"Toplam pozisyon: {total}")


if __name__ == "__main__":
    main()
