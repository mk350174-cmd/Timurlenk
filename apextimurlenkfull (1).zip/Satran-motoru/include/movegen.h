#pragma once
#include "types.h"
#include "board.h"
#include <array>

namespace Apex {

// ─────────────────────────────────────────────────────────────────────────────
//  MoveList — stack üzerinde yaşayan hamle listesi (heap alloc yok)
// ─────────────────────────────────────────────────────────────────────────────
constexpr int MAX_MOVES = 1024; // Timurlenk'te bir pozisyonda maksimum hamle (güvenli üst sınır)

struct MoveList {
    MoveExt moves[MAX_MOVES];
    int     count = 0;

    void push(Move m, PieceType promo = NO_PIECE_TYPE) {
        moves[count++] = MoveExt(m, promo);
    }
    MoveExt* begin() { return moves; }
    MoveExt* end()   { return moves + count; }
    const MoveExt* begin() const { return moves; }
    const MoveExt* end()   const { return moves + count; }
    int size() const { return count; }
    bool empty() const { return count == 0; }
};

// ─────────────────────────────────────────────────────────────────────────────
//  MoveGenerator
//
//  Timurlenk'e özgü 11 taş tipi için tam hamle üreteci.
//  Tüm hamleler pseudo-legal üretilir; yasal kontrol Board::do_move sonrası
//  inCheck() ile yapılır.
//
//  ── Taş hareketleri (tarihsel) ──────────────────────────────────────────
//
//  ŞAH (K):   8 yönde 1 kare. Ek: swap hakkı (herhangi kendi taşıyla).
//             Citadel girişi (rakibin kalesine) → beraberlik hamlesi.
//
//  KALE (R):  Yatay ve dikey, sınırsız kayma. Taşlar engel.
//
//  ZÜRAFA (Z): Gryphon hareketi.
//             1 kare çapraz hareket et, SONRA en az 3 kare düz devam et.
//             Yani: (±1,±1) + (N×±1,0) veya (0,N×±1) N≥3
//             Aradaki kareler boş olmalı (atlayamaz).
//             Bu tarihsel Timurlenk zürafasıdır (modern satranç zürafasından farklı).
//
//  TALİA (T): Yatay veya dikey tam 2 kare sıçrar. Aradaki taşı ATLAYABİLİR.
//             (0,±2) veya (±2,0) — sadece hedef kareye bakılır.
//
//  AT (N):    Standart L hareketi: (±1,±2) veya (±2,±1). Atlayabilir.
//
//  DEVE (C):  Uzatılmış at: (±1,±3) veya (±3,±1). Atlayabilir.
//
//  FİL (E):   Çapraz tam 2 kare sıçrar. (±2,±2). Atlayabilir. Renk bağımlı.
//
//  SAVAŞ MAKİNESİ (W): Yatay/dikey tam 2 kare sıçrar. (±2,0) veya (0,±2).
//                       Atlayabilir. (Dabbaba)
//
//  FERZ (F):  Çapraz 1 kare. (±1,±1). En zayıf "süvari".
//
//  VALİ (V):  Yatay/dikey 1 kare. (±1,0) veya (0,±1). Wazir.
//
//  PİYON (P): İleri 1 kare. Çift adım YOK (tarihsel kural).
//             Çapraz ileri yeme. En passant YOK.
//             Terfi: son sıraya ulaşınca herhangi taşa dönüşür (şah hariç).
//
//  ── Özel kurallar ───────────────────────────────────────────────────────
//
//  SWAP (Yer Değiştirme):
//    Her oyuncu oyun boyunca sadece BİR KEZ kullanabilir.
//    Şah, kendi herhangi bir taşıyla yer değiştirir.
//    Şah yer değiştirme sonrasında tehdit altında olmamalıdır.
//    Kullanılan taşın hareketi geçerli olmak zorunda değildir.
//
//  CİTADEL (Kale Girişi):
//    Beyaz şah BLACK_CITADEL'e (111) girebilir → oyun beraberlikle biter.
//    Siyah şah WHITE_CITADEL'e (110) girebilir → oyun beraberlikle biter.
//    Citadel'e sadece şah girebilir, başka taş giremez.
//    Citadel'in komşuluğu:
//      WHITE_CITADEL ↔ kare 21 (k2, file=10, rank=1)
//      BLACK_CITADEL ↔ kare 88 (a9, file=0,  rank=8)
//    Şah, normal hareketiyle komşu karede ise citadel'e girebilir.
// ─────────────────────────────────────────────────────────────────────────────
class MoveGenerator {
public:
    // ── Ana üretim fonksiyonları ──────────────────────────────────────────

    // Tüm yasal hamleler (şaha girilmeyenler)
    static void generate_legal   (const Board& b, MoveList& ml);
    static void generate_legal   (Board& b,       MoveList& ml); // do_move gerektiren bağlamlar

    // Pseudo-legal hamleler (şah kontrolü yapılmaz, hızlı)
    static void generate_pseudo  (const Board& b, MoveList& ml);

    // Sadece yemeler + promosyonlar (quiescence search için)
    static void generate_captures(const Board& b, MoveList& ml);

    // Şahı kurtaran hamleler (şah altındayken)
    static void generate_evasions(const Board& b, MoveList& ml);

    // ── Taş bazlı üreticiler (public — evaluate/search tarafından kullanılır) ─
    static void gen_sah   (const Board& b, Square from, Color c, MoveList& ml);
    static void gen_kale  (const Board& b, Square from, Color c, MoveList& ml);
    static void gen_zurafa(const Board& b, Square from, Color c, MoveList& ml);
    static void gen_talia (const Board& b, Square from, Color c, MoveList& ml);
    static void gen_at    (const Board& b, Square from, Color c, MoveList& ml);
    static void gen_deve  (const Board& b, Square from, Color c, MoveList& ml);
    static void gen_fil   (const Board& b, Square from, Color c, MoveList& ml);
    static void gen_savas (const Board& b, Square from, Color c, MoveList& ml);
    static void gen_ferz  (const Board& b, Square from, Color c, MoveList& ml);
    static void gen_vali  (const Board& b, Square from, Color c, MoveList& ml);
    static void gen_piyon (const Board& b, Square from, Color c, MoveList& ml);

    // Swap hamlesi üretimi
    static void gen_swap  (const Board& b, Color c, MoveList& ml);

    // ── Mobilite sayısı (değerlendirici için) ──────────────────────────────
    // Yasal hamle üretmeden sadece sayar (daha hızlı)
    static int  mobility(const Board& b, Color c);

    // ── Yardımcılar ───────────────────────────────────────────────────────

    // Kayma yardımcısı: (dx,dy) yönünde engele kadar git
    // Hamleler ml'e eklenir; taş yeme dahil
    static void slide(const Board& b, Square from, Color c,
                      int dx, int dy, MoveList& ml);

    // Sıçrama yardımcısı: (dx,dy) hedefine git (varsa yiyor, yoksa geçiyor)
    static void jump(const Board& b, Square from, Color c,
                     int dx, int dy, MoveList& ml);

    // Kare geçerli mi ve erişilebilir mi (boş veya düşman)
    static bool can_go(const Board& b, Color c, int file, int rank);

    // Zürafa için: (df,dr) çapraz + (N×sf, 0) veya (0, N×sr) düz (N≥3)
    static void zurafa_ray(const Board& b, Square from, Color c,
                           int df, int dr, MoveList& ml);
};

// ─────────────────────────────────────────────────────────────────────────────
//  Hamle Sıralama (Move Ordering)
//  Alpha-Beta verimliliği için hamleler en iyiden en kötüye sıralanır.
//
//  Öncelik sırası:
//    1. TT hamlesi (önceki aramanın en iyi hamlesi)
//    2. Kazançlı yemeler (MVV-LVA: Most Valuable Victim / Least Valuable Attacker)
//    3. Şah terfileri
//    4. Killer hamleler (aynı derinlikte beta kesimi yapan hamleler)
//    5. Counter-move (önceki hamleye tarihsel en iyi yanıt)
//    6. History heuristic (geçmişte iyi beta kesimi yapan hamleler)
//    7. Kayıplı yemeler (SEE < 0)
// ─────────────────────────────────────────────────────────────────────────────
constexpr int MAX_PLY = 128;

class MoveOrderer {
public:
    MoveOrderer() { reset(); }

    void reset();

    // Hamleleri skorla ve sırala
    // cont_hist: [PIECE_TYPE_NB][BOARD_SIZE] — önceki hamle bağlamı (CMH)
    void score_moves(MoveList& ml, const Board& b,
                     Move tt_move, int ply, Color stm,
                     Move prev_move = MOVE_NONE,
                     const i32 (*cont_hist)[BOARD_SIZE] = nullptr) const;

    // Partial insertion sort: index'ten itibaren en yüksek skorlu hamleyi öne getirir
    MoveExt& next_move(MoveList& ml, int index) const;

    // Killer hamle ekle (beta kesimi yapan hamle)
    void add_killer(Move m, int ply);

    // History güncelle
    void update_history(Move m, int depth, bool good, Color stm);

    // Capture history güncelle: [renk][hedef kare][yakalanan taş tipi]
    void update_cap_history(Move m, int depth, bool good, Color stm, PieceType captured);

    // Counter-move güncelle
    void update_counter(Move prev, Move response);

    // SEE (Static Exchange Evaluation) — taş değişiminin net değeri
    static i32 see(const Board& b, Move m);

private:
    // Killers: her derinlik için 2 hamle
    Move killers_[MAX_PLY][2];

    // History tablosu: [renk][kaynak][hedef] → skor
    // Timurlenk için: 2 × 112 × 112 = 25088 giriş
    i32  history_[2][BOARD_SIZE][BOARD_SIZE];

    // Capture history: [renk][hedef kare][yakalanan taş tipi] → skor
    // Yakalama sıralamasını MVV-LVA ötesinde iyileştirir
    // 2 × 112 × 11 = 2464 giriş (~9.6KB)
    i32  cap_history_[2][BOARD_SIZE][PIECE_TYPE_NB];

    // Counter-move: önceki hamleye karşı en iyi yanıt
    Move counter_[BOARD_SIZE][BOARD_SIZE];
};

} // namespace Apex
