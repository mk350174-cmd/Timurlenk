#pragma once
#include "types.h"
#include <string>
#include <algorithm>

namespace Apex {

// ─────────────────────────────────────────────────────────────────────────────
//  PersonaLayer — L1.5 Katman
//
//  Apex v2.0 Bilişsel Mimari'nin temel persona altyapısı.
//  ML altyapısı gerektirmeden saf C++ ile arama parametrelerini etkiler:
//
//    Machiavelli (K1–K10): Ragione di Stato — pragmatik, dar aspiration,
//                          Necessità modunda agresif zaman yönetimi.
//    Nietzsche             : Güç İstenci — geniş aspiration, Vezüv protokolü
//                          ile materyal feda uzantıları.
//
//  Psyche skaleri (ψt ∈ [-100, +100]):
//    ψ < -60  → Necessità modu (K36): dar pencere, acil arama
//    ψ > +60 (Nietzsche) → Vezüv Protokolü: geniş pencere, feda uzantısı
// ─────────────────────────────────────────────────────────────────────────────

enum class PersonaType : u8 {
    NONE        = 0,
    MACHIAVELLI = 1,
    NIETZSCHE   = 2,
    // Türk-Altay mitolojisi — v0.4.0-mythology
    ULGEN       = 3,  // Yaratıcı Tanrı: pozisyonel, sabırlı, uzun vadeli
    ERLIK       = 4,  // Yeraltı Hükümdarı: agresif, taktik, feda odaklı
    BOZKURT     = 5,  // Göktürk Totemi: dinamik, reaktif, tempo avcısı
    TENGRI      = 6,  // Gök Tanrı: saf hesap, maksimum derinlik
    DEDE_KORKUT = 7,  // Bilge Ozan: açılış odaklı, tecrübe bazlı
    UMAY        = 8,  // Ana Tanrıça: savunmacı, şah güvenliği öncelikli
};

struct PersonaLayer {
    PersonaType type   = PersonaType::NONE;
    int         psyche = 0;  // ψt ∈ [-100, +100]

    void set_persona(PersonaType t) { type = t; }
    void set_psyche(int psi)        { psyche = std::clamp(psi, -100, 100); }

    // +ψ → daha saldırgan contempt (beraberlik reddi)
    int contempt() const;

    // Aspiration window başlangıç genişliği
    // Vezüv → ×3, Necessità → ÷2, diğer → base + |ψ|/5
    int aspiration_delta() const;

    // K36 — Necessità: pozisyon kötüyse (ψ < -60) acil mod
    bool necessita_mode() const { return psyche < -60; }

    // Nietzsche Vezüv Protokolü: materyal feda fırsatlarında +1 ply uzatma
    bool vezuv_protocol() const {
        return type == PersonaType::NIETZSCHE && psyche > 60;
    }

    // Erlik Karanlık Derinlik: ψ > +60'ta mat araması modu
    bool erlik_dark_depth() const {
        return type == PersonaType::ERLIK && psyche > 60;
    }

    // Umay Koruyucu Kanat: şah güvenliği düşükse tam savunma modu
    bool umay_shield() const {
        return type == PersonaType::UMAY && psyche < -30;
    }

    // UCI info string yorumu — kısa, felsefi, Türkçe
    std::string commentary(int depth, i32 score) const;

    // Persona adı (UCI combo için)
    const char* name() const {
        switch (type) {
            case PersonaType::MACHIAVELLI: return "Machiavelli";
            case PersonaType::NIETZSCHE:   return "Nietzsche";
            case PersonaType::ULGEN:       return "Ulgen";
            case PersonaType::ERLIK:       return "Erlik";
            case PersonaType::BOZKURT:     return "Bozkurt";
            case PersonaType::TENGRI:      return "Tengri";
            case PersonaType::DEDE_KORKUT: return "DedeKorkut";
            case PersonaType::UMAY:        return "Umay";
            default:                       return "None";
        }
    }
};

} // namespace Apex
