#pragma once
#include "types.h"
#include <cstdint>
#include <string>
#include <unordered_map>
#include <vector>

namespace Apex {

// ─────────────────────────────────────────────────────────────────────────────
//  Açılış Kitabı — APEX binary format v3
//
//  Dosya düzeni:
//    [0..3]  magic: "APEX"
//    [4..7]  versiyon: uint32_t = 3
//    [8..11] kayıt sayısı: uint32_t
//    [...] her kayıt: 8B hash + 1B from_sq + 1B to_sq + 1B promo + 1B pad + 1B weight
//
//  Kullanım:
//    OpeningBook book;
//    book.load("networks/timurlenk_openings.bin");
//    Move m = book.probe(board.hash());   // 0 = kitapta yok
// ─────────────────────────────────────────────────────────────────────────────

struct BookEntry {
    uint8_t from_sq;  // kaynak kare (0-111)
    uint8_t to_sq;    // hedef kare  (0-111)
    uint8_t promo;    // terfi taşı (0 = yok)
    uint8_t weight;   // ağırlık (1-255) — ağırlıklı rastgele seçim
};

class OpeningBook {
public:
    // Dosyadan yükle. Başarılı ise true döner.
    bool load(const std::string& path);

    // Pozisyon hash'ine göre hamle ara.
    // Birden fazla hamle varsa ağırlıklı rastgele seçim yapar.
    // Kitapta yoksa MOVE_NONE (0) döner.
    Move probe(uint64_t pos_hash) const;

    // Kitap yüklü ve dolu mu?
    bool loaded() const { return !entries_.empty(); }

    // Kitaptaki toplam pozisyon sayısı
    size_t size() const { return entries_.size(); }

private:
    std::unordered_map<uint64_t, std::vector<BookEntry>> entries_;
};

} // namespace Apex
