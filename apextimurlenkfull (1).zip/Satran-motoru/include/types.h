#pragma once
#include <cstdint>
#include <cassert>
#include <string>

// ─────────────────────────────────────────────────────────────────────────────
//  APEX Timurlenk Motoru — types.h
//  Temel veri tipleri: kare, taş, renk, hamle
//
//  Tahta düzeni:
//    Normal oyun alanı: 11 sütun × 10 satır = 110 kare (indeks 0–109)
//    Beyaz citadel:     indeks 110  (tahta koordinatında: sütun 11, satır 1)
//    Siyah citadel:     indeks 111  (tahta koordinatında: sütun -1, satır 8)
//    BOARD_SIZE = 112
//
//  Koordinat sistemi:
//    file (sütun): 0–10  → a–k
//    rank (satır): 0–9   → 1–10
//    sq = rank * 11 + file   (normal kareler için)
//    sq = 110                (beyaz citadel: k2 sağında)
//    sq = 111                (siyah citadel: a9 solunda)
// ─────────────────────────────────────────────────────────────────────────────

namespace Apex {

// ── Temel tam sayı tipleri ────────────────────────────────────────────────────
using u8  = uint8_t;
using u16 = uint16_t;
using u32 = uint32_t;
using u64 = uint64_t;
using i8  = int8_t;
using i16 = int16_t;
using i32 = int32_t;
using i64 = int64_t;

// ── Kare (Square) ────────────────────────────────────────────────────────────
// 0–109: normal kareler, 110: beyaz citadel, 111: siyah citadel, 112: geçersiz
using Square = u8;

constexpr int  BOARD_FILES = 11;
constexpr int  BOARD_RANKS = 10;
constexpr int  BOARD_NORMAL = BOARD_FILES * BOARD_RANKS; // 110
constexpr int  BOARD_SIZE   = 112;                       // 110 + 2 citadel
constexpr Square SQ_NONE    = 112;

// Citadel kareleri
constexpr Square WHITE_CITADEL = 110;  // Beyazın rakip kalesine gireceği kare
constexpr Square BLACK_CITADEL = 111;  // Siyahın rakip kalesine gireceği kare

// Citadel'in tahta komşuları (hangi normal kareye bitişik)
// Beyaz citadel: satır 1 (rank=1), sütun 10'un (k) sağında → k2 yanı
// Siyah citadel: satır 8 (rank=8), sütun 0'ın (a) solunda → a9 yanı
constexpr Square WHITE_CITADEL_NEIGHBOR = 1 * BOARD_FILES + 10; // k2 = rank1*11+file10 = 21
constexpr Square BLACK_CITADEL_NEIGHBOR = 8 * BOARD_FILES + 0;  // a9 = rank8*11+file0  = 88

inline Square make_sq(int file, int rank) {
    assert(file >= 0 && file < BOARD_FILES);
    assert(rank >= 0 && rank < BOARD_RANKS);
    return static_cast<Square>(rank * BOARD_FILES + file);
}
inline int sq_file(Square sq) { return sq % BOARD_FILES; }
inline int sq_rank(Square sq) { return sq / BOARD_FILES; }
inline bool sq_valid(Square sq) { return sq < BOARD_NORMAL; }
inline bool sq_is_citadel(Square sq) { return sq == WHITE_CITADEL || sq == BLACK_CITADEL; }

// ── Renk (Color) ─────────────────────────────────────────────────────────────
enum Color : u8 { WHITE = 0, BLACK = 1, NO_COLOR = 2 };
inline Color operator~(Color c) { return static_cast<Color>(c ^ 1); }

// ── Taş Tipi (PieceType) ──────────────────────────────────────────────────────
// Timurlenk'e özgü 11 taş tipi (tarihsel Türkçe isimler)
enum PieceType : u8 {
    NO_PIECE_TYPE = 0,
    SAH    = 1,   // K — Şah          : 8 yönde 1 kare + swap hakkı
    KALE   = 2,   // R — Kale         : yatay/dikey sınırsız kayma
    ZURAFA = 3,   // Z — Zürafa       : çapraz 1 + min 3 düz (gryphon)
    TALIA  = 4,   // T — Talia/Gözcü  : yatay/dikey tam 2 sıçrama
    AT     = 5,   // N — At           : L şekli 2+1 atlama
    DEVE   = 6,   // C — Deve         : 3+1 atlama (extended knight)
    FIL    = 7,   // E — Fil          : çapraz tam 2 sıçrama
    SAVAS  = 8,   // W — Savaş Makinesi: yatay/dikey tam 2 sıçrama
    FERZ   = 9,   // F — Ferz         : çapraz 1 kare
    VALI   = 10,  // V — Vali/Wazir   : yatay/dikey 1 kare
    PIYON  = 11,  // P — Piyon        : ileri 1, çift adım yok, çapraz yer
    PIECE_TYPE_NB = 12
};

// ── Taş (Piece) ───────────────────────────────────────────────────────────────
// Renk + tip birleşimi: bit 0 = renk, bit 1-4 = tip
// Değer aralığı: 0–23 (NO_PIECE=0)
enum Piece : u8 {
    NO_PIECE     = 0,
    W_SAH        = (SAH    << 1) | WHITE,  //  2
    W_KALE       = (KALE   << 1) | WHITE,  //  4
    W_ZURAFA     = (ZURAFA << 1) | WHITE,  //  6
    W_TALIA      = (TALIA  << 1) | WHITE,  //  8
    W_AT         = (AT     << 1) | WHITE,  // 10
    W_DEVE       = (DEVE   << 1) | WHITE,  // 12
    W_FIL        = (FIL    << 1) | WHITE,  // 14
    W_SAVAS      = (SAVAS  << 1) | WHITE,  // 16
    W_FERZ       = (FERZ   << 1) | WHITE,  // 18
    W_VALI       = (VALI   << 1) | WHITE,  // 20
    W_PIYON      = (PIYON  << 1) | WHITE,  // 22
    B_SAH        = (SAH    << 1) | BLACK,  //  3
    B_KALE       = (KALE   << 1) | BLACK,  //  5
    B_ZURAFA     = (ZURAFA << 1) | BLACK,  //  7
    B_TALIA      = (TALIA  << 1) | BLACK,  //  9
    B_AT         = (AT     << 1) | BLACK,  // 11
    B_DEVE       = (DEVE   << 1) | BLACK,  // 13
    B_FIL        = (FIL    << 1) | BLACK,  // 15
    B_SAVAS      = (SAVAS  << 1) | BLACK,  // 17
    B_FERZ       = (FERZ   << 1) | BLACK,  // 19
    B_VALI       = (VALI   << 1) | BLACK,  // 21
    B_PIYON      = (PIYON  << 1) | BLACK,  // 23
    PIECE_NB     = 24
};

inline Piece make_piece(Color c, PieceType pt) {
    return static_cast<Piece>((pt << 1) | c);
}
inline PieceType piece_type(Piece p) { return static_cast<PieceType>(p >> 1); }
inline Color     piece_color(Piece p){ return static_cast<Color>(p & 1); }

// ── Materyal Değerleri ────────────────────────────────────────────────────────
// Centipawn cinsinden (cp). Tarihsel ve pratik denge gözetilerek ayarlandı.
constexpr i32 PIECE_VALUE[PIECE_TYPE_NB] = {
    0,        // NO_PIECE_TYPE
    20000,    // SAH    — sonsuz değer (mat)
    550,      // KALE   — uzun mesafe kayma, çok güçlü 11x10'da
    480,      // ZURAFA — gryphon: çapraz+düz kombinasyonu, çok mobil
    340,      // TALIA  — 2'li sıçrama, atlama özelliği ile barikat kırıcı
    325,      // AT     — klasik at hareketi, renk bağımlı
    330,      // DEVE   — 3+1 atlama, renk bağımsız → 11x10'da At'tan biraz değerli
    290,      // FIL    — 2'li çapraz sıçrama, renk bağımlı
    260,      // SAVAS  — 2'li düz sıçrama, kontrol alanı sınırlı
    160,      // FERZ   — sadece çapraz 1, zayıf ama stratejik
    130,      // VALI   — sadece dik 1, en zayıf süvari
    100,      // PIYON  — temel birim
};

// ── Hamle (Move) ──────────────────────────────────────────────────────────────
// 16-bit kodlama:
//   bit  0– 6: kaynak kare    (0–112, 7 bit)
//   bit  7–13: hedef kare     (0–112, 7 bit)
//   bit 14–15: hamle tipi (0=normal, 1=terfi, 2=swap, 3=citadel-giriş)
// Terfi hamlesi için ek bilgi ayrı tutulur (MoveExt).
using Move = u16;
constexpr Move MOVE_NONE  = 0;
constexpr Move MOVE_NULL  = 0xFFFF;

enum MoveType : u8 {
    MT_NORMAL  = 0,
    MT_PROMO   = 1,  // Piyon terfisi
    MT_SWAP    = 2,  // Şah yer değiştirme hakkı (Timurlenk özgün kuralı)
    MT_CITADEL = 3,  // Şahın rakip kalesine girişi (beraberlik)
};

inline Move  make_move(Square from, Square to, MoveType mt = MT_NORMAL) {
    return static_cast<Move>((mt << 14) | (to << 7) | from);
}
inline Square    move_from(Move m) { return static_cast<Square>(m & 0x7F); }
inline Square    move_to  (Move m) { return static_cast<Square>((m >> 7) & 0x7F); }
inline MoveType  move_type(Move m) { return static_cast<MoveType>(m >> 14); }
inline bool      move_ok  (Move m) { return m != MOVE_NONE && m != MOVE_NULL; }

// Terfi hamlesi için genişletilmiş bilgi
struct MoveExt {
    Move      move;
    PieceType promo;    // MT_PROMO ise hangi taşa terfi
    i32       score = 0; // Sıralama skoru (score_moves tarafından doldurulur)
    MoveExt() : move(MOVE_NONE), promo(NO_PIECE_TYPE), score(0) {}
    MoveExt(Move m, PieceType p = NO_PIECE_TYPE) : move(m), promo(p), score(0) {}
};

// ── Değerlendirme skoru ───────────────────────────────────────────────────────
constexpr i32 SCORE_INFINITE =  1'000'000;
constexpr i32 SCORE_NONE     = -1'000'001;
constexpr i32 SCORE_MATE     =    900'000;
constexpr i32 SCORE_DRAW     =          0;

inline bool is_mate_score(i32 s) { return std::abs(s) > SCORE_MATE - 500; }
inline int  mate_in_plies(i32 s) {
    return s > 0 ? (SCORE_MATE - s + 1) / 2 : -(SCORE_MATE + s) / 2;
}

// ── Taş isimleri (debug/UCI için) ────────────────────────────────────────────
constexpr const char* PIECE_TYPE_STR[PIECE_TYPE_NB] = {
    ".", "K", "R", "Z", "T", "N", "C", "E", "W", "F", "V", "P"
};
constexpr const char* PIECE_TYPE_TR[PIECE_TYPE_NB] = {
    "-", "Şah", "Kale", "Zürafa", "Talia", "At", "Deve",
    "Fil", "Savaş Makinesi", "Ferz", "Vali", "Piyon"
};

} // namespace Apex
