#pragma once
/**
 * nnue.h — Apex Timurlenk NNUE Değerlendirme Ağı
 *
 * Mimari: HalfKA benzeri, Timurlenk'e özgü
 *   Giriş : 2 × (PIECE_TYPES × BOARD_SQ) = 2 × 1320 = 2640 binary özellik
 *           (her iki kral kare perspektifinden ayrı birikimleyici)
 *   L1    : 256 nöron, clamp(0,127) aktivasyon (quantize)
 *   L2    : 32 nöron, ReLU
 *   Çıkış : 1 değer → cp birimine dönüştür (× SCALE / Q_SCALE)
 *
 * Ağırlık dosyası: networks/apex_v1.bin
 *   Format: "APEX" (4B) + version(4B) + W1 + b1 + W2 + b2 + W3 + b3
 *   Tüm ağırlıklar int16 (quantize), biyaslar int32
 */

#include "types.h"
#include <array>
#include <cstdint>
#include <string>

namespace Apex {

class Board; // ileri bildirim — board.h döngüsel bağımlılık önler

// ─── Ağ boyutları ────────────────────────────────────────────────────────────
// Giriş özelliği: (parça tipi - piyon değil SAH dahil) × kare
// 11 parça tipi (SAH=1..PIYON=11) × 110 kare = 1210 per renk → 2420 toplam
// Ama HalfKA: (parça tipi × kare) için her renk perspektifinden ayrı
// Basit versiyon: her renk için [ptype-1][sq] binary özelliği

static constexpr int NNUE_PIECE_TYPES = 11; // SAH..PIYON
static constexpr int NNUE_SQUARES     = BOARD_NORMAL; // 110
static constexpr int NNUE_INPUT       = NNUE_PIECE_TYPES * NNUE_SQUARES; // 1210 per side
static constexpr int NNUE_L1          = 256;
static constexpr int NNUE_L2          = 32;
static constexpr int NNUE_OUTPUT      = 1;

// Quantization sabitleri
static constexpr int Q_IN   = 127;  // giriş scale
static constexpr int Q_W1   = 64;   // L1 ağırlık scale
static constexpr int Q_W2   = 64;   // L2 ağırlık scale
static constexpr int NNUE_SCALE = 400; // cp çıkış ölçeği

// ─── Akümülatör ──────────────────────────────────────────────────────────────
// Her iki taraf için ayrı ayrı tutulur, taş ekleme/çıkarma sırasında güncellenir

struct Accumulator {
    std::array<int32_t, NNUE_L1> white{};
    std::array<int32_t, NNUE_L1> black{};

    void reset(const std::array<int32_t, NNUE_L1>& bias) {
        white = bias;
        black = bias;
    }
};

// ─── NNUE Ağı ────────────────────────────────────────────────────────────────

class NNUENetwork {
public:
    NNUENetwork();

    // Ağırlık dosyasından yükle — başarılıysa true döner
    bool load(const std::string& path);

    // Ağ yüklü mü?
    bool loaded() const { return loaded_; }

    // Tam (kaba kuvvet) değerlendirme — akümülatör olmadan
    // board: tüm taş bilgisi
    // stm: sıradaki renk (+1 → stm avantajı)
    i32 evaluate(const Board& b, Color stm) const;

    // Özellik indeksi hesapla: [color perspective][piece_type][square]
    static int feature_index(Color perspective, Color piece_color,
                             PieceType pt, Square sq);

    // Artımlı akümülatör güncelleme — tek taş ekleme/çıkarma
    void add_piece(Accumulator& acc, Color pc, PieceType pt, Square sq) const;
    void remove_piece_from_acc(Accumulator& acc, Color pc, PieceType pt, Square sq) const;

    // L1 bias erişimi (Board::refresh_nnue_acc için)
    const std::array<int32_t, NNUE_L1>& b1() const { return b1_; }

private:
    bool loaded_ = false;

    // L1: [NNUE_INPUT × NNUE_L1] — her özelliğin L1 nöronlarına katkısı
    // Her taraf kendi perspektifinden bakarak aynı L1 ağırlıklarını kullanır
    std::array<int16_t, NNUE_INPUT * NNUE_L1> W1_{};
    std::array<int32_t, NNUE_L1>              b1_{};

    // L2: [NNUE_L1 * 2 × NNUE_L2] — iki birikimleyici birleştirilir
    std::array<int16_t, NNUE_L1 * 2 * NNUE_L2> W2_{};
    std::array<int32_t, NNUE_L2>                b2_{};

    // L3: [NNUE_L2 × NNUE_OUTPUT]
    std::array<int16_t, NNUE_L2 * NNUE_OUTPUT> W3_{};
    std::array<int32_t, NNUE_OUTPUT>            b3_{};

    // İleri besleme (quantize)
    i32 forward(const Accumulator& acc, Color stm) const;
};

} // namespace Apex
