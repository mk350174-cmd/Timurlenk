#pragma once
#include <string>
#include <functional>
#include <atomic>
#include <thread>

namespace Apex {

// ─────────────────────────────────────────────────────────────────────────────
//  CommentaryBridge — Needle Python köprüsü
//
//  needle_bridge.py'yi tek-seferlik subprocess olarak çağırır (echo | python3).
//  Her istek ayrı bir thread'de çalışır — motor hiçbir zaman bloke olmaz.
//  Needle kurulu değilse veya hata olursa sessizce başarısız olur.
//
//  Kullanım:
//    bridge.set_script("/path/to/needle_bridge.py")
//    bridge.request_async("ERLIK", 250, 8, [](const std::string& s) {
//        std::cout << "info string [Needle] " << s << "\n";
//    });
// ─────────────────────────────────────────────────────────────────────────────

class CommentaryBridge {
public:
    using Callback = std::function<void(const std::string&)>;

    void set_script(const std::string& path) { script_path_ = path; }
    bool is_configured() const { return !script_path_.empty(); }

    // Asenkron: ayrı thread'de çalışır, sonuç callback ile döner
    void request_async(const std::string& persona, int score, int depth,
                       Callback cb);

    // Zaman yönetimi kararı: "spend_more"|"normal"|"spend_less" döner (async)
    // phase_score: 0=endgame .. 255=middlegame
    // material_balance: cp cinsinden (+ = kazanıyoruz, - = kaybediyoruz)
    void request_time_async(const std::string& persona,
                            int phase_score,
                            int material_balance,
                            Callback cb);

    // Açılış stili kararı: "aggressive"|"solid"|"gambit" döner (async)
    void request_opening_async(const std::string& persona, int move_num,
                                bool is_white, Callback cb);

    // Citadel strateji kararı: "rush_citadel"|"consolidate"|"ignore" döner (async)
    void request_citadel_async(const std::string& persona, int phase,
                                int king_dist, int material, Callback cb);

    // Dinamik contempt kararı: "raise"|"hold"|"lower" döner (async)
    void request_contempt_async(const std::string& persona, int score_trend,
                                 int move_num, Callback cb);

    // Tüm async işlerin bitmesini bekle (quit sırasında)
    void wait();

private:
    std::string       script_path_;
    std::atomic<int>  pending_{0};

    // Tek-seferlik subprocess: echo JSON | python3 bridge.py
    // Sonuç: commentary string veya "" (hata)
    static std::string call_bridge(const std::string& script,
                                   const std::string& persona,
                                   int score, int depth);

    // Zaman kararı için subprocess: "decision" alanı döner
    static std::string call_bridge_time(const std::string& script,
                                        const std::string& persona,
                                        int phase_score, int material_balance);

    // Açılış stili için subprocess: "style" alanı döner
    static std::string call_bridge_opening(const std::string& script,
                                            const std::string& persona,
                                            int move_num, bool is_white);

    // Citadel stratejisi için subprocess: "strategy" alanı döner
    static std::string call_bridge_citadel(const std::string& script,
                                            const std::string& persona,
                                            int phase, int king_dist, int material);

    // Contempt kararı için subprocess: "action" alanı döner
    static std::string call_bridge_contempt(const std::string& script,
                                             const std::string& persona,
                                             int score_trend, int move_num);
};

} // namespace Apex
