#pragma once
#include "types.h"
#include <array>
#include <random>

namespace Apex {

// ─────────────────────────────────────────────────────────────────────────────
//  Zobrist Hashing
//  Her (kare, taş) kombinasyonu için rastgele 64-bit anahtar.
//  Artımlı güncelleme: hamle yapıldığında XOR ile çıkar/ekle.
// ─────────────────────────────────────────────────────────────────────────────
struct ZobristTable {
    // [kare][taş tipi][renk]
    u64 piece [BOARD_SIZE][PIECE_TYPE_NB][2];
    u64 side;               // Siyah'ın sırası olduğunda XOR'la
    u64 swap_used[2];       // Yer değiştirme hakkı kullanıldığında
    u64 citadel_draw;       // Citadel beraberliği hash'i (özel)

    void init(u64 seed = 0xDEADBEEF12345678ULL) {
        // xorshift64 ile deterministik üretim (her çalışmada aynı)
        auto rng = [&]() -> u64 {
            seed ^= seed << 13;
            seed ^= seed >> 7;
            seed ^= seed << 17;
            return seed;
        };
        for (int sq = 0; sq < BOARD_SIZE; sq++)
            for (int pt = 0; pt < PIECE_TYPE_NB; pt++)
                for (int c = 0; c < 2; c++)
                    piece[sq][pt][c] = rng();
        side            = rng();
        swap_used[0]    = rng();
        swap_used[1]    = rng();
        citadel_draw    = rng();
    }
};

extern ZobristTable Zobrist; // tt.cpp'de tanımlanır

// ─────────────────────────────────────────────────────────────────────────────
//  Transposition Table (TT)
//  Daha önce analiz edilen pozisyonları saklayan hash tablosu.
//  Her slot 16 byte → önbellek dostu.
// ─────────────────────────────────────────────────────────────────────────────

enum TTFlag : u8 {
    TT_NONE  = 0,
    TT_EXACT = 1,  // Kesin skor
    TT_LOWER = 2,  // Alpha kesimi (alt sınır)
    TT_UPPER = 3,  // Beta kesimi (üst sınır)
};

// TT girişi — 16 byte
struct alignas(16) TTEntry {
    u32  key16;    // hash'in üst 32 bit'i (doğrulama)
    i16  score;    // pozisyon skoru (cp)
    i16  eval;     // statik eval (quiescence için)
    Move move;     // en iyi hamle
    u8   depth;    // arama derinliği
    u8   flag;     // TTFlag
    u8   age;      // TT yaşı (ne zaman yazıldı)
    u8   padding;

    void clear() {
        key16 = 0; score = 0; eval = 0;
        move  = MOVE_NONE; depth = 0;
        flag  = TT_NONE;   age   = 0;
    }
    bool valid() const { return flag != TT_NONE; }
};

static_assert(sizeof(TTEntry) == 16, "TTEntry 16 byte olmali");

// TT boyutu: 2^N slot. Varsayılan: 2^22 = 4M slot × 16 byte = 64 MB
constexpr int TT_DEFAULT_MB = 64;

class TranspositionTable {
public:
    TranspositionTable();
    ~TranspositionTable();

    // MB cinsinden boyutu ayarla (UCI setengineoption)
    void resize(int mb);

    // Tabloyu temizle (yeni oyun başladığında)
    void clear();

    // Yaşı artır (her arama turunda)
    void new_search() { age_++; }

    // Pozisyon yaz
    void store(u64 hash, int depth, TTFlag flag, i32 score, i32 eval,
               Move best_move, int ply = 0);

    // Pozisyon oku — nullptr döndürürse hit yok
    const TTEntry* probe(u64 hash) const;

    // Doluluk oranı (promil — UCI için)
    int hashfull() const;

private:
    TTEntry* table_;
    size_t   size_;    // slot sayısı
    u8       age_;

    size_t index(u64 hash) const { return hash & (size_ - 1); }
};

// ─────────────────────────────────────────────────────────────────────────────
//  Pawn Table (piyon yapısı önbelleği)
//  Piyonlar sık değişmez → ayrı önbellek avantaj sağlar
// ─────────────────────────────────────────────────────────────────────────────
struct PawnEntry {
    u64 key;
    i32 score[2]; // [WHITE][BLACK] piyon yapısı skoru
};

constexpr size_t PAWN_TABLE_SIZE = 1 << 14; // 16K giriş

class PawnTable {
public:
    PawnTable() { clear(); }
    void clear() { entries_.fill({}); }

    PawnEntry* probe(u64 key) {
        auto& e = entries_[key & (PAWN_TABLE_SIZE - 1)];
        return (e.key == key) ? &e : nullptr;
    }
    void store(u64 key, i32 w, i32 b) {
        auto& e = entries_[key & (PAWN_TABLE_SIZE - 1)];
        e.key = key; e.score[WHITE] = w; e.score[BLACK] = b;
    }
private:
    std::array<PawnEntry, PAWN_TABLE_SIZE> entries_;
};

} // namespace Apex
