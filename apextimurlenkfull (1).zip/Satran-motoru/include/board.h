#pragma once
#include "types.h"
#include "tt.h"
#include "nnue.h"
#include <array>
#include <vector>
#include <string>

namespace Apex {

// ─────────────────────────────────────────────────────────────────────────────
//  StateInfo — hamle yapıldığında değişen, undo için saklanması gereken bilgiler
// ─────────────────────────────────────────────────────────────────────────────
struct StateInfo {
    u64       hash;             // Zobrist hash (hamle öncesi)
    u64       pawn_hash;        // Piyon hash'i
    Square    enpassant;        // En passant hedef karesi (SQ_NONE ise yok)
    i32       material[2];      // Materyal dengesi [WHITE][BLACK]
    u8        halfmove;         // 50 hamle kuralı sayacı
    bool      swap_used[2];     // Yer değiştirme hakkı kullanıldı mı [W][B]
    Piece     captured;         // Bu hamlede yenilen taş (NO_PIECE ise yok)
    Move      last_move;        // Yapılan hamle (undo için)
    StateInfo* prev;            // Önceki durum (linked list)
    // Mobilite cache — her node'da tüm hamle üretiminden kaçınmak için
    i32       mobility_cache[2];  // [WHITE][BLACK] toplam hamle sayısı
    bool      mobility_valid[2];  // hesaplanmış mı?
    // NNUE artımlı akümülatör — do_move'da güncellenir, evaluate'te kullanılır
    Accumulator acc;
    bool        acc_valid = false;
};

// ─────────────────────────────────────────────────────────────────────────────
//  Board — Timurlenk tahtası
//
//  Temsil: mailbox (düz dizi) + parça listeleri
//    mailbox[112]: her karede hangi taş var
//    pieces[renk][tip]: her taş tipinin kare kümesi (vector, max ~22 taş/yan)
//
//  112 kare düzeni:
//    [0–109]  : normal 11×10 tahta (rank*11 + file)
//    [110]    : WHITE_CITADEL (beyaz şahın girebileceği siyah citadel)
//    [111]    : BLACK_CITADEL (siyah şahın girebileceği beyaz citadel)
//
//  Citadel komşuluğu:
//    WHITE_CITADEL ↔ kare 21 (k, rank=1 → sütun 10, satır 1)
//    BLACK_CITADEL ↔ kare 88 (a, rank=8 → sütun 0,  satır 8)
// ─────────────────────────────────────────────────────────────────────────────
class Board {
public:
    Board();
    Board(const Board& other);
    Board& operator=(const Board& other);

    // Başlangıç pozisyonunu kur
    void setup();

    // Timurlenk FEN string'den pozisyon yükle
    bool from_string(const std::string& s);

    // Mevcut pozisyonu FEN string'e dönüştür
    std::string to_fen() const;

    // ── Tahta erişimi ──────────────────────────────────────────────────────
    Piece  piece_on(Square sq) const        { return mailbox_[sq]; }
    bool   empty   (Square sq) const        { return mailbox_[sq] == NO_PIECE; }
    Color  color_on(Square sq) const        { return piece_color(mailbox_[sq]); }
    Square king_sq (Color c)   const        { return king_sq_[c]; }

    // ── Durum bilgileri ────────────────────────────────────────────────────
    Color         side_to_move()  const { return stm_; }
    const StateInfo* state()      const { return st_; }
    u64           hash()          const { return st_->hash; }
    u64           pawn_hash()     const { return st_->pawn_hash; }
    Square        enpassant()     const { return st_->enpassant; }
    bool          swap_used(Color c) const { return st_->swap_used[c]; }
    int           halfmove()      const { return st_->halfmove; }
    int           fullmove()      const { return fullmove_; }
    i32           material(Color c)   const { return st_->material[c]; }

    // ── Parça erişimi ─────────────────────────────────────────────────────
    const std::vector<Square>& pieces(Color c, PieceType pt) const {
        return piece_list_[c][pt];
    }

    // ── Saldırı / Şah kontrolü ────────────────────────────────────────────
    bool is_attacked(Square sq, Color by) const;
    bool in_check()    const { return is_attacked(king_sq_[stm_], ~stm_); }
    bool gives_check(Move m) const;

    // ── Hamle yapma / geri alma ───────────────────────────────────────────
    // StateInfo dışarıdan verilir (arama stack'inde tutulur, heap alloc yok)
    void do_move  (Move m, StateInfo& new_st, PieceType promo = NO_PIECE_TYPE);
    void undo_move(Move m);

    // Null move (NMP için — sadece sırayı geçer)
    void do_null_move  (StateInfo& new_st);
    void undo_null_move();

    // ── NNUE bağlantısı (artımlı güncelleme için) ─────────────────────────
    void set_nnue_net(const NNUENetwork* n) { nnue_net_ = n; }
    // Kök pozisyon akümülatörünü sıfırdan hesapla ve valid olarak işaretle
    void refresh_nnue_acc();

    // ── Özel Timurlenk kuralları ──────────────────────────────────────────

    // Şah yer değiştirme (swap): şah herhangi kendi taşıyla yer değiştirir
    // (şahı tehdide sokmaması gerekir)
    bool can_swap(Color c) const { return !st_->swap_used[c]; }

    // Citadel girişi: şah rakibin kalesine girer → beraberlik
    // Kural: WHITE_CITADEL'e sadece siyah şah girebilir (beyazın "kalesine")
    // BLACK_CITADEL'e sadece beyaz şah girebilir
    bool is_citadel_move(Move m) const;

    // Citadel beraberlik kontrolü: şah rakibin kalesine girmişse true
    // Beyaz şah BLACK_CITADEL (111)'e girerse → beraberlik
    // Siyah şah WHITE_CITADEL (110)'a girerse → beraberlik
    bool king_on_citadel(Color c) const {
        if (c == WHITE) return king_sq_[WHITE] == BLACK_CITADEL;
        else            return king_sq_[BLACK] == WHITE_CITADEL;
    }

    // Oyun bitti mi?
    enum GameResult { ONGOING, WHITE_WINS, BLACK_WINS, DRAW };
    GameResult game_over() const;

    // Tekrar kontrolü
    bool is_repetition(int count = 3) const;

    // ── Debug ─────────────────────────────────────────────────────────────
    std::string to_string() const;

private:
    // ── İç veri yapıları ──────────────────────────────────────────────────
    Piece    mailbox_[BOARD_SIZE];   // Her karede hangi taş
    Square   king_sq_[2];            // Şahların konumu [WHITE][BLACK]

    // Parça listeleri: piece_list_[renk][tip] → o taşın bulunduğu kareler
    // Max: 2 kale, 2 zürafa... ama terfi ile artabilir. 32 yeterli.
    std::vector<Square> piece_list_[2][PIECE_TYPE_NB];

    Color      stm_;        // Sıra kimin
    int        fullmove_;   // Hamle sayısı (tam hamle)
    const NNUENetwork* nnue_net_ = nullptr; // Artımlı NNUE güncellemesi için

    // StateInfo linked list (stack yerine dizi kullanılabilir — search.h'de)
    StateInfo  st_buf_[256]; // Arama için yeterli buffer
    StateInfo* st_;
    int        st_idx_;

    // ── İç yardımcılar ────────────────────────────────────────────────────
    void put_piece   (Piece p, Square sq);
    void remove_piece(Square sq);
    void move_piece  (Square from, Square to);
    void update_hash_piece(Square sq, Piece p);

    // Saldırı hesabı — her taş tipi için ayrı (movegen.h ile paylaşılır)
    bool attacked_by_sah   (Square sq, Color by) const;
    bool attacked_by_kale  (Square sq, Color by) const;
    bool attacked_by_zurafa(Square sq, Color by) const;
    bool attacked_by_talia (Square sq, Color by) const;
    bool attacked_by_at    (Square sq, Color by) const;
    bool attacked_by_deve  (Square sq, Color by) const;
    bool attacked_by_fil   (Square sq, Color by) const;
    bool attacked_by_savas (Square sq, Color by) const;
    bool attacked_by_ferz  (Square sq, Color by) const;
    bool attacked_by_vali  (Square sq, Color by) const;
    bool attacked_by_piyon (Square sq, Color by) const;
};

// ─────────────────────────────────────────────────────────────────────────────
//  Başlangıç dizilişi (tarihsel — Timurlenk kurallarına göre)
//
//  Satır 0 (Beyaz alt sıra, rank=0):
//    Fil  ·  Deve  ·  SavaşM  ·  SavaşM  ·  Deve  ·  Fil
//    B  .  C    .   W     .    W     .   C    .   B
//
//  Satır 1 (Beyaz ana sıra, rank=1):
//    Kale-At-Talia-Zürafa-Ferz-Şah-Vali-Zürafa-Talia-At-Kale
//    R    N   T     Z      F    K   V    Z      T     N   R
//
//  Satır 2 (Beyaz piyonlar, rank=2):
//    P P P P P P P P P P P  (11 piyon — çift adım yok!)
//
//  Siyah: rank 9, 8, 7 — yansıtılmış
//    Siyah rank=9: Fil . Deve . SM . SM . Deve . Fil
//    Siyah rank=8: Kale-At-Talia-Zürafa-Vali-Şah-Ferz-Zürafa-Talia-At-Kale
//    (Ferz ve Vali siyahta simetrik olarak yer değiştirmiştir)
//
//  Citadel konumları:
//    WHITE_CITADEL (110): rank=1, file=11 (k sütununun sağında)
//      → Siyah şah buraya girerse beraberlik
//    BLACK_CITADEL (111): rank=8, file=-1 (a sütununun solunda)
//      → Beyaz şah buraya girerse beraberlik
// ─────────────────────────────────────────────────────────────────────────────

// Başlangıç dizilişi sabitleri (board.cpp'de setup() içinde kullanılır)
constexpr PieceType START_RANK0[BOARD_FILES] = {
    FIL, NO_PIECE_TYPE, DEVE, NO_PIECE_TYPE, SAVAS,
    NO_PIECE_TYPE,
    SAVAS, NO_PIECE_TYPE, DEVE, NO_PIECE_TYPE, FIL
};
constexpr PieceType START_RANK1_WHITE[BOARD_FILES] = {
    KALE, AT, TALIA, ZURAFA, FERZ, SAH, VALI, ZURAFA, TALIA, AT, KALE
};
// Siyah rank=8: Ferz ve Vali yer değiştirmiş (tarihsel asimetri)
constexpr PieceType START_RANK1_BLACK[BOARD_FILES] = {
    KALE, AT, TALIA, ZURAFA, VALI, SAH, FERZ, ZURAFA, TALIA, AT, KALE
};

} // namespace Apex
