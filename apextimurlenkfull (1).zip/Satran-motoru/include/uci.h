#pragma once
#include "types.h"
#include "board.h"
#include "search.h"
#include "tt.h"
#include "persona.h"
#include "commentary.h"
#include "book.h"
#include <string>
#include <sstream>
#include <thread>
#include <memory>
#include <vector>

namespace Apex {

// ─────────────────────────────────────────────────────────────────────────────
//  UCI (Universal Chess Interface) Protokol Arayüzü
//
//  Apex Timurlenk motoru standart UCI protokolüyle iletişim kurar.
//  Bu sayede Arena, Cute Chess, BankSiaQ gibi tüm GUI'larda çalışır.
//
//  Desteklenen komutlar:
//    uci            → motor kimliğini ve seçenekleri bildir
//    isready        → hazır olduğunda "readyok" yaz
//    ucinewgame     → yeni oyun, TT temizle
//    position       → pozisyonu kur (startpos veya fen)
//    go             → aramayı başlat
//    stop           → aramayı durdur
//    quit           → motoru kapat
//    setoption      → ayar değiştir
//    ponderhit      → ponder pozisyonu gerçekleşti
//    d              → tahtayı debug modda göster (standart olmayan ama yaygın)
//    eval           → statik değerlendirmeyi göster (debug)
//
//  Motor seçenekleri (setoption name X value Y):
//    Hash           → TT boyutu (MB, varsayılan: 64)
//    Threads        → İş parçacığı sayısı (varsayılan: 1, max: 128)
//    Contempt       → Beraberlik beklentisi cp cinsinden (varsayılan: 0)
//    SyzygyPath     → Syzygy tablebase dizin yolu
//    Ponder         → Ponder modu (varsayılan: false)
//    MultiPV        → Kaç hamle raporlansın (varsayılan: 1, max: 10)
//    MoveOverhead   → GUI iletişim gecikmesi ms (varsayılan: 30)
//    UCI_Chess960   → Chess960 modu (Timurlenk için kullanılmaz)
//
//  Timurlenk'e özgü seçenekler:
//    CitadelDraw    → Citadel girişi beraberlik sayılsın mı (varsayılan: true)
//    SwapAllowed    → Yer değiştirme hakkı aktif mi (varsayılan: true)
//    PieceNames     → Taş isim formatı: "tr" / "en" (varsayılan: "tr")
// ─────────────────────────────────────────────────────────────────────────────

// Motor sürüm bilgisi
constexpr const char* ENGINE_NAME    = "Apex Timurlenk";
constexpr const char* ENGINE_VERSION = "1.4.0-sprint18";
constexpr const char* ENGINE_AUTHOR  = "Apex Development Team";

// ─────────────────────────────────────────────────────────────────────────────
//  Motor Seçenekleri
// ─────────────────────────────────────────────────────────────────────────────
struct EngineOptions {
    int  hash_mb        = 64;
    int  threads        = 1;
    int  contempt       = 0;
    int  multi_pv       = 1;
    int  move_overhead  = 30;  // ms
    bool ponder         = false;
    bool citadel_draw   = true;
    bool swap_allowed   = true;
    std::string syzygy_path = "";
    std::string piece_names = "tr"; // "tr" veya "en"
    // L1.5 Persona Katmanı
    PersonaLayer persona;
    // Needle commentary bridge
    bool        use_needle      = false;
    std::string needle_script   = "";   // needle_bridge.py yolu
    // NNUE
    bool        use_nnue        = false;
    std::string nnue_path       = "networks/apex_v1.bin";
    // Açılış Kitabı
    bool        own_book        = true;
    std::string book_path       = "networks/timurlenk_openings.bin";
};

// ─────────────────────────────────────────────────────────────────────────────
//  Timurlenk FEN Formatı
//
//  Standart satranç FEN'ini Timurlenk'e genişletiyoruz:
//
//  <pozisyon> <sıra> <ek-bayraklar> <yarım-hamle> <tam-hamle>
//
//  Pozisyon: rank 9'dan rank 0'a, '/' ile ayrılmış 10 satır
//    + iki citadel durumu köşeli parantez içinde
//  Taş harfleri: K R Z T N C E W F V P (büyük=beyaz, küçük=siyah)
//  Boş kareler: sayı (1-11)
//  Citadel: [wc] beyaz citadel doluysa (olamaz normalde),
//            [bc] siyah citadel doluysa
//
//  Ek bayraklar: s veya - (swap hakkı: 'w' beyaz kullandı, 'b' siyah kullandı)
//    Örn: "-"=her iki taraf hakkını kullanmadı
//         "w"=beyaz kullandı  "b"=siyah kullandı  "wb"=her ikisi kullandı
//
//  Başlangıç FEN:
//    "e.c.w.w.c.e/RRRRRRRRRRR/PPPPPPPPPPP/11/11/11/11/ppppppppppp/rrrrrrrrrrr/E.C.W.W.C.E
//     KR1ZF1VZR1K/11/...
//
//  NOT: Gerçek başlangıç FEN'i board.cpp setup() fonksiyonunda tanımlanır.
//       Bu format gelecekteki pozisyon yükleyici için rezerve edilmiştir.
// ─────────────────────────────────────────────────────────────────────────────

// ─────────────────────────────────────────────────────────────────────────────
//  UCI Arayüz Sınıfı
// ─────────────────────────────────────────────────────────────────────────────
class UCI {
public:
    UCI();
    ~UCI();

    // Ana döngü — stdin'den komut okur, stdout'a yazar
    void loop();

    // Tekil komut işle (test için)
    void process(const std::string& line);

private:
    Board               board_;
    TranspositionTable  tt_;
    Searcher            searcher_;
    EngineOptions       opts_;
    CommentaryBridge    commentary_;
    OpeningBook         book_;
    std::thread         search_thread_;
    bool                searching_  = false;
    bool                quit_       = false;
    std::vector<StateInfo> move_history_; // position komutundaki hamle geçmişi

    // ── Komut İşleyiciler ─────────────────────────────────────────────────
    void cmd_uci();
    void cmd_isready();
    void cmd_ucinewgame();
    void cmd_position(std::istringstream& ss);
    void cmd_go       (std::istringstream& ss);
    void cmd_stop();
    void cmd_quit();
    void cmd_setoption(std::istringstream& ss);
    void cmd_ponderhit();
    void cmd_debug_board();
    void cmd_debug_eval();
    void cmd_debug_moves();
    void cmd_debug_hash();                   // Zobrist hash değerini stdout'a yaz
    void cmd_perft(std::istringstream& ss);  // Hamle üreteci doğrulama

    // ── UCI Çıktı Oluşturucular ───────────────────────────────────────────

    // info depth X seldepth Y score cp Z nodes N nps N pv ...
    void print_info(int depth, int sel_depth, i32 score,
                    u64 nodes, int64_t ms, const PVLine& pv,
                    int multi_pv_idx = 0);

    // bestmove X ponder Y
    void print_bestmove(Move best, Move ponder);

    // ── Hamle Formatı ─────────────────────────────────────────────────────
    // Timurlenk koordinat sistemi:
    //   file: a-k (0-10), rank: 1-10 (rank 0 = "1")
    //   Normal: "e5f7", Terfi: "a9b10=Z" (Zürafa'ya terfi)
    //   Swap: "swap:e1g1" (şah e1'den g1'deki taşla yer değiştirir)
    //   Citadel beyaz: "k2-wc" (k2'den beyaz citadel'e)
    //   Citadel siyah: "a9-bc"
    static std::string move_to_str(Move m, PieceType promo = NO_PIECE_TYPE);
    static Move        str_to_move(const std::string& s, const Board& b);
    static std::string sq_to_str  (Square sq);
    static Square      str_to_sq  (const std::string& s);

    // ── Perft (hamle üreteci test) ────────────────────────────────────────
    u64 perft(int depth);

    // ── Yardımcılar ───────────────────────────────────────────────────────
    void apply_options();  // opts_ değiştiğinde motoru güncelle
    void wait_search_done();
};

// ─────────────────────────────────────────────────────────────────────────────
//  UCI Hamle Koordinat Sistemi (Referans)
//
//  Timurlenk 11×10 tahta koordinatları:
//
//    Sütunlar (file): a=0, b=1, c=2, d=3, e=4, f=5, g=6, h=7, i=8, j=9, k=10
//    Satırlar (rank): 1=rank0, 2=rank1, ..., 10=rank9
//
//    Kare indeksi: sq = (rank-1)*11 + file_index
//      Örn: e5 → file=4, rank=4 → sq = 4*11+4 = 48
//           k2 → file=10, rank=1 → sq = 1*11+10 = 21
//
//    Citadel kareleri:
//      "wc" → WHITE_CITADEL (110) — beyazın rakip kalesine giriş noktası
//      "bc" → BLACK_CITADEL (111) — siyahın rakip kalesine giriş noktası
//
//    Citadel komşusu:
//      WHITE_CITADEL ↔ k2 (sq=21): Siyah şah k2'deyken "wc"ye girebilir
//      BLACK_CITADEL ↔ a9 (sq=88): Beyaz şah a9'dayken "bc"ye girebilir
//
//  Hamle örnekleri:
//    "e1f3"     → e1'den f3'e normal hamle
//    "a9bc"     → beyaz şah a9'dan siyah citadel'e (beraberlik hamlesi)
//    "k2wc"     → siyah şah k2'den beyaz citadel'e (beraberlik hamlesi)
//    "b9b10=K"  → b9'dan b10'a piyon hamlesi, Kale'ye terfi
//    "swap e1h4" → şah e1'deki taşla h4'tekini yer değiştirir
// ─────────────────────────────────────────────────────────────────────────────

} // namespace Apex
