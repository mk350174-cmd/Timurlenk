#pragma once
#include "types.h"
#include "board.h"
#include "tt.h"
#include "nnue.h"

namespace Apex {

// ─────────────────────────────────────────────────────────────────────────────
//  Piece-Square Tables (PST)
//  Her taş tipi için 11×10 = 110 kare pozisyon değer tablosu.
//  2 faz: middlegame (mg) ve endgame (eg).
//  Siyah için tablo dikey yansıtılır (rank = 9 - rank).
//
//  Değerler centipawn (cp) cinsinden, materyal değerine ek olarak.
// ─────────────────────────────────────────────────────────────────────────────
struct PSTTable {
    i16 mg[BOARD_NORMAL]; // middlegame — indeks: rank*11+file (beyaz perspektifi)
    i16 eg[BOARD_NORMAL]; // endgame
};

// 11 taş tipi için PST tabloları (evaluate.cpp'de tanımlanır)
extern PSTTable PST[PIECE_TYPE_NB];

// PST'yi başlat
void init_pst();

// ─────────────────────────────────────────────────────────────────────────────
//  Oyun Fazı Hesabı
//  Materyale göre [0.0, 1.0] arası faz değeri.
//  1.0 = tam middlegame, 0.0 = tam endgame.
// ─────────────────────────────────────────────────────────────────────────────
// Faz katkısı — şah ve piyon faza dahil değil
constexpr i32 PHASE_WEIGHT[PIECE_TYPE_NB] = {
    0, 0,   // NO_PIECE, SAH
    4,      // KALE
    4,      // ZURAFA
    3,      // TALIA
    3,      // AT
    3,      // DEVE
    2,      // FIL
    2,      // SAVAS
    1,      // FERZ
    1,      // VALI
    0       // PIYON
};
// Her iki tarafta tam materyal: 2×(4+4+3+3+3+2+2+1+1) × 2 taraf = 96
constexpr i32 MAX_PHASE = 96;

// ─────────────────────────────────────────────────────────────────────────────
//  Kral Güvenliği Tablosu
//  Şahın yakınındaki saldırıcı sayısına ve güçlerine göre ceza.
// ─────────────────────────────────────────────────────────────────────────────
constexpr i32 KING_ATTACK_WEIGHT[PIECE_TYPE_NB] = {
    0, 0,  // NO_PIECE, SAH (şah şahı tehdit edemez arama sırasında)
    4,     // KALE
    5,     // ZURAFA
    2,     // TALIA
    2,     // AT
    2,     // DEVE
    2,     // FIL
    2,     // SAVAS
    1,     // FERZ
    1,     // VALI
    0      // PIYON
};

// Saldırı sayısına göre ceza tablosu (0–31 arası saldırı skoru)
extern i32 KING_SAFETY_TABLE[64];

// ─────────────────────────────────────────────────────────────────────────────
//  Değerlendirme Bonusları ve Cezaları
// ─────────────────────────────────────────────────────────────────────────────

// Mobilite bonusu: [taş tipi][hamle sayısı] — ortalama hareketlilik üstü bonus
// Maksimum hamle sayısı yaklaşık değerler:
//   Kale: ~20, Zürafa: ~30, Talia: ~4, At: ~8, Deve: ~8, Fil: ~4
//   SavaşM: ~4, Ferz: ~4, Vali: ~4
constexpr i32 MOBILITY_BONUS_MG[PIECE_TYPE_NB][32] = {
    {}, // NO_PIECE_TYPE
    {}, // SAH — ayrı hesaplanır
    // KALE: 0–20 hamle arası
    { -20,-15,-10,-5,0,3,6,9,11,13,15,16,17,18,19,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20 },
    // ZURAFA: 0–30 hamle arası (çok mobil)
    { -25,-20,-15,-10,-5,0,4,8,11,14,17,19,21,23,24,25,26,27,27,28,28,29,29,29,30,30,30,30,30,30,30,30 },
    // TALIA: 0–4 hamle arası
    { -10,-5,0,5,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10 },
    // AT: 0–8 hamle arası
    { -25,-15,-5,5,12,17,20,23,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25 },
    // DEVE: 0–8 hamle arası
    { -20,-12,-4,4,10,15,18,21,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23 },
    // FİL: 0–4 hamle arası (renk bağımlı, sınırlı)
    { -15,-5,5,10,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15 },
    // SAVAŞ MAKİNESİ: 0–4 hamle arası
    { -15,-5,3,8,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12 },
    // FERZ: 0–4 hamle arası
    { -8,-3,2,6,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9 },
    // VALİ: 0–4 hamle arası
    { -8,-3,2,5,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8 },
    {}, // PİYON — ayrı hesaplanır
};

constexpr i32 MOBILITY_BONUS_EG[PIECE_TYPE_NB][32] = {
    {}, {},
    { -18,-13,-8,-3,2,5,8,10,12,14,15,16,17,17,18,18,18,18,18,18,18,18,18,18,18,18,18,18,18,18,18,18 },
    { -20,-15,-10,-5,0,4,8,11,14,16,18,20,21,22,23,24,24,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25 },
    { -8,-3,3,8,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12 },
    { -20,-12,-4,4,10,14,17,19,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21 },
    { -18,-10,-3,4,9,13,16,18,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20 },
    { -12,-4,4,9,13,13,13,13,13,13,13,13,13,13,13,13,13,13,13,13,13,13,13,13,13,13,13,13,13,13,13,13 },
    { -12,-4,3,7,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10 },
    { -6,-2,3,6,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8 },
    { -6,-2,2,5,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7 },
    {},
};

// Çıplak şah cezası (bare king — tek başına kalan şah)
constexpr i32 BARE_KING_PENALTY_MG = 600;
constexpr i32 BARE_KING_PENALTY_EG = 900;

// Piyon yapısı
constexpr i32 PASSED_PAWN_BONUS[10] = { 0,10,15,25,40,60,85,120,160,0 }; // rank bazında
constexpr i32 DOUBLED_PAWN_PENALTY  = -20;
constexpr i32 ISOLATED_PAWN_PENALTY = -15;
constexpr i32 BACKWARD_PAWN_PENALTY = -10;

// Parça koordinasyonu
constexpr i32 BISHOP_PAIR_BONUS       = 30; // 2+ fil varsa
constexpr i32 ROOK_OPEN_FILE_BONUS    = 20; // Kale açık dosyada
constexpr i32 ROOK_SEMI_OPEN_BONUS    = 10; // Kale yarı açık dosyada
constexpr i32 KING_SHELTER_PENALTY    = -18; // Her eksik piyon kalkanı başına
constexpr i32 OUTPOST_BONUS           = 25; // At/Fil rakip piyon kontrolünde değil
constexpr i32 OUTPOST_SUPPORTED_BONUS = 12; // + kendi piyonu destekliyorsa

// Citadel tehdidi bonusu (şah citadel'e yaklaşınca)
constexpr i32 CITADEL_THREAT_BONUS = 30; // 2 kare uzakta
constexpr i32 CITADEL_ADJACENT_BONUS = 60; // 1 kare uzakta

// Tempo: hamle sırası avantajı
constexpr i32 TEMPO_BONUS = 8;

// Kale bağlantısı: iki kale aynı dosya/satırda, aralarında taş yok
constexpr i32 ROOK_CONNECTIVITY_BONUS = 15;

// ─────────────────────────────────────────────────────────────────────────────
//  Persona Ağırlık Çarpanları
//  Her persona için materyal değerlendirme çarpanları.
//  1.0 = varsayılan, >1.0 = güçlendir, <1.0 = zayıflat.
// ─────────────────────────────────────────────────────────────────────────────
struct PersonaWeights {
    float rook_mult        = 1.0f;
    float pawn_mult        = 1.0f;
    float knight_mult      = 1.0f;
    float king_safety_mult = 1.0f;
};

// ─────────────────────────────────────────────────────────────────────────────
//  Evaluator
// ─────────────────────────────────────────────────────────────────────────────
class Evaluator {
public:
    Evaluator() : pawn_table_() {}

    // Persona ağırlık çarpanlarını ayarla (idx: PersonaType int değeri)
    void setPersona(int idx);

    // NNUE yükle — başarılıysa true
    bool load_nnue(const std::string& path) { return nnue_.load(path); }
    bool nnue_loaded() const { return nnue_.loaded(); }
    void set_use_nnue(bool v) { use_nnue_ = v; }
    bool use_nnue() const { return use_nnue_ && nnue_.loaded(); }
    const NNUENetwork* get_nnue_ptr() const { return &nnue_; }

    // Ana değerlendirme fonksiyonu
    // side: değerlendirmeyi kimin perspektifinden yapacağız (+iyi = side iyi)
    i32 evaluate(const Board& b, Color side);

    // Statik değerlendirme (quiescence için hızlı versiyon)
    static i32 evaluate_fast(const Board& b, Color side);

private:
    PawnTable      pawn_table_;
    NNUENetwork    nnue_;
    bool           use_nnue_ = false;
    PersonaWeights pw_;         // Persona çarpanları

    // Alt fonksiyonlar
    i32 eval_material (const Board& b) const;
    i32 eval_pst      (const Board& b, Color c, int phase) const;
    i32 eval_mobility (const Board& b, Color c, int phase) const;
    i32 eval_king_safety(const Board& b, Color c, int phase) const;
    i32 eval_pawn_structure(const Board& b, Color c);
    i32 eval_citadel  (const Board& b, Color c, int phase) const;

    // Tahmini oyun fazı [0=endgame .. MAX_PHASE=middlegame]
    static int game_phase(const Board& b);

    // Taraf perspektifine göre PST değeri
    static i32 pst_value(PieceType pt, Square sq, Color c, int phase);
};

} // namespace Apex
