#pragma once
#include "types.h"
#include "board.h"
#include "tt.h"
#include "movegen.h"
#include "evaluate.h"
#include "persona.h"
#include <atomic>
#include <chrono>
#include <functional>
#include <thread>
#include <vector>

namespace Apex {

// ─────────────────────────────────────────────────────────────────────────────
//  Zaman Yönetimi
// ─────────────────────────────────────────────────────────────────────────────
struct TimeManager {
    using Clock = std::chrono::steady_clock;
    using Ms    = std::chrono::milliseconds;

    Clock::time_point start;
    int64_t  hard_limit_ms = 0;  // Kesinlikle bu süre aşılamaz
    int64_t  soft_limit_ms = 0;  // İdeal hedef (iterasyon tamamlandıktan sonra dur)
    bool     infinite      = false;

    void init(int64_t wtime, int64_t btime, int64_t winc, int64_t binc,
              int movestogo, Color stm);
    void init_movetime(int64_t ms) { hard_limit_ms = ms; soft_limit_ms = ms * 9 / 10; }
    void init_infinite()           { infinite = true; }

    int64_t elapsed_ms() const {
        return std::chrono::duration_cast<Ms>(Clock::now() - start).count();
    }
    bool soft_expired() const { return !infinite && elapsed_ms() >= soft_limit_ms; }
    bool hard_expired() const { return !infinite && elapsed_ms() >= hard_limit_ms; }
};

// ─────────────────────────────────────────────────────────────────────────────
//  Arama Sınırları (UCI'dan gelir)
// ─────────────────────────────────────────────────────────────────────────────
struct SearchLimits {
    int64_t wtime    = 0;
    int64_t btime    = 0;
    int64_t winc     = 0;
    int64_t binc     = 0;
    int     movestogo = 0;
    int64_t movetime  = 0;
    int     depth     = MAX_PLY;
    int64_t nodes     = 0;
    bool    infinite  = false;
    bool    ponder    = false;
};

// ─────────────────────────────────────────────────────────────────────────────
//  Arama İstatistikleri
// ─────────────────────────────────────────────────────────────────────────────
struct SearchStats {
    u64 nodes        = 0;  // Ziyaret edilen toplam düğüm
    u64 qnodes       = 0;  // Quiescence düğümleri
    u64 tt_hits      = 0;  // TT isabeti
    u64 tt_cuts      = 0;  // TT'den beta kesimi
    u64 null_cuts    = 0;  // Null move beta kesimi
    u64 lmr_count    = 0;  // LMR uygulamaları
    u64 singular_ext = 0;  // Singular extension uygulamaları
    int sel_depth    = 0;  // Seçici derinlik (quiescence dahil)

    void reset() { *this = {}; }
};

// ─────────────────────────────────────────────────────────────────────────────
//  Arama Stack çerçevesi (her derinlik için)
// ─────────────────────────────────────────────────────────────────────────────
struct SearchFrame {
    StateInfo  state;           // do_move için StateInfo (heap alloc yok)
    Move       current_move;    // Bu derinlikte denenen hamle
    Move       excluded_move;   // Singular extension — dışlanan hamle
    i32        static_eval;     // Bu pozisyonun statik değerlendirmesi
    int        ply;             // Kök'ten uzaklık
    bool       in_check;        // Şah altında mı
    bool       tt_pv;           // TT'den PV hattında mıyız
};

// ─────────────────────────────────────────────────────────────────────────────
//  PV (Principal Variation) — en iyi hamle dizisi
// ─────────────────────────────────────────────────────────────────────────────
struct PVLine {
    Move moves[MAX_PLY];
    int  length = 0;

    void clear()              { length = 0; }
    void push(Move m)         { if (length < MAX_PLY) moves[length++] = m; }
    Move best() const         { return length > 0 ? moves[0] : MOVE_NONE; }
    void copy_from(Move m, const PVLine& child) {
        moves[0] = m;
        for (int i = 0; i < child.length; i++) moves[i+1] = child.moves[i];
        length = child.length + 1;
    }
};

// ─────────────────────────────────────────────────────────────────────────────
//  LMR (Late Move Reductions) Tablosu
//  lmr_table[depth][move_index] → azaltma miktarı
//  Formül: max(0, floor(ln(depth) * ln(moves) / 2.0 - 0.5))
// ─────────────────────────────────────────────────────────────────────────────
extern int LMR_TABLE[MAX_PLY][MAX_MOVES];
void init_lmr_table();

// ─────────────────────────────────────────────────────────────────────────────
//  Searcher — Ana Arama Motoru
//
//  Timurlenk için adapte edilmiş APEX arama algoritması:
//
//  1. Iterative Deepening + Aspiration Windows
//  2. Alpha-Beta Negamax (fail-soft)
//  3. Transposition Table entegrasyonu
//  4. Null Move Pruning (NMP)
//  5. Late Move Reductions (LMR) — dinamik azaltma
//  6. Singular Extensions
//  7. Futility Pruning
//  8. Razoring
//  9. Probcut
// 10. Quiescence Search (yemeler + terfi)
// 11. Lazy SMP (çok çekirdek) — thread pool üzerinden
// 12. Citadel farkındalığı — beraberlik hamlelerini doğru skorla
// ─────────────────────────────────────────────────────────────────────────────
class Searcher {
public:
    Searcher(Board& board, TranspositionTable& tt);

    // Ana arama — UCI'dan çağrılır
    void start_search(const SearchLimits& limits);

    // Thread sayısını ayarla (Lazy SMP)
    void set_threads(int n) { n_threads_ = std::max(1, n); }

    // Aramayı durdur (UCI stop)
    void stop() { stopped_.store(true); }

    // Ponder pozisyon gerçekleşti — zaman yönetimini aktif et
    void ponderhit();

    // Persona katmanını güncelle
    void set_persona(const PersonaLayer& p) { persona_ = p; }

    // Sonuç erişimi
    Move  best_move()  const { return best_move_; }
    Move  ponder_move() const { return ponder_move_; }
    i32   best_score() const { return best_score_; }

    // UCI info callback (her iterasyon sonrası çağrılır)
    using InfoCallback = std::function<void(int depth, int sel_depth,
                                            i32 score, u64 nodes,
                                            int64_t ms, const PVLine&)>;
    void set_info_callback(InfoCallback cb) { info_cb_ = cb; }

    // Needle commentary callback — persona adı, skor, derinlik ile çağrılır
    using NeedleCallback = std::function<void(const std::string& persona,
                                              int score, int depth)>;
    void set_needle_callback(NeedleCallback cb) { needle_cb_ = cb; }

    // Zaman yönetimi kararı callback — async, sonuç "spend_more"|"normal"|"spend_less"
    using TimeAdjCallback = std::function<void(
        const std::string& persona,
        int phase_score,
        int material_balance,
        std::function<void(const std::string&)> result_cb)>;
    void set_time_adj_callback(TimeAdjCallback cb) { time_adj_cb_ = cb; }

    // Açılış stili kararı — "aggressive"|"solid"|"gambit"
    using OpeningCb = std::function<void(
        const std::string& persona, int move_num, bool is_white,
        std::function<void(const std::string&)> result_cb)>;
    void set_opening_callback(OpeningCb cb) { opening_cb_ = cb; }

    // Citadel strateji kararı — "rush_citadel"|"consolidate"|"ignore"
    using CitadelCb = std::function<void(
        const std::string& persona, int phase, int king_dist, int material,
        std::function<void(const std::string&)> result_cb)>;
    void set_citadel_callback(CitadelCb cb) { citadel_cb_ = cb; }

    // Dinamik contempt kararı — "raise"|"hold"|"lower"
    using ContemptCb = std::function<void(
        const std::string& persona, int score_trend, int move_num,
        std::function<void(const std::string&)> result_cb)>;
    void set_contempt_callback(ContemptCb cb) { contempt_cb_ = cb; }

    // Tekrar tablosu temizle (yeni oyun)
    void new_game();

    // Statik değerlendirme (test için)
    i32 static_eval(const Board& b);

    // NNUE erişimi (UCI setoption için)
    Evaluator& evaluator() { return evaluator_; }

private:
    Board&              board_;
    TranspositionTable& tt_;
    MoveOrderer         orderer_;
    Evaluator           evaluator_;
    TimeManager         tm_;
    SearchStats         stats_;
    SearchFrame         stack_[MAX_PLY + 4]; // +4 sentinel
    // CMH: [taş_tipi][hedef_kare] — önceki hamlenin bağlamında sakin hamle skoru
    // MAX_PLY bağımsız tablo yerine taş×kare matrisi (basit 1-ply CMH)
    i32                 cont_hist_[PIECE_TYPE_NB][BOARD_SIZE];
    PVLine              root_pv_;
    Move                best_move_;
    Move                ponder_move_;
    i32                 best_score_;
    std::atomic<bool>   stopped_;
    InfoCallback        info_cb_;
    NeedleCallback      needle_cb_;
    TimeAdjCallback     time_adj_cb_;
    std::atomic<int>    time_adj_{0};  // 0=normal, 1=spend_more, -1=spend_less
    OpeningCb           opening_cb_;
    CitadelCb           citadel_cb_;
    ContemptCb          contempt_cb_;
    std::atomic<int>    opening_adj_{0};      // 0=solid/none, 1=aggressive, 2=gambit
    std::atomic<int>    citadel_adj_{0};      // 0=hold, 1=rush, -1=ignore
    std::atomic<int>    contempt_pending_{0}; // 0=hold, 1=raise, -1=lower
    i32                 citadel_bias_ = 0;    // citadel_score() içinde kullanılır
    PersonaLayer        persona_;

    // ── Iterative Deepening ───────────────────────────────────────────────
    void iterative_deepening(int max_depth);

    // ── Alpha-Beta (Negamax, fail-soft) ──────────────────────────────────
    // pv_node:    PV düğümü mü (alpha < beta-1)
    // cut_node:   kesim düğümü beklentisi
    i32 search(int depth, i32 alpha, i32 beta, int ply,
               bool pv_node, bool cut_node, PVLine* pv_line = nullptr);

    // ── Quiescence Search ─────────────────────────────────────────────────
    i32 qsearch(i32 alpha, i32 beta, int ply);

    // ── Budama ve Azaltma Kararları ───────────────────────────────────────

    // Razoring: çok düşük derinlikte statik eval yeterliyse
    bool try_razoring(int depth, i32 alpha, i32 static_eval,
                      bool in_check, i32& score);

    // Null Move Pruning
    bool try_null_move(int depth, i32 beta, i32 static_eval,
                       bool in_check, bool pv_node, int ply, i32& score);

    // Probcut: yüksek beta kenarında erken kesim
    bool try_probcut(int depth, i32 beta, bool in_check, int ply,
                     i32 static_eval, i32& score);

    // LMR azaltma miktarı
    int lmr_reduction(int depth, int move_idx, bool pv_node,
                      bool gives_check, bool is_capture) const;

    // Singular Extension kontrolü
    bool is_singular(Move m, int depth, i32 tt_score, int ply);
    i32  is_singular_score(Move m, int depth, i32 tt_score, int ply);

    // ── Timurlenk'e özgü kontroller ──────────────────────────────────────

    // Citadel hamlesi skoru: beraberlik = 0 (contempt ve citadel_bias ile ayarlanabilir)
    i32 citadel_score() const { return SCORE_DRAW + contempt_ + citadel_bias_; }

    // Bare king cezası (bir tarafın şah dışında taşı kalmadı)
    bool is_bare_king(Color c) const;

    // ── Yardımcılar ───────────────────────────────────────────────────────
    bool time_check();           // Zaman doldu mu (her 1024 düğümde kontrol)
    void update_stats(int depth, Move best, i32 best_score,
                      i32 alpha, i32 beta, int ply,
                      const MoveList& tried_quiets,
                      const MoveList& tried_captures);

    i32 contempt_ = 0;  // Beraberlik için beklenti ayarı (+ = beraberlikten kaçın)
    u64 node_limit_ = 0;
    bool pondering_  = false;

    // ── Lazy SMP ─────────────────────────────────────────────────────────────
    int                        n_threads_ = 1;
    std::vector<std::thread>   helpers_;
    std::atomic<bool>*         extern_stop_ = nullptr;  // Ana thread'in durdurma sinyali

    void run_as_helper(std::atomic<bool>& parent_stop, int max_depth);
};

// ─────────────────────────────────────────────────────────────────────────────
//  Alpha-Beta Algoritması — Pseudokod (dokümantasyon)
//
//  function search(depth, alpha, beta, ply, pv_node):
//
//    // 1. Terminal kontroller
//    if time_up or nodes_limit: return 0
//    if ply >= MAX_PLY: return evaluate()
//    if is_repetition or halfmove >= 100: return DRAW
//
//    // 2. Citadel kontrolü (Timurlenk özgün)
//    if citadel_reached: return DRAW (± contempt)
//
//    // 3. Transposition Table sorgusu
//    tt_entry = tt.probe(hash)
//    if tt_entry and tt_entry.depth >= depth:
//        if tt_entry.flag == EXACT: return tt_entry.score
//        if tt_entry.flag == LOWER: alpha = max(alpha, tt_entry.score)
//        if tt_entry.flag == UPPER: beta  = min(beta,  tt_entry.score)
//        if alpha >= beta: return tt_entry.score  // TT cut
//
//    // 4. Statik değerlendirme
//    in_check = board.in_check()
//    if not in_check:
//        static_eval = evaluate()
//        // Improving: bu pozisyon 2 hamle öncesinden iyi mi?
//        improving = static_eval > stack[ply-2].static_eval
//
//    // 5. Pruning (şah altında değilken)
//    if not pv_node and not in_check:
//        // 5a. Razoring (depth <= 3)
//        if depth <= 3 and static_eval + razor_margin[depth] <= alpha:
//            qscore = qsearch(alpha, beta)
//            if qscore <= alpha: return qscore
//
//        // 5b. Null Move Pruning
//        if depth >= 3 and static_eval >= beta and board.has_pieces():
//            R = 3 + depth/6 + min(3, (static_eval-beta)/200)
//            do_null_move()
//            score = -search(depth-R, -beta, -beta+1, ply+1, false, true)
//            undo_null_move()
//            if score >= beta: return beta (null cut)
//
//        // 5c. Probcut (depth >= 5)
//        if depth >= 5:
//            probcut_beta = beta + 200
//            for each capture with SEE >= probcut_beta - static_eval:
//                score = -search(depth-4, -probcut_beta, -probcut_beta+1, ...)
//                if score >= probcut_beta: return probcut_beta
//
//    // 6. Hamle döngüsü
//    generate_moves(ml)
//    order_moves(ml, tt_move, ply)
//    best_score = -INFINITE
//    tried_quiets = []
//
//    for i, move in enumerate(ml):
//        if move == excluded_move: continue
//
//        // Singular Extension
//        extension = 0
//        if move == tt_move and depth >= 8 and tt_score != NONE:
//            singular_beta = tt_score - depth
//            score = search(depth/2, singular_beta-1, singular_beta, ..., excluded=move)
//            if score < singular_beta: extension = 1   // Tekil hamle
//            elif singular_beta >= beta: return singular_beta  // Multi-cut
//
//        do_move(move)
//
//        // Late Move Reductions
//        if i >= 2 and depth >= 3 and not in_check and not gives_check:
//            R = lmr_table[depth][i]
//            R -= pv_node ? 1 : 0
//            R -= improving ? 1 : 0
//            R = max(1, R)
//            // LMR ile önce sığ ara
//            score = -search(depth-1-R, -alpha-1, -alpha, ply+1, false, true)
//            // Umut verirse tam derinlikte yeniden ara
//            if score > alpha:
//                score = -search(depth-1, -alpha-1, -alpha, ply+1, false, !cut_node)
//        else:
//            // Normal tam arama (ilk hamle veya erken hamleler)
//            score = -search(depth-1+extension, -beta, -alpha, ply+1, pv_node, false)
//
//        undo_move(move)
//
//        if score > best_score:
//            best_score = score
//            best_move  = move
//            if score > alpha:
//                alpha = score
//                if pv_node: update_pv(move)
//                if alpha >= beta:
//                    // Beta kesimi — güncelle
//                    update_stats(move, tried_quiets, depth, ply)
//                    break  // Budama
//
//    // 7. Mat / Pat / Beraberlik kontrolü
//    if best_score == -INFINITE:
//        if in_check: return -SCORE_MATE + ply  // Mat yedik
//        else:        return SCORE_DRAW          // Pat
//
//    // 8. TT'ye yaz
//    flag = best_score >= beta   ? TT_LOWER :
//           best_score <= alpha0 ? TT_UPPER : TT_EXACT
//    tt.store(hash, depth, flag, best_score, static_eval, best_move)
//
//    return best_score
// ─────────────────────────────────────────────────────────────────────────────

} // namespace Apex
