#include "board.h"
#include "movegen.h"
#include "evaluate.h"
#include "tt.h"
#include <iostream>
#include <cassert>

using namespace Apex;

static int pass_count = 0;
static int fail_count = 0;

#define TEST_ASSERT(cond, name) do { \
    if (cond) { std::cout << "[PASS] " << name << "\n"; pass_count++; } \
    else { std::cout << "[FAIL] " << name << "\n"; fail_count++; } \
} while(0)

void test_piyon_moves() {
    Board b; b.setup();
    // Piyon rank 2 (rank index 2) — her piyon 1 adım ileri gidebilir
    MoveList ml;
    Square pawn_sq = make_sq(0, 2); // a3 — beyaz piyon
    TEST_ASSERT(b.piece_on(pawn_sq) == W_PIYON, "Piyon: a3'te beyaz piyon var");
    MoveGenerator::gen_piyon(b, pawn_sq, WHITE, ml);
    TEST_ASSERT(ml.size() > 0, "Piyon: a3'teki piyon hamle üretildi");
}

void test_swap_generated() {
    Board b; b.setup();
    MoveList ml;
    MoveGenerator::gen_swap(b, WHITE, ml);
    // Başlangıçta swap hakkı var, şah altında değil → swap üretilmeli
    TEST_ASSERT(ml.size() > 0, "Swap: başlangıçta swap hamlesi üretildi");
    // Tüm hamleler MT_SWAP tipinde mi?
    bool all_swap = true;
    for (auto& me : ml)
        if (move_type(me.move) != MT_SWAP) { all_swap = false; break; }
    TEST_ASSERT(all_swap, "Swap: tüm üretilen hamleler MT_SWAP tipinde");
}

void test_swap_not_after_used() {
    Board b; b.setup();
    // Swap hamlesini yap
    MoveList ml;
    MoveGenerator::gen_swap(b, WHITE, ml);
    if (ml.size() > 0) {
        StateInfo si;
        b.do_move(ml.begin()->move, si);
        // Siyah hamlesi (null-like kontrolü için, sadece state kontrol et)
        TEST_ASSERT(si.swap_used[WHITE], "Swap: kullanıldıktan sonra swap_used=true");

        // Siyah tarafı: swap hakkı hala var
        MoveList ml2;
        MoveGenerator::gen_swap(b, BLACK, ml2);
        // Siyah henüz swap kullanmadı → swap üretilmeli
        // (Sıra siyahta artık)
        if (b.side_to_move() == BLACK) {
            TEST_ASSERT(true, "Swap: sıra siyaha geçti");
        }
    }
}

void test_kale_moves() {
    Board b; b.setup();
    // Başlangıçta kale kilitli (piyon önünde)
    MoveList ml;
    Square kale_sq = make_sq(0, 1); // a2 — beyaz kale
    TEST_ASSERT(b.piece_on(kale_sq) == W_KALE, "Kale: a2'de beyaz kale var");
    MoveGenerator::gen_kale(b, kale_sq, WHITE, ml);
    // Kale rank 1'de, rank 2'de piyon var → hareket edemez
    TEST_ASSERT(ml.size() == 0, "Kale: başlangıçta a2 kalesi hareket edemiyor");
}

void test_at_moves() {
    Board b; b.setup();
    // At rank 1'de
    Square at_sq = make_sq(1, 1); // b2 — beyaz at
    TEST_ASSERT(b.piece_on(at_sq) == W_AT, "At: b2'de beyaz at var");
    MoveList ml;
    MoveGenerator::gen_at(b, at_sq, WHITE, ml);
    // At L şekli: (1,2) veya (2,1) → b2'den c4 veya d3 gibi
    TEST_ASSERT(ml.size() > 0, "At: b2'deki at hamle üretildi");
}

void test_generate_pseudo_count() {
    Board b; b.setup();
    MoveList ml;
    MoveGenerator::generate_pseudo(b, ml);
    // Başlangıçta en az 30+ hamle beklenir (11 piyon + diğerleri)
    TEST_ASSERT(ml.size() >= 30, "Pseudo: başlangıçta 30+ hamle üretildi");
}

void test_generate_legal_vs_pseudo() {
    Board b; b.setup();
    MoveList pseudo_ml, legal_ml;
    MoveGenerator::generate_pseudo(b, pseudo_ml);
    MoveGenerator::generate_legal(b, legal_ml);
    // Legal ≤ pseudo
    TEST_ASSERT(legal_ml.size() <= pseudo_ml.size(),
                "Legal: legal hamle sayısı pseudo'dan fazla değil");
    TEST_ASSERT(legal_ml.size() > 0, "Legal: en az 1 yasal hamle var");
}

void test_capture_excludes_swap() {
    Board b; b.setup();
    MoveList ml;
    MoveGenerator::generate_captures(b, ml);
    // Başlangıçta yeme hamlesi yok (boş tahta ortası)
    // Swap hamlesi de capture listesinde olmamalı
    bool has_swap_in_captures = false;
    for (auto& me : ml)
        if (move_type(me.move) == MT_SWAP)
            has_swap_in_captures = true;
    TEST_ASSERT(!has_swap_in_captures, "Captures: swap hamlesi capture listesinde yok");
}

int main() {
    Zobrist.init();
    init_pst();

    std::cout << "=== MoveGen Test Suite ===\n\n";

    test_piyon_moves();
    test_swap_generated();
    test_swap_not_after_used();
    test_kale_moves();
    test_at_moves();
    test_generate_pseudo_count();
    test_generate_legal_vs_pseudo();
    test_capture_excludes_swap();

    std::cout << "\n=== Sonuç: " << pass_count << " geçti, "
              << fail_count << " başarısız ===\n";
    return fail_count > 0 ? 1 : 0;
}
