-- Apex Timurlenk — Supabase Şeması
-- Çalıştırma: Supabase SQL Editor > New Query > Yapıştır > Run

-- ─── Profil tablosu ──────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS profiles (
  id           UUID REFERENCES auth.users ON DELETE CASCADE PRIMARY KEY,
  username     TEXT UNIQUE NOT NULL,
  elo          INTEGER NOT NULL DEFAULT 1200,
  games_won    INTEGER NOT NULL DEFAULT 0,
  games_lost   INTEGER NOT NULL DEFAULT 0,
  games_draw   INTEGER NOT NULL DEFAULT 0,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Yeni kullanıcı kaydolunca otomatik profil oluştur
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
  INSERT INTO public.profiles (id, username)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'username', split_part(NEW.email, '@', 1))
  )
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE PROCEDURE public.handle_new_user();

-- ─── Oyun tablosu ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS games (
  id          UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  white_id    UUID REFERENCES profiles(id) ON DELETE SET NULL,
  black_id    UUID REFERENCES profiles(id) ON DELETE SET NULL,
  result      TEXT CHECK (result IN ('1-0', '0-1', '1/2-1/2', '*')) DEFAULT '*',
  pgn         TEXT,
  start_fen   TEXT DEFAULT 'startpos',
  time_control TEXT,                -- örn. "600+5" (10dk + 5s artış)
  white_elo   INTEGER,              -- oyun anındaki ELO (değişmez)
  black_elo   INTEGER,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  finished_at TIMESTAMPTZ
);

-- ─── Hamle tablosu (analiz için opsiyonel) ───────────────────────────────────
CREATE TABLE IF NOT EXISTS moves (
  id       BIGSERIAL PRIMARY KEY,
  game_id  UUID REFERENCES games(id) ON DELETE CASCADE NOT NULL,
  ply      INTEGER NOT NULL,        -- 1'den başlar (beyaz 1, siyah 2, ...)
  move     TEXT NOT NULL,           -- UCI formatı: "e2e4" veya "swap:e1g3"
  eval_cp  INTEGER,                 -- motor değerlendirmesi (centipawn)
  clock_ms INTEGER                  -- hamle sonrası kalan süre (ms)
);

CREATE INDEX IF NOT EXISTS moves_game_id_idx ON moves(game_id, ply);

-- ─── ELO güncelleme RPC ──────────────────────────────────────────────────────
-- Kullanım: SELECT update_elo('game-uuid-buraya');
CREATE OR REPLACE FUNCTION public.update_elo(p_game_id UUID)
RETURNS JSONB LANGUAGE plpgsql SECURITY DEFINER AS $$
DECLARE
  v_game   games%ROWTYPE;
  v_white  profiles%ROWTYPE;
  v_black  profiles%ROWTYPE;
  k        CONSTANT INTEGER := 32;
  expected FLOAT;
  score    FLOAT;
  delta    INTEGER;
  new_white_elo INTEGER;
  new_black_elo  INTEGER;
BEGIN
  SELECT * INTO v_game  FROM games    WHERE id = p_game_id;
  SELECT * INTO v_white FROM profiles WHERE id = v_game.white_id;
  SELECT * INTO v_black FROM profiles WHERE id = v_game.black_id;

  IF v_game.result = '*' OR v_white.id IS NULL OR v_black.id IS NULL THEN
    RETURN jsonb_build_object('error', 'Oyun bitmemiş veya oyuncu bulunamadı');
  END IF;

  expected := 1.0 / (1.0 + pow(10.0, (v_black.elo - v_white.elo) / 400.0));

  score := CASE v_game.result
    WHEN '1-0'     THEN 1.0
    WHEN '0-1'     THEN 0.0
    WHEN '1/2-1/2' THEN 0.5
    ELSE 0.5
  END;

  delta := ROUND(k * (score - expected));
  new_white_elo := GREATEST(100, v_white.elo + delta);
  new_black_elo  := GREATEST(100, v_black.elo  - delta);

  -- Profilleri güncelle
  UPDATE profiles SET
    elo        = new_white_elo,
    games_won  = games_won  + CASE WHEN v_game.result = '1-0' THEN 1 ELSE 0 END,
    games_lost = games_lost + CASE WHEN v_game.result = '0-1' THEN 1 ELSE 0 END,
    games_draw = games_draw + CASE WHEN v_game.result = '1/2-1/2' THEN 1 ELSE 0 END,
    updated_at = now()
  WHERE id = v_white.id;

  UPDATE profiles SET
    elo        = new_black_elo,
    games_won  = games_won  + CASE WHEN v_game.result = '0-1' THEN 1 ELSE 0 END,
    games_lost = games_lost + CASE WHEN v_game.result = '1-0' THEN 1 ELSE 0 END,
    games_draw = games_draw + CASE WHEN v_game.result = '1/2-1/2' THEN 1 ELSE 0 END,
    updated_at = now()
  WHERE id = v_black.id;

  RETURN jsonb_build_object(
    'white_old', v_white.elo,  'white_new', new_white_elo,
    'black_old', v_black.elo,  'black_new', new_black_elo,
    'delta', delta,            'result', v_game.result
  );
END;
$$;

-- ─── Row Level Security ───────────────────────────────────────────────────────
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE games    ENABLE ROW LEVEL SECURITY;
ALTER TABLE moves    ENABLE ROW LEVEL SECURITY;

-- Profil: herkes okuyabilir, sadece kendisi güncelleyebilir
CREATE POLICY "Profil okuma" ON profiles FOR SELECT USING (true);
CREATE POLICY "Profil güncelleme" ON profiles FOR UPDATE USING (auth.uid() = id);

-- Oyun: herkes okuyabilir, sadece katılımcılar yazabilir
CREATE POLICY "Oyun okuma" ON games FOR SELECT USING (true);
CREATE POLICY "Oyun oluşturma" ON games FOR INSERT
  WITH CHECK (auth.uid() = white_id OR auth.uid() = black_id);
CREATE POLICY "Oyun güncelleme" ON games FOR UPDATE
  USING (auth.uid() = white_id OR auth.uid() = black_id);

-- Hamle: oyun RLS ile bağlantılı
CREATE POLICY "Hamle okuma" ON moves FOR SELECT USING (true);
CREATE POLICY "Hamle ekleme" ON moves FOR INSERT
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM games g
      WHERE g.id = game_id
        AND (g.white_id = auth.uid() OR g.black_id = auth.uid())
    )
  );
