/**
 * apex_timur_worker.js — Apex Timurlenk Web Worker
 *
 * Ana iş parçacığından mesaj alır, motoru çalıştırır, sonuç döndürür.
 * start_search() bloklayıcı olduğu için Worker içinde çalışmalıdır.
 *
 * Kullanım (ana iş parçacığı):
 *   const engine = new ApexTimurlenkEngine();
 *   await engine.ready();
 *   await engine.newGame();
 *   const move = await engine.bestMove({ depth: 6 });
 */

// WASM modülünü yükle
importScripts('apex_timur.js');

let Module = null;
let ready = false;

// ── WASM C fonksiyon sarıcıları ──────────────────────────────────────────────
let api = {};

function initApi(M) {
    api.init          = M.cwrap('engine_init',           null,   ['number']);
    api.newGame       = M.cwrap('engine_new_game',        null,   []);
    api.setPosition   = M.cwrap('engine_set_position',    'number', ['string']);
    api.doMoves       = M.cwrap('engine_do_moves',        'number', ['string']);
    api.bestMove      = M.cwrap('engine_best_move',       'string', ['number', 'number']);
    api.getEval       = M.cwrap('engine_get_eval',        'number', []);
    api.getLegalMoves = M.cwrap('engine_get_legal_moves', 'string', []);
    api.getFen        = M.cwrap('engine_get_fen',         'string', []);
    api.isGameOver    = M.cwrap('engine_is_game_over',    'number', []);
    api.sideToMove    = M.cwrap('engine_get_side_to_move','number', []);
    api.clearTT       = M.cwrap('engine_clear_tt',        null,   []);
}

// WASM yükle
ApexTimurlenkModule().then(M => {
    Module = M;
    initApi(M);
    api.init(16); // 16 MB TT varsayılan
    ready = true;
    postMessage({ type: 'ready' });
});

// ── Mesaj işleyici ───────────────────────────────────────────────────────────
self.onmessage = function(e) {
    const { id, cmd, data } = e.data;

    if (!ready && cmd !== 'ping') {
        postMessage({ id, error: 'Motor henüz hazır değil' });
        return;
    }

    try {
        let result;

        switch (cmd) {
            case 'ping':
                result = { pong: true, ready };
                break;

            case 'init':
                api.init(data?.hashMb ?? 16);
                result = { ok: true };
                break;

            case 'newGame':
                api.newGame();
                result = { ok: true };
                break;

            case 'setPosition': {
                // data: { fen: "startpos" | "...", moves: "e2e4 e7e5" }
                const pos = data?.fen ?? 'startpos';
                const ok = api.setPosition(pos);
                if (ok && data?.moves) {
                    api.doMoves(data.moves);
                }
                result = { ok: !!ok, fen: api.getFen() };
                break;
            }

            case 'doMoves': {
                // data: { moves: "e2e4 e7e5" }
                const n = api.doMoves(data?.moves ?? '');
                result = { applied: n, fen: api.getFen() };
                break;
            }

            case 'bestMove': {
                // data: { depth: 6, movetime: 1000 }
                const depth    = data?.depth    ?? 6;
                const movetime = data?.movetime ?? 0;
                const move = api.bestMove(depth, movetime);
                const eval_ = api.getEval();
                result = { move, eval: eval_, fen: api.getFen() };
                break;
            }

            case 'eval':
                result = { eval: api.getEval(), side: api.sideToMove() };
                break;

            case 'legalMoves': {
                const raw = api.getLegalMoves();
                result = { moves: JSON.parse(raw) };
                break;
            }

            case 'isGameOver': {
                // 0=devam, 1=mat, 2=pat, 3=citadel beraberlik
                const status = api.isGameOver();
                const STATUS = ['playing', 'checkmate', 'stalemate', 'citadel'];
                result = { status: STATUS[status] ?? 'unknown', code: status };
                break;
            }

            case 'fen':
                result = { fen: api.getFen() };
                break;

            case 'clearTT':
                api.clearTT();
                result = { ok: true };
                break;

            default:
                result = { error: `Bilinmeyen komut: ${cmd}` };
        }

        postMessage({ id, result });
    } catch (err) {
        postMessage({ id, error: err.message ?? String(err) });
    }
};
