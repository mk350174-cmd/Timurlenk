/**
 * ApexWorker.js — Apex Timurlenk WebAssembly Web Worker Köprüsü
 *
 * Kullanım (ana thread):
 *   const worker = new ApexEngineWorker('/engine/apex_timur.js');
 *   await worker.init();
 *   await worker.newGame();
 *   await worker.setPersona('Machiavelli', 60);
 *   const move = await worker.bestMove(8, 2000);
 *   const info = worker.lastInfo; // { depth, score, pv, nps, nodes }
 *
 * Worker içinde emcc çıktısı olan apex_timur.js yüklenir.
 * Tüm çağrılar Promise tabanlıdır — UI asla bloklanmaz.
 */

'use strict';

// ═══════════════════════════════════════════════════════════════
// BÖLÜM A — Worker İç Kodu (importScripts ile yüklenen taraf)
// ═══════════════════════════════════════════════════════════════

// Bu blok Worker içinde çalışır (self === DedicatedWorkerGlobalScope)
if (typeof importScripts === 'function') {

  let Module = null;
  let _ready = false;

  // WASM modülünü yükle
  self.onmessage = async function(e) {
    const { id, cmd, args } = e.data;

    try {
      const result = await dispatch(cmd, args);
      self.postMessage({ id, ok: true, result });
    } catch (err) {
      self.postMessage({ id, ok: false, error: err.message || String(err) });
    }
  };

  async function dispatch(cmd, args) {
    switch (cmd) {

      case 'load': {
        // apex_timur.js path'ini al ve modülü yükle
        const wasmUrl = args[0];
        importScripts(wasmUrl);
        // Emscripten modülü global 'ApexTimur' veya 'Module' olarak tanımlar
        const factory = self.ApexTimur || self.Module;
        if (!factory) throw new Error('WASM factory bulunamadı. apex_timur.js doğru mu?');
        Module = await factory();
        _ready = true;
        return 'loaded';
      }

      case 'init': {
        _check();
        const hashMb = (args && args[0]) || 16;
        Module.ccall('engine_init', null, ['number'], [hashMb]);
        return 'ok';
      }

      case 'newGame': {
        _check();
        Module.ccall('engine_new_game', null, [], []);
        return 'ok';
      }

      case 'setPosition': {
        _check();
        const pos = args[0] || 'startpos';
        const ok = Module.ccall('engine_set_position', 'number', ['string'], [pos]);
        if (!ok) throw new Error('Geçersiz FEN: ' + pos);
        return 'ok';
      }

      case 'doMoves': {
        _check();
        const moves = args[0] || '';
        const count = Module.ccall('engine_do_moves', 'number', ['string'], [moves]);
        return count;
      }

      case 'bestMove': {
        _check();
        const depth = (args && args[0]) || 0;
        const ms    = (args && args[1]) || 2000;
        const move  = Module.ccall('engine_search_async', 'string', ['number','number'], [depth, ms]);
        const info  = _parseInfo(Module.ccall('engine_get_last_info', 'string', [], []));
        return { move, info };
      }

      case 'getEval': {
        _check();
        return Module.ccall('engine_get_eval', 'number', [], []);
      }

      case 'getLegalMoves': {
        _check();
        const raw = Module.ccall('engine_get_legal_moves', 'string', [], []);
        return JSON.parse(raw);
      }

      case 'getFen': {
        _check();
        return Module.ccall('engine_get_fen', 'string', [], []);
      }

      case 'getBoardJson': {
        _check();
        const raw = Module.ccall('engine_get_board_json', 'string', [], []);
        return JSON.parse(raw);
      }

      case 'isGameOver': {
        _check();
        // 0=devam 1=mat 2=pat 3=citadel beraberlik
        return Module.ccall('engine_is_game_over', 'number', [], []);
      }

      case 'getSideToMove': {
        _check();
        // 0=beyaz 1=siyah
        return Module.ccall('engine_get_side_to_move', 'number', [], []);
      }

      case 'setPersona': {
        _check();
        const name   = (args && args[0]) || 'None';
        const psyche = (args && args[1]) || 0;
        const ok = Module.ccall('engine_set_persona', 'number', ['string','number'], [name, psyche]);
        if (!ok) throw new Error('Bilinmeyen persona: ' + name);
        return 'ok';
      }

      case 'undo': {
        _check();
        const ok = Module.ccall('engine_undo', 'number', [], []);
        return ok === 1 ? 'ok' : 'nothing_to_undo';
      }

      case 'clearTT': {
        _check();
        Module.ccall('engine_clear_tt', null, [], []);
        return 'ok';
      }

      default:
        throw new Error('Bilinmeyen komut: ' + cmd);
    }
  }

  function _check() {
    if (!_ready || !Module) throw new Error('Motor henüz yüklenmedi. load() çağrısı yapın.');
  }

  function _parseInfo(jsonStr) {
    try { return JSON.parse(jsonStr); }
    catch(e) { return {}; }
  }
}

// ═══════════════════════════════════════════════════════════════
// BÖLÜM B — Ana Thread Tarafı (ApexEngineWorker sınıfı)
// ═══════════════════════════════════════════════════════════════

// Worker olmayan ortamda (ana thread) bu sınıf dışa açılır
if (typeof window !== 'undefined' || typeof globalThis !== 'undefined') {

class ApexEngineWorker {
  /**
   * @param {string} wasmJsUrl  - emcc çıktısı apex_timur.js'nin URL'i
   * @param {string} workerUrl  - Bu dosyanın URL'i (ApexWorker.js)
   */
  constructor(wasmJsUrl, workerUrl) {
    this._wasmUrl   = wasmJsUrl;
    this._workerUrl = workerUrl || document.currentScript?.src || '/ApexWorker.js';
    this._worker    = null;
    this._pending   = new Map(); // id → { resolve, reject }
    this._nextId    = 1;
    this.lastInfo   = null; // Son arama bilgisi
    this.onInfo     = null; // Opsiyonel callback: fn(info)
  }

  // ── Başlatma ──────────────────────────────────────────────────

  /** Worker'ı başlat ve WASM modülünü yükle */
  async init(hashMb = 16) {
    this._worker = new Worker(this._workerUrl);
    this._worker.onmessage = (e) => this._onMessage(e);
    this._worker.onerror   = (e) => {
      console.error('[ApexWorker] Worker hatası:', e.message);
    };

    await this._call('load', [this._wasmUrl]);
    await this._call('init', [hashMb]);
    console.log('[ApexWorker] Motor hazır. Hash:', hashMb, 'MB');
  }

  /** Worker'ı kapat */
  destroy() {
    if (this._worker) {
      this._worker.terminate();
      this._worker = null;
    }
    this._pending.clear();
  }

  // ── Motor Komutları ───────────────────────────────────────────

  /** Yeni oyun başlat */
  newGame()                    { return this._call('newGame'); }

  /**
   * Pozisyonu kur
   * @param {string} pos - "startpos" veya FEN string
   */
  setPosition(pos)             { return this._call('setPosition', [pos]); }

  /**
   * Hamleleri uygula
   * @param {string} moves - "e2e4 e7e5 g1f3" formatında
   * @returns {Promise<number>} uygulanan hamle sayısı
   */
  doMoves(moves)               { return this._call('doMoves', [moves]); }

  /**
   * En iyi hamleyi ara
   * @param {number} depth       - Maksimum derinlik (0 = sınırsız)
   * @param {number} movetimeMs  - Zaman sınırı ms
   * @returns {Promise<{move: string, info: object}>}
   */
  async bestMove(depth = 0, movetimeMs = 2000) {
    const result = await this._call('bestMove', [depth, movetimeMs]);
    this.lastInfo = result.info;
    if (this.onInfo) this.onInfo(result.info);
    return result;
  }

  /** Statik değerlendirme skoru (centipawn) */
  getEval()                    { return this._call('getEval'); }

  /**
   * Yasal hamleler listesi
   * @returns {Promise<string[]>} ["e2e4", "d2d4", "swap:e1g1", ...]
   */
  getLegalMoves()              { return this._call('getLegalMoves'); }

  /** Mevcut FEN string */
  getFen()                     { return this._call('getFen'); }

  /**
   * Tahta durumu JSON
   * @returns {Promise<{pieces: Array, turn: string, inCheck: boolean}>}
   */
  getBoardJson()               { return this._call('getBoardJson'); }

  /**
   * Oyun bitti mi?
   * @returns {Promise<number>} 0=devam 1=mat 2=pat 3=citadel beraberlik
   */
  isGameOver()                 { return this._call('isGameOver'); }

  /**
   * Sıradaki taraf
   * @returns {Promise<number>} 0=beyaz 1=siyah
   */
  getSideToMove()              { return this._call('getSideToMove'); }

  /**
   * AI kişiliğini ayarla
   * @param {string} name    - "Machiavelli"|"Bozkurt"|"Ulgen"|"Erlik"|
   *                           "Nietzsche"|"Tengri"|"DedeKorkut"|"Umay"|"None"
   * @param {number} psyche  - -100..100
   */
  setPersona(name, psyche = 0) { return this._call('setPersona', [name, psyche]); }

  /** Son hamleyi geri al */
  undo()                       { return this._call('undo'); }

  /** Transpozisyon tablosunu temizle */
  clearTT()                    { return this._call('clearTT'); }

  // ── Yardımcı: Tam Oyun Akışı ──────────────────────────────────

  /**
   * Tam hamle yap (pozisyon + uygula + kontrol)
   * @param {string[]} moveHistory - Tüm hamle geçmişi ["e2e4","e7e5",...]
   * @returns {Promise<{move, info, gameOver, sideToMove}>}
   */
  async makeAIMove(moveHistory = [], depth = 0, movetimeMs = 2000) {
    if (moveHistory.length > 0) {
      await this.setPosition('startpos');
      await this.doMoves(moveHistory.join(' '));
    }
    const { move, info } = await this.bestMove(depth, movetimeMs);
    const gameOver       = await this.isGameOver();
    const sideToMove     = await this.getSideToMove();
    return { move, info, gameOver, sideToMove };
  }

  // ── İç Mekanizma ──────────────────────────────────────────────

  _call(cmd, args = []) {
    return new Promise((resolve, reject) => {
      const id = this._nextId++;
      this._pending.set(id, { resolve, reject });
      this._worker.postMessage({ id, cmd, args });
    });
  }

  _onMessage(e) {
    const { id, ok, result, error } = e.data;
    const pending = this._pending.get(id);
    if (!pending) return;
    this._pending.delete(id);
    if (ok) pending.resolve(result);
    else    pending.reject(new Error(error));
  }
}

// Global'e ekle
if (typeof window !== 'undefined')     window.ApexEngineWorker = ApexEngineWorker;
if (typeof globalThis !== 'undefined') globalThis.ApexEngineWorker = ApexEngineWorker;

} // end if (window/globalThis)
