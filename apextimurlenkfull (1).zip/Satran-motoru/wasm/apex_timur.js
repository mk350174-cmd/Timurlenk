/**
 * apex_timur.js — Apex Timurlenk Tarayıcı API
 *
 * Web Worker üzerinden motoru saran async/await arayüzü.
 * Bloklayıcı arama ana iş parçacığını dondurmaz.
 *
 * Kullanım:
 *   <script src="apex_timur.js"></script>
 *   const engine = new ApexTimurlenkEngine('apex_timur_worker.js');
 *   await engine.ready();
 *   await engine.newGame();
 *   const { move, eval } = await engine.bestMove({ depth: 6 });
 *   console.log(move); // "c1d4"
 */

class ApexTimurlenkEngine {
    /**
     * @param {string} workerUrl  — Worker script yolu (varsayılan: 'apex_timur_worker.js')
     * @param {object} opts       — { hashMb: 16 }
     */
    constructor(workerUrl = 'apex_timur_worker.js', opts = {}) {
        this._worker  = new Worker(workerUrl);
        this._pending = new Map();   // id → { resolve, reject }
        this._nextId  = 1;
        this._readyPromise = null;
        this._opts = opts;

        this._worker.onmessage = (e) => {
            const { id, type, result, error } = e.data;

            // İlk hazırlık mesajı
            if (type === 'ready') {
                if (this._readyResolve) {
                    this._readyResolve();
                    this._readyResolve = null;
                }
                return;
            }

            const pending = this._pending.get(id);
            if (!pending) return;
            this._pending.delete(id);
            if (error) pending.reject(new Error(error));
            else       pending.resolve(result);
        };

        this._worker.onerror = (e) => {
            console.error('[ApexTimurlenk] Worker hatası:', e);
        };
    }

    // ── Dahili iletişim ────────────────────────────────────────────────────────

    _send(cmd, data) {
        const id = this._nextId++;
        return new Promise((resolve, reject) => {
            this._pending.set(id, { resolve, reject });
            this._worker.postMessage({ id, cmd, data });
        });
    }

    // ── Genel API ─────────────────────────────────────────────────────────────

    /**
     * Motor ve WASM hazır olana kadar bekle.
     * @returns {Promise<void>}
     */
    ready() {
        if (!this._readyPromise) {
            this._readyPromise = new Promise((resolve) => {
                this._readyResolve = resolve;
                // Zaten hazırsa ping ile kontrol et
                this._send('ping', null).then(r => {
                    if (r.ready && this._readyResolve) {
                        this._readyResolve();
                        this._readyResolve = null;
                    }
                }).catch(() => {});
            });
        }
        return this._readyPromise;
    }

    /**
     * Yeni oyun başlat (TT temizle, startpos kur).
     */
    newGame() {
        return this._send('newGame', null);
    }

    /**
     * Pozisyonu ayarla.
     * @param {string} fen    — "startpos" veya FEN string
     * @param {string} moves  — Boşlukla ayrılmış UCI hamleleri (opsiyonel)
     * @returns {Promise<{ok, fen}>}
     */
    setPosition(fen = 'startpos', moves = '') {
        return this._send('setPosition', { fen, moves: moves || undefined });
    }

    /**
     * Mevcut pozisyona hamle(ler) uygula.
     * @param {string|string[]} moves — "e2e4" veya ["e2e4","e7e5"]
     * @returns {Promise<{applied, fen}>}
     */
    doMoves(moves) {
        const s = Array.isArray(moves) ? moves.join(' ') : moves;
        return this._send('doMoves', { moves: s });
    }

    /**
     * En iyi hamleyi bul.
     * @param {object} opts — { depth: 6, movetime: 1000 }
     * @returns {Promise<{move: string, eval: number, fen: string}>}
     *   move: "e2e4" | "swap:e1h4" | "a9bc"
     *   eval: santipawn (pozitif = sıradaki taraf avantajlı)
     */
    bestMove(opts = {}) {
        return this._send('bestMove', {
            depth:    opts.depth    ?? 6,
            movetime: opts.movetime ?? 0,
        });
    }

    /**
     * Statik değerlendirme al (cp).
     * @returns {Promise<{eval: number, side: number}>}
     */
    getEval() {
        return this._send('eval', null);
    }

    /**
     * Yasal hamle listesi al.
     * @returns {Promise<{moves: string[]}>}
     */
    getLegalMoves() {
        return this._send('legalMoves', null);
    }

    /**
     * Oyun bitti mi?
     * @returns {Promise<{status: 'playing'|'checkmate'|'stalemate'|'citadel', code: number}>}
     */
    isGameOver() {
        return this._send('isGameOver', null);
    }

    /**
     * Mevcut FEN string.
     * @returns {Promise<{fen: string}>}
     */
    getFen() {
        return this._send('fen', null);
    }

    /**
     * Transpozisyon tablosunu temizle.
     */
    clearTT() {
        return this._send('clearTT', null);
    }

    /**
     * Worker'ı kapat.
     */
    destroy() {
        this._worker.terminate();
        this._pending.forEach(({ reject }) => reject(new Error('Motor kapatıldı')));
        this._pending.clear();
    }
}

// ES module ve script tag uyumluluğu
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { ApexTimurlenkEngine };
} else if (typeof window !== 'undefined') {
    window.ApexTimurlenkEngine = ApexTimurlenkEngine;
}
