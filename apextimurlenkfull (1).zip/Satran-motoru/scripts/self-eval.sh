#!/bin/bash
# Apex Timurlenk haftalık öz-değerlendirme
# Kullanım: bash scripts/self-eval.sh [--json]
set -e
ENGINE=${ENGINE:-./build/apex_timur}
SCORE=0
TOTAL=0

check() {
  local label="$1" result="$2" expected="$3"
  TOTAL=$((TOTAL+1))
  if echo "$result" | grep -q "$expected"; then
    echo "  V $label"
    SCORE=$((SCORE+1))
  else
    echo "  X $label (beklenen: $expected)"
    echo "    Cikti: $(echo "$result" | head -1)"
  fi
}

echo "=== Apex Timurlenk Oz-Degerlendirme ==="
echo "Tarih: $(date '+%Y-%m-%d %H:%M')"
echo ""

# Motor varlık kontrolü
echo "## 1. Motor"
if [ -f "$ENGINE" ]; then
  echo "  V Binary mevcut: $ENGINE"
  SCORE=$((SCORE+1))
else
  echo "  X Binary yok: $ENGINE --- yeniden derle: cmake --build build"
fi
TOTAL=$((TOTAL+1))

# UCI protokol
UCI_OUT=$(printf "uci\nquit\n" | "$ENGINE" 2>/dev/null)
check "uciok" "$UCI_OUT" "uciok"

# isready
READY_OUT=$(printf "uci\nisready\nquit\n" | "$ENGINE" 2>/dev/null)
check "readyok" "$READY_OUT" "readyok"

# Perft doğrulama
echo ""
echo "## 2. Perft Regresyon"
PERFT_OUT=$(printf "position startpos\nperft 1\nperft 2\nquit\n" | "$ENGINE" 2>/dev/null)
check "perft(1)=53" "$PERFT_OUT" "53"
check "perft(2)=2809" "$PERFT_OUT" "2809"

# Arama testi
echo ""
echo "## 3. Arama"
SEARCH_OUT=$(printf "position startpos\ngo depth 4\nquit\n" | "$ENGINE" 2>/dev/null)
check "bestmove uretiyor" "$SEARCH_OUT" "bestmove"
NPS=$(echo "$SEARCH_OUT" | grep -oP 'nps \K\d+' | tail -1)
if [ -n "$NPS" ] && [ "$NPS" -gt 10000 ]; then
  echo "  V NPS: $NPS (>10k)"
  SCORE=$((SCORE+1))
else
  echo "  ! NPS: ${NPS:-bilinmiyor} (hedef: >10k)"
fi
TOTAL=$((TOTAL+1))

# Bridge kontrolü
echo ""
echo "## 4. Bridge"
if python3 -m py_compile bridge/engine_server.py 2>/dev/null; then
  echo "  V engine_server.py sozdizimi gecerli"
  SCORE=$((SCORE+1))
else
  echo "  X engine_server.py sozdizimi hatasi"
fi
TOTAL=$((TOTAL+1))

if node --check bridge/engine_ui_bridge.js 2>/dev/null; then
  echo "  V engine_ui_bridge.js sozdizimi gecerli"
  SCORE=$((SCORE+1))
else
  echo "  X engine_ui_bridge.js sozdizimi hatasi"
fi
TOTAL=$((TOTAL+1))

# UI dosyası
echo ""
echo "## 5. UI"
if node --check timurlenk_ui_v2.html 2>/dev/null; then
  echo "  V timurlenk_ui_v2.html sozdizimi gecerli"
  SCORE=$((SCORE+1))
else
  echo "  X timurlenk_ui_v2.html sozdizimi hatasi"
fi
TOTAL=$((TOTAL+1))

# Sonuç
echo ""
echo "================================="
echo "Skor: $SCORE/$TOTAL"
PCT=$((SCORE*100/TOTAL))
if [ "$PCT" -ge 90 ]; then
  echo "Durum: SAGLIKLI V ($PCT%)"
elif [ "$PCT" -ge 70 ]; then
  echo "Durum: UYARI ! ($PCT%)"
else
  echo "Durum: KRITIK X ($PCT%)"
fi
