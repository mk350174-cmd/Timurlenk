/**
 * test_rules.cpp — Apex Timurlenk kural birim testleri
 *
 * Derleme:
 *   g++ -std=c++20 -O2 -I../include test_rules.cpp \
 *       ../src/board.cpp ../src/tt.cpp ../src/movegen.cpp \
 *       ../src/evaluate.cpp ../src/nnue.cpp -o test_rules
 * Çalıştırma:
 *   ./test_rules
 */

#include "board.h"
#include "movegen.h"
#include "evaluate.h"
#include "tt.h"
#include <iostream>
#include <cassert>
#include <string>

using namespace Apex;

// ─── Yardımcı ────────────────────────────────────────────────────────────────

static int passed = 0;
static int failed = 0;

#define TEST(name, expr) do { \
    if (expr) { std::cout << "[OK] " << name << "\n"; passed++; } \
    else       { std::cout << "[FAIL] " << name << "\n"; failed++; } \
} while(0)

// ─── Perft Doğrulama ─────────────────────────────────────────────────────────

static u64 perft(Board& b, int depth) {
    if (depth == 0) return 1;
    MoveList ml;
    MoveGenerator::generate_legal(b, ml);
    u64 count = 0;
    for (auto& me : ml) {
        StateInfo st;
        b.do_move(me.move, st, me.promo);
        count += perft(b, depth - 1);
        b.undo_move(me.move);
    }
    return count;
}

static void test_perft() {
    Board b;
    b.setup();
    TEST("perft(1) = 53",    perft(b, 1) == 53);
    TEST("perft(2) = 2809",  perft(b, 2) == 2809);
    TEST("perft(3) = 112479",perft(b, 3) == 112479);
}

// ─── Citadel Kuralı ──────────────────────────────────────────────────────────

static void test_citadel() {
    Board b;
    b.setup();
    // Başlangıçta citadel üzerinde şah yok
    TEST("citadel başlangıç: beyaz yok",  !b.king_on_citadel(WHITE));
    TEST("citadel başlangıç: siyah yok",  !b.king_on_citadel(BLACK));
}

// ─── Swap Kuralı ─────────────────────────────────────────────────────────────

static void test_swap() {
    Board b;
    b.setup();
    // Başlangıçta her iki taraf da swap hakkına sahip
    TEST("swap hakkı WHITE başlangıç", b.can_swap(WHITE));
    TEST("swap hakkı BLACK başlangıç", b.can_swap(BLACK));
}

// ─── FEN Round-Trip ───────────────────────────────────────────────────────────

static void test_fen_roundtrip() {
    Board b;
    b.setup();
    std::string fen1 = b.to_fen();
    Board b2;
    bool ok = b2.from_string(fen1);
    std::string fen2 = b2.to_fen();
    TEST("FEN yükleme başarılı", ok);
    TEST("FEN round-trip eşit", fen1 == fen2);
}

// ─── Hamle Geri Alma ─────────────────────────────────────────────────────────

static void test_undo_move() {
    Board b;
    b.setup();
    std::string fen_before = b.to_fen();
    u64 hash_before = b.hash();

    MoveList ml;
    MoveGenerator::generate_legal(b, ml);
    if (ml.size() > 0) {
        auto& me = ml.moves[0];
        StateInfo st;
        b.do_move(me.move, st, me.promo);
        b.undo_move(me.move);

        TEST("undo_move sonrası FEN aynı",  b.to_fen() == fen_before);
        TEST("undo_move sonrası hash aynı", b.hash() == hash_before);
    }
}

// ─── Değerlendirme Simetrisi ──────────────────────────────────────────────────

static void test_eval_symmetry() {
    init_pst();
    Board b;
    b.setup();
    Evaluator ev;
    i32 white_pov = ev.evaluate(b, WHITE);
    i32 black_pov = ev.evaluate(b, BLACK);
    // Başlangıçta değerlendirme her iki taraf için simetrik olmalı (≈0 veya eşit)
    // |white_pov + black_pov| küçük olmalı (nötr pozisyon)
    int diff = white_pov + black_pov;
    TEST("eval simetrisi: fark < 50cp", diff < 50 && diff > -50);
}

// ─── Ana ─────────────────────────────────────────────────────────────────────

int main() {
    std::cout << "=== Apex Timurlenk Kural Testleri ===\n\n";

    Zobrist.init();
    init_pst();

    test_perft();
    test_citadel();
    test_swap();
    test_fen_roundtrip();
    test_undo_move();
    test_eval_symmetry();

    std::cout << "\n--- Sonuç: " << passed << " geçti, " << failed << " başarısız ---\n";
    return (failed == 0) ? 0 : 1;
}
